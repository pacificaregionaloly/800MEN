# Wavesports API Contract — Men's 200 Metres (WSTV)

This specification defines the HTTP / Realtime API consumed by the self-contained **Men's 200m Event Module** (`event/men200m/api/WavesportsApiClient.ts`) for **Klemonserrat Stadium** (**1st Pacifica Regional Olympics 2026**).

---

## Authentication & Configuration

All HTTP requests include:

```http
Authorization: Bearer <API_TOKEN>
Content-Type: application/json
Accept: application/json
```

Client configuration (`event/men200m/config/index.ts`):
- `API_BASE_URL` — Base URL (default `/api/wavesports`, `VITE_WAVESPORTS_API_BASE_URL`, or `?apiBase=...`)
- `API_TOKEN` — Bearer token (`VITE_WAVESPORTS_API_TOKEN`)
- `RACE_ID` — Race identifier (default `men-200m-final-1`, `VITE_WAVESPORTS_200M_RACE_ID`, or `?race=...`)
- `POLL_INTERVAL_MS` — Polling interval in ms (default `2500`, or `VITE_WAVESPORTS_POLL_MS`)

---

## Endpoints

### 1. Fetch Race Setup
`GET {API_BASE_URL}/races/{raceId}/setup`

The client remains in `WAITING_FOR_API` (stadium live and orbitable, no athletes placed, race controls disabled) until this endpoint returns HTTP 200 with a payload passing validation.

#### Setup Payload Schema
```json
{
  "raceId": "men-200m-final-1",
  "event": "men_200m",
  "round": "final",
  "heat": 1,
  "seed": 739204,
  "scheduledStartTime": "2026-12-06T16:15:00Z",
  "allowManualStart": false,
  "venue": "Klemonserrat Stadium",
  "rules": {
    "falseStartDisqualifies": true,
    "windLimitMps": 2.0
  },
  "incidentOverrides": null,
  "athletes": [
    {
      "athleteId": "ath_205",
      "lane": 5,
      "name": "Kaelen Tuiasosopo",
      "shortName": "TUIASOSOPO",
      "nation": "New Pleadland",
      "nationCode": "NPL",
      "bib": "205",
      "kit": {
        "primary": "#0033A0",
        "secondary": "#FFFFFF",
        "accent": "#D4AF37"
      },
      "ratings": {
        "reaction": 86,
        "acceleration": 90,
        "topSpeed": 95,
        "speedEndurance": 91,
        "consistency": 89,
        "composure": 87,
        "durability": 86,
        "technique": 92
      },
      "personalBest": 19.79,
      "seasonBest": 19.85,
      "status": "active"
    }
  ]
}
```

#### Validation Rules (Client-Enforced)
If any check fails, the module rejects the payload, stays in `WAITING_FOR_API`, displays an error, retries with exponential backoff, and attempts to POST `VALIDATION_FAILED` to `/status`:
- `event`: must equal `"men_200m"` (all other events rejected)
- `athletes`: array of **2 to 8** entries
- `lane`: unique integers **1 to 8**
- `ratings`: all 8 fields (`reaction`, `acceleration`, `topSpeed`, `speedEndurance`, `consistency`, `composure`, `durability`, `technique`) must be finite numbers in **0..100**
- `seed`: must be an **integer**
- `status`: must be `"active"` or `"dns"`
- `kit`: `{ primary, secondary, accent }` color strings required

---

### 2. Poll or Stream Race Commands
- HTTP Polling: `GET {API_BASE_URL}/races/{raceId}/commands?since={ISO-8601}`
- Optional SSE (`?realtime=sse`): `GET {API_BASE_URL}/races/{raceId}/commands/stream`
- Optional WebSocket (`?realtime=ws`): `WS {API_BASE_URL}/races/{raceId}/commands/ws`

Commands:
```json
{ "command": "start", "issuedAt": "2026-12-06T16:15:00Z" }
{ "command": "abort", "reason": "Track obstruction" }
{ "command": "reset" }
```

---

### 3. Post Race Status Updates
`POST {API_BASE_URL}/races/{raceId}/status`

Lifecycle statuses emitted:
`VALIDATED`, `ATHLETES_ON_TRACK`, `READY`, `ON_YOUR_MARKS`, `SET`, `FALSE_START`, `RECALL`, `RUNNING`, `ABORTED`, `RESULTS_POSTED`, `VALIDATION_FAILED`, `API_ERROR`, `SELF_CHECK_FAILED`.

---

### 4. Post Final Results
`POST {API_BASE_URL}/races/{raceId}/results`

Sent automatically when the race transitions to `FINISHED`, moving to `RESULTS_POSTED`:

```json
{
  "raceId": "men-200m-final-1",
  "seed": 739204,
  "completedAt": "2026-12-06T16:15:24Z",
  "wind": { "mps": 0.9, "legal": true },
  "incidents": [
    {
      "type": "lane_violation",
      "code": "LANE_LINE_INSIDE_DQ",
      "athleteId": "ath_201",
      "lane": 1,
      "attempt": 0,
      "atTime": 8.42,
      "detail": "Kitione Wari stepped inside the inner lane line on the bend near 84m (DQ)."
    }
  ],
  "results": [
    {
      "rank": 1,
      "lane": 5,
      "athleteId": "ath_205",
      "name": "Kaelen Tuiasosopo",
      "shortName": "TUIASOSOPO",
      "nation": "New Pleadland",
      "nationCode": "NPL",
      "bib": "205",
      "time": 19.84,
      "exactTime": 19.839,
      "reactionTime": 0.141,
      "splits": { "50": 5.56, "100": 10.12, "150": 14.84 },
      "bendTime": 11.44,
      "straightTime": 8.40,
      "topSpeedMps": 11.98,
      "status": "finished",
      "notes": []
    }
  ]
}
```
