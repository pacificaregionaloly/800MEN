# Wavesports API Contract — Men's 400 Metres (WSTV)

This specification defines the HTTP / Realtime API consumed by the self-contained **Men's 400m Event Module** (`event/men400m/api/WavesportsApiClient.ts`) for **Klemonserrat Stadium** (**1st Pacifica Regional Olympics 2026**).

---

## Authentication & Configuration

All HTTP requests include:

```http
Authorization: Bearer <API_TOKEN>
Content-Type: application/json
Accept: application/json
```

Client configuration (`event/men400m/config/index.ts`):
- `API_BASE_URL` — Base URL (default `/api/wavesports`, `VITE_WAVESPORTS_API_BASE_URL`, or `?apiBase=...`)
- `API_TOKEN` — Bearer token (`VITE_WAVESPORTS_API_TOKEN`)
- `RACE_ID` — Race identifier (default `men-400m-final-1`, `VITE_WAVESPORTS_400M_RACE_ID`, or `?race=...`)
- `POLL_INTERVAL_MS` — Polling interval in ms (default `2500`, or `VITE_WAVESPORTS_POLL_MS`)

---

## Endpoints

### 1. Fetch Race Setup
`GET {API_BASE_URL}/races/{raceId}/setup`

The client remains in `WAITING_FOR_API` (stadium live and orbitable, no athletes placed, race controls disabled) until this endpoint returns HTTP 200 with a payload passing validation.

#### Setup Payload Schema
```json
{
  "raceId": "men-400m-final-1",
  "event": "men_400m",
  "round": "final",
  "heat": 1,
  "seed": 400826,
  "scheduledStartTime": "2026-12-06T17:10:00Z",
  "allowManualStart": false,
  "venue": "Klemonserrat Stadium",
  "rules": {
    "falseStartDisqualifies": true,
    "windLimitMps": 2.0
  },
  "incidentOverrides": null,
  "athletes": [
    {
      "athleteId": "ath_405",
      "lane": 5,
      "name": "Nikau Tamati",
      "shortName": "TAMATI",
      "nation": "New Pleadland",
      "nationCode": "NPL",
      "bib": "405",
      "kit": {
        "primary": "#0033A0",
        "secondary": "#FFFFFF",
        "accent": "#D4AF37"
      },
      "ratings": {
        "reaction": 85,
        "acceleration": 89,
        "topSpeed": 94,
        "speedEndurance": 95,
        "consistency": 91,
        "composure": 89,
        "durability": 88,
        "technique": 92
      },
      "personalBest": 43.94,
      "seasonBest": 44.05,
      "status": "active"
    }
  ]
}
```

#### Validation Rules (Client-Enforced)
If any check fails, the module rejects the payload, stays in `WAITING_FOR_API`, displays an error, retries with exponential backoff, and attempts to POST `VALIDATION_FAILED` to `/status`:
- `event`: must equal `"men_400m"` (all other events — including `women_400m`, `men_200m`, `women_200m`, `men_100m`, `women_100m` — are rejected)
- `athletes`: array of **2 to 8** entries
- `lane`: unique integers **1 to 8**
- `ratings`: all 8 fields (`reaction`, `acceleration`, `topSpeed`, `speedEndurance`, `consistency`, `composure`, `durability`, `technique`) must be finite numbers in **0..100**
- `seed`: must be an **integer**
- `status`: must be `"active"` or `"dns"`
- `kit`: `{ primary, secondary, accent }` color strings required

---

### 2. Poll or Stream Race Commands
- HTTP Polling: `GET {API_BASE_URL}/races/{raceId}/commands?since={ISO-8601}`
- Optional SSE (`?realtime=sse`): `GET {API_BASE_URL}/races/{raceId}/commands/stream`
- Optional WebSocket (`?realtime=ws`): `WS {API_BASE_URL}/races/{raceId}/commands/ws`

Commands:
```json
{ "command": "start", "issuedAt": "2026-12-06T17:10:00Z" }
{ "command": "abort", "reason": "Track obstruction" }
{ "command": "reset" }
```

---

### 3. Post Race Status Updates
`POST {API_BASE_URL}/races/{raceId}/status`

Lifecycle statuses emitted:
`VALIDATED`, `ATHLETES_ON_TRACK`, `READY`, `ON_YOUR_MARKS`, `SET`, `FALSE_START`, `RECALL`, `RUNNING`, `ABORTED`, `RESULTS_POSTED`, `VALIDATION_FAILED`, `API_ERROR`, `SELF_CHECK_FAILED`.

---

### 4. Post Final Results
`POST {API_BASE_URL}/races/{raceId}/results`

Sent automatically when the race transitions to `FINISHED`, moving to `RESULTS_POSTED`. Note: wind speed is recorded as **informational only** (`wind.legal: true`, as wind-assistance limits do not apply to the 400 m full-lap event).

```json
{
  "raceId": "men-400m-final-1",
  "seed": 400826,
  "completedAt": "2026-12-06T17:11:02Z",
  "wind": { "mps": 1.4, "legal": true },
  "incidents": [
    {
      "type": "fatigue_collapse",
      "code": "FATIGUE_TYING_UP",
      "athleteId": "ath_408",
      "lane": 8,
      "attempt": 0,
      "atTime": 41.82,
      "detail": "Benson Maenu tied up heavily in the closing metres at 364.2m and stumbled toward the line."
    }
  ],
  "results": [
    {
      "rank": 1,
      "lane": 4,
      "athleteId": "ath_404",
      "name": "Callum McAllister",
      "shortName": "MCALLISTER",
      "nation": "Australia",
      "nationCode": "AUS",
      "bib": "404",
      "time": 43.67,
      "exactTime": 43.671,
      "reactionTime": 0.149,
      "splits": { "100": 10.52, "200": 20.40, "300": 31.73 },
      "firstHalf": 20.40,
      "secondHalf": 23.27,
      "topSpeedMps": 10.87,
      "pacingStrategy": "even_paced",
      "status": "finished",
      "notes": ["New PB (43.671s)"]
    }
  ]
}
```
