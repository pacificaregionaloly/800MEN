import * as THREE from 'three';
import { BoardManager } from '../boards/BoardManager';
import { BoardScreen } from '../boards/BoardScreen';
import {
  createNewPleadlandFlagTexture,
  createPacificaBannerTexture,
  createPerimeterAdTexture,
  createWSTVBannerTexture,
} from '../branding/textures';
import { STADIUM_CONFIG } from '../config';
import { SeatSlot } from '../crowd/CrowdManager';
import { buildOvalRibbonGeometry } from '../track/TrackBuilder';
import {
  HALF_STRAIGHT,
  KERB_RADIUS,
  OUTER_TRACK_RADIUS,
  sampleClosedOvalPoints,
} from '../track/trackGeometry';

export interface OvalSample {
  x: number;
  z: number;
  nx: number; // outward normal X
  nz: number; // outward normal Z
  rotY: number; // facing inward (-normal)
  angle: number;
}

/**
 * Uniformly samples points around an oval at radius `r` with spacing `stepMeters`.
 */
function sampleOvalBySpacing(r: number, stepMeters: number): OvalSample[] {
  const straightLen = STADIUM_CONFIG.track.straightLength;
  const bendLen = Math.PI * r;
  const totalLen = 2 * straightLen + 2 * bendLen;
  const count = Math.max(12, Math.round(totalLen / stepMeters));
  const actualStep = totalLen / count;
  const out: OvalSample[] = [];

  for (let i = 0; i < count; i++) {
    let s = i * actualStep;
    let x = 0;
    let z = 0;
    let nx = 0;
    let nz = 1;

    if (s < straightLen) {
      x = -HALF_STRAIGHT + s;
      z = r;
      nx = 0;
      nz = 1;
    } else if (s < straightLen + bendLen) {
      s -= straightLen;
      const phi = Math.PI / 2 - (s / bendLen) * Math.PI;
      nx = Math.cos(phi);
      nz = Math.sin(phi);
      x = HALF_STRAIGHT + r * nx;
      z = r * nz;
    } else if (s < 2 * straightLen + bendLen) {
      s -= straightLen + bendLen;
      x = HALF_STRAIGHT - s;
      z = -r;
      nx = 0;
      nz = -1;
    } else {
      s -= 2 * straightLen + bendLen;
      const phi = -Math.PI / 2 - (s / bendLen) * Math.PI;
      nx = Math.cos(phi);
      nz = Math.sin(phi);
      x = -HALF_STRAIGHT + r * nx;
      z = r * nz;
    }

    out.push({
      x,
      z,
      nx,
      nz,
      rotY: Math.atan2(-nx, -nz),
      angle: Math.atan2(z, x),
    });
  }
  return out;
}

function buildExtrudedOvalWall(
  radius: number,
  yBottom: number,
  yTop: number,
  curveSegments = 72,
  inward = false
): THREE.BufferGeometry {
  const pts = sampleClosedOvalPoints(radius, curveSegments);
  const count = pts.length;
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  let dist = 0;
  for (let i = 0; i < count; i++) {
    const p = pts[i];
    if (i > 0) dist += p.distanceTo(pts[i - 1]);
    positions.push(p.x, yBottom, p.y, p.x, yTop, p.y);
    uvs.push(dist / 24, 0, dist / 24, 1);
  }
  for (let i = 0; i < count; i++) {
    const next = (i + 1) % count;
    const a = i * 2;
    const b = i * 2 + 1;
    const c = next * 2;
    const d = next * 2 + 1;
    if (inward) {
      indices.push(a, b, c, b, d, c);
    } else {
      indices.push(a, c, b, b, c, d);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

function buildSlopedOvalDeck(
  innerR: number,
  innerY: number,
  outerR: number,
  outerY: number,
  curveSegments = 72
): THREE.BufferGeometry {
  const innerPts = sampleClosedOvalPoints(innerR, curveSegments);
  const outerPts = sampleClosedOvalPoints(outerR, curveSegments);
  const count = innerPts.length;
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  let dist = 0;
  for (let i = 0; i < count; i++) {
    const pIn = innerPts[i];
    const pOut = outerPts[i];
    if (i > 0) dist += pIn.distanceTo(innerPts[i - 1]);
    positions.push(pIn.x, innerY, pIn.y, pOut.x, outerY, pOut.y);
    uvs.push(dist * 0.05, 0, dist * 0.05, 1);
  }
  for (let i = 0; i < count; i++) {
    const next = (i + 1) % count;
    const a = i * 2;
    const b = i * 2 + 1;
    const c = next * 2;
    const d = next * 2 + 1;
    indices.push(a, b, c, b, d, c);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

export interface StadiumBuildResult {
  group: THREE.Group;
  seatSlots: SeatSlot[];
  totalSeatsBuilt: number;
  update: (elapsedSeconds: number) => void;
  dispose: () => void;
}

export function buildStadiumStructure(
  boardManager: BoardManager,
  maxAnisotropy: number
): StadiumBuildResult {
  const S = STADIUM_CONFIG.stadium;
  const C = STADIUM_CONFIG.colors;

  const group = new THREE.Group();
  group.name = 'KlemonserratStadiumStructure';

  const seatSlots: SeatSlot[] = [];

  // Shared Architectural Materials
  const concreteMat = new THREE.MeshStandardMaterial({
    color: C.concrete,
    roughness: 0.85,
    metalness: 0.06,
  });
  const darkConcreteMat = new THREE.MeshStandardMaterial({
    color: '#334155',
    roughness: 0.88,
    metalness: 0.08,
  });
  const whiteSteelMat = new THREE.MeshStandardMaterial({
    color: '#F1F5F9',
    roughness: 0.28,
    metalness: 0.45,
  });
  const darkSteelMat = new THREE.MeshStandardMaterial({
    color: '#0F172A',
    roughness: 0.35,
    metalness: 0.72,
  });
  const royalBlueWallMat = new THREE.MeshStandardMaterial({
    color: C.newPleadlandBlue,
    roughness: 0.55,
    metalness: 0.15,
  });
  const goldTrimMat = new THREE.MeshStandardMaterial({
    color: C.goldBright,
    emissive: C.gold,
    emissiveIntensity: 0.35,
    roughness: 0.25,
    metalness: 0.75,
  });
  const glassMat = new THREE.MeshStandardMaterial({
    color: '#1E3A5F',
    roughness: 0.08,
    metalness: 0.88,
    transparent: true,
    opacity: 0.82,
  });

  // Textures
  const flagTex = createNewPleadlandFlagTexture(maxAnisotropy);
  const pacificaTex = createPacificaBannerTexture(maxAnisotropy);
  const wstvTex = createWSTVBannerTexture(maxAnisotropy);
  const adPacificaTex = createPerimeterAdTexture('pacifica', maxAnisotropy);
  const adPleadlandTex = createPerimeterAdTexture('pleadland', maxAnisotropy);
  const adWstvTex = createPerimeterAdTexture('wstv', maxAnisotropy);

  // ============================================================================
  // 1. TWO-TIER CONTINUOUS ~40,000-SEAT BOWL (InstancedMesh)
  // ============================================================================
  const bowlInnerR = OUTER_TRACK_RADIUS + S.bowlInnerOffset; // 51.06 m
  const tier1StartY = 1.4;
  const tier1OuterR = bowlInnerR + S.tier1Rows * S.rowDepth;
  const tier1TopY = tier1StartY + S.tier1Rows * S.rowRise;

  const tier2InnerR = tier1OuterR + S.concourseGap;
  const tier2StartY = tier1TopY + 2.2;
  const tier2OuterR = tier2InnerR + S.tier2Rows * S.rowDepth;
  const tier2TopY = tier2StartY + S.tier2Rows * S.rowRise;

  // Inner bowl retaining wall (inward-facing) + sloped concrete decks + concourse + outer wall
  const innerWall = new THREE.Mesh(
    buildExtrudedOvalWall(bowlInnerR - 0.4, 0, tier1StartY + 0.2, 72, true),
    concreteMat
  );
  group.add(innerWall);

  const tier1Deck = new THREE.Mesh(
    buildSlopedOvalDeck(bowlInnerR - 0.3, tier1StartY - 0.12, tier1OuterR + 0.4, tier1TopY - 0.12, 72),
    darkConcreteMat
  );
  const tier1Shell = new THREE.Mesh(
    buildExtrudedOvalWall(tier1OuterR + 0.3, 0, tier1TopY + 0.3, 72),
    darkConcreteMat
  );
  const concourseDeck = new THREE.Mesh(
    buildOvalRibbonGeometry(tier1OuterR, tier2InnerR + 0.2, tier1TopY + 0.25, 72, 0.03),
    concreteMat
  );
  const tier2Wall = new THREE.Mesh(
    buildExtrudedOvalWall(tier2InnerR - 0.3, tier1TopY, tier2StartY, 72, true),
    royalBlueWallMat
  );
  const tier2Deck = new THREE.Mesh(
    buildSlopedOvalDeck(tier2InnerR - 0.2, tier2StartY - 0.12, tier2OuterR + 0.4, tier2TopY - 0.12, 72),
    darkConcreteMat
  );
  const outerShellWall = new THREE.Mesh(
    buildExtrudedOvalWall(tier2OuterR + 0.5, 0, tier2TopY + 1.8, 72),
    whiteSteelMat
  );
  group.add(tier1Deck, tier1Shell, concourseDeck, tier2Wall, tier2Deck, outerShellWall);

  // Collect seat positions for Tier 1 + Tier 2 (~40,000 seats)
  interface SeatPlacement {
    x: number;
    y: number;
    z: number;
    rotY: number;
    color: THREE.Color;
  }
  const seatPlacements: SeatPlacement[] = [];
  const stairSlots: { x: number; y: number; z: number; rotY: number }[] = [];

  const seatBlue = new THREE.Color(C.newPleadlandBlue);
  const seatBlueMid = new THREE.Color('#1450B8');
  const seatWhite = new THREE.Color('#F1F5F9');
  const seatGold = new THREE.Color(C.goldBright);

  const seatPitch = 0.64; // ~0.64m center-to-center yields ~40,000 seats total across 46 rows

  // Tier 1 rows
  for (let row = 0; row < S.tier1Rows; row++) {
    const r = bowlInnerR + row * S.rowDepth + 0.35;
    const y = tier1StartY + row * S.rowRise;
    const samples = sampleOvalBySpacing(r, seatPitch);
    const total = samples.length;
    const vomEvery = Math.max(48, Math.round(total / 10));

    for (let i = 0; i < total; i++) {
      const s = samples[i];
      const modAisle = i % S.aisleEverySeats;
      const modVom = i % vomEvery;
      const isVomitory = row >= 4 && row <= 9 && modVom < 4;

      if (modAisle === 0) {
        stairSlots.push({ x: s.x, y, z: s.z, rotY: s.rotY });
        continue;
      }
      if (isVomitory) continue;

      // Blue & white wave pattern
      const waveBand = Math.sin((i / total) * Math.PI * 10 + row * 0.25) > 0.42;
      const col = row === 0 || row === S.tier1Rows - 1 ? seatWhite : waveBand ? seatWhite : seatBlue;

      seatPlacements.push({ x: s.x, y, z: s.z, rotY: s.rotY, color: col });
      seatSlots.push({ position: new THREE.Vector3(s.x, y, s.z), rotY: s.rotY });
    }
  }

  // Tier 2 rows (with VIP / Media / Commentary cutout on home straight +Z, |x| < 18)
  for (let row = 0; row < S.tier2Rows; row++) {
    const r = tier2InnerR + row * S.rowDepth + 0.35;
    const y = tier2StartY + row * S.rowRise;
    const samples = sampleOvalBySpacing(r, seatPitch);
    const total = samples.length;

    for (let i = 0; i < total; i++) {
      const s = samples[i];
      // Cutout for VIP & WSTV Commentary Box on bottom rows of Tier 2 Home Straight
      if (s.z > 0 && Math.abs(s.x) < 17.5 && row < 8) {
        continue;
      }
      if (i % S.aisleEverySeats === 0) {
        stairSlots.push({ x: s.x, y, z: s.z, rotY: s.rotY });
        continue;
      }

      const isVipGold = s.z > 0 && Math.abs(s.x) < 22 && row >= 8 && row < 12;
      const band = (row >= 9 && row <= 12) || (Math.floor(i / 18) + row) % 7 === 0;
      const col = isVipGold ? seatGold : band ? seatWhite : row % 2 === 0 ? seatBlue : seatBlueMid;

      seatPlacements.push({ x: s.x, y, z: s.z, rotY: s.rotY, color: col });
      seatSlots.push({ position: new THREE.Vector3(s.x, y, s.z), rotY: s.rotY });
    }
  }

  // Build InstancedMesh for all ~40,000 seats
  const seatGeo = new THREE.BoxGeometry(0.46, 0.46, 0.42);
  seatGeo.translate(0, 0.23, 0);
  const seatMat = new THREE.MeshStandardMaterial({ roughness: 0.62, metalness: 0.08 });
  const seatsInstanced = new THREE.InstancedMesh(seatGeo, seatMat, seatPlacements.length);
  seatsInstanced.name = 'StadiumSeatsInstanced';
  const dummy = new THREE.Object3D();

  for (let i = 0; i < seatPlacements.length; i++) {
    const sp = seatPlacements[i];
    dummy.position.set(sp.x, sp.y, sp.z);
    dummy.rotation.set(0, sp.rotY, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    seatsInstanced.setMatrixAt(i, dummy.matrix);
    seatsInstanced.setColorAt(i, sp.color);
  }
  seatsInstanced.instanceMatrix.needsUpdate = true;
  if (seatsInstanced.instanceColor) seatsInstanced.instanceColor.needsUpdate = true;
  seatsInstanced.computeBoundingSphere();
  group.add(seatsInstanced);
  console.info(`[Stadium Structure] Built ${seatPlacements.length.toLocaleString()} two-tier seats.`);

  // Stairway treads (InstancedMesh)
  const stairGeo = new THREE.BoxGeometry(0.62, 0.16, 0.78);
  const stairMat = new THREE.MeshStandardMaterial({ color: '#94A3B8', roughness: 0.85 });
  const stairsMesh = new THREE.InstancedMesh(stairGeo, stairMat, stairSlots.length);
  for (let i = 0; i < stairSlots.length; i++) {
    const st = stairSlots[i];
    dummy.position.set(st.x, st.y + 0.04, st.z);
    dummy.rotation.set(0, st.rotY, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    stairsMesh.setMatrixAt(i, dummy.matrix);
  }
  stairsMesh.instanceMatrix.needsUpdate = true;
  stairsMesh.computeBoundingSphere();
  group.add(stairsMesh);

  // Dark Vomitory Tunnel Portals in Tier 1
  const vomSamples = sampleOvalBySpacing(bowlInnerR + 6 * S.rowDepth, seatPitch);
  const vomStep = Math.max(48, Math.round(vomSamples.length / 10));
  for (let i = 1; i < vomSamples.length; i += vomStep) {
    const vs = vomSamples[i];
    const portal = new THREE.Mesh(new THREE.BoxGeometry(2.6, 2.2, 2.8), darkSteelMat);
    portal.position.set(vs.x, tier1StartY + 6 * S.rowRise + 0.8, vs.z);
    portal.rotation.y = vs.rotY;
    group.add(portal);
  }

  // VIP / Media / WSTV Commentary Box overlooking Home Straight (+Z)
  const vipBoxGroup = new THREE.Group();
  vipBoxGroup.position.set(0, tier2StartY + 1.8, tier2InnerR + 2.6);
  const vipStructure = new THREE.Mesh(new THREE.BoxGeometry(34, 4.4, 5.2), darkSteelMat);
  vipBoxGroup.add(vipStructure);
  const vipGlass = new THREE.Mesh(new THREE.BoxGeometry(33.2, 3.1, 0.25), glassMat);
  vipGlass.position.set(0, 0.2, -2.55);
  vipBoxGroup.add(vipGlass);
  const vipWstvFascia = new THREE.Mesh(
    new THREE.PlaneGeometry(14, 1.3),
    new THREE.MeshBasicMaterial({ map: wstvTex })
  );
  vipWstvFascia.position.set(0, -1.55, -2.7);
  vipWstvFascia.rotation.y = Math.PI;
  vipBoxGroup.add(vipWstvFascia);
  group.add(vipBoxGroup);

  // Giant Pacifica Regional Olympics Mosaic Banner on North Grandstand Upper Tier
  const standsBanner = new THREE.Mesh(
    new THREE.PlaneGeometry(24, 14),
    new THREE.MeshStandardMaterial({ map: pacificaTex, roughness: 0.65 })
  );
  standsBanner.position.set(0, tier2StartY + 7.5, -(tier2InnerR + 7.5));
  standsBanner.rotation.x = -0.32;
  group.add(standsBanner);

  // ============================================================================
  // 2. SWEEPING WAVE WHITE ROOF CANOPY + STEEL MASTS + TENSILE CABLES
  // ============================================================================
  buildWaveRoofCanopy(group, tier2InnerR, tier2OuterR, tier2TopY, whiteSteelMat, darkSteelMat, goldTrimMat);

  // ============================================================================
  // 3. EXTERIOR WHITE/STEEL FACADE, GLASS CONCOURSE & ROYAL-BLUE/GOLD STRIPS
  // ============================================================================
  buildExteriorFacade(
    group,
    tier2OuterR + 0.5,
    tier2TopY + 1.8,
    whiteSteelMat,
    royalBlueWallMat,
    goldTrimMat,
    glassMat,
    pacificaTex,
    wstvTex
  );

  // ============================================================================
  // 4. GRAND ENTRANCE PLAZA, PALM TREES, FLAGPOLES & CEREMONIAL TORCH CAULDRON
  // ============================================================================
  const updateFlame = buildEntrancePlazaAndTorch(
    group,
    tier2OuterR,
    concreteMat,
    whiteSteelMat,
    goldTrimMat,
    flagTex
  );

  // ============================================================================
  // 5. PERIMETER ADVERTISING BOARDS & INFIELD PROPS / CAMERAS
  // ============================================================================
  buildPerimeterAdBoards(
    group,
    OUTER_TRACK_RADIUS + STADIUM_CONFIG.track.outerApronWidth + 0.45,
    adPacificaTex,
    adPleadlandTex,
    adWstvTex,
    darkSteelMat
  );
  buildBroadcastAndInfieldProps(
    group,
    whiteSteelMat,
    darkSteelMat,
    royalBlueWallMat,
    goldTrimMat,
    wstvTex
  );

  // ============================================================================
  // 6. VIDEO BOARDS & RING SCOREBOARD (4 Live Switchable BoardScreens)
  // ============================================================================
  // A) Ring Board (360° closed LED fascia ribbon along Tier 2 front edge)
  const ringGeo = buildExtrudedOvalWall(tier2InnerR - 0.35, tier2StartY - 1.55, tier2StartY - 0.05, 96);
  const ringScreen = new BoardScreen({
    name: 'ringBoard',
    canvasWidth: 2048,
    canvasHeight: 128,
    worldWidth: 1,
    worldHeight: 1.5,
    maxAnisotropy,
    isRing: true,
    geometry: ringGeo,
    repeatX: 10,
  });
  group.add(ringScreen.mesh);
  boardManager.register(ringScreen);

  // B) East End LED Video Board (+X end above bowl, facing -X)
  const eastBoard = createFramedVideoBoard('eastBoard', 24, 12, maxAnisotropy, darkSteelMat, goldTrimMat);
  eastBoard.holder.position.set(HALF_STRAIGHT + tier2InnerR + 2.5, tier2TopY + 6.5, 0);
  eastBoard.holder.rotation.y = -Math.PI / 2;
  group.add(eastBoard.holder);
  boardManager.register(eastBoard.screen);

  // C) West End LED Video Board (-X end above bowl, facing +X)
  const westBoard = createFramedVideoBoard('westBoard', 24, 12, maxAnisotropy, darkSteelMat, goldTrimMat);
  westBoard.holder.position.set(-(HALF_STRAIGHT + tier2InnerR + 2.5), tier2TopY + 6.5, 0);
  westBoard.holder.rotation.y = Math.PI / 2;
  group.add(westBoard.holder);
  boardManager.register(westBoard.screen);

  // D) Main Hero Scoreboard (elevated above North-East rim facing Home Straight)
  const mainBoard = createFramedVideoBoard('mainScoreboard', 30, 15, maxAnisotropy, darkSteelMat, goldTrimMat);
  mainBoard.holder.position.set(34, tier2TopY + 9.2, -(tier2OuterR - 2));
  mainBoard.holder.lookAt(0, 8, 25);
  group.add(mainBoard.holder);
  boardManager.register(mainBoard.screen);

  const dispose = () => {
    group.traverse((obj) => {
      if (obj instanceof THREE.Mesh || obj instanceof THREE.InstancedMesh) {
        obj.geometry.dispose();
        if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
        else obj.material.dispose();
      }
    });
    flagTex.dispose();
    pacificaTex.dispose();
    wstvTex.dispose();
    adPacificaTex.dispose();
    adPleadlandTex.dispose();
    adWstvTex.dispose();
  };

  return {
    group,
    seatSlots,
    totalSeatsBuilt: seatPlacements.length,
    update: (elapsedSeconds: number) => {
      updateFlame(elapsedSeconds);
    },
    dispose,
  };
}

function createFramedVideoBoard(
  name: 'eastBoard' | 'westBoard' | 'mainScoreboard',
  worldWidth: number,
  worldHeight: number,
  maxAnisotropy: number,
  frameMat: THREE.Material,
  trimMat: THREE.Material
): { holder: THREE.Group; screen: BoardScreen } {
  const holder = new THREE.Group();
  holder.name = `BoardFrame_${name}`;

  const screen = new BoardScreen({
    name,
    canvasWidth: 1024,
    canvasHeight: 512,
    worldWidth,
    worldHeight,
    maxAnisotropy,
  });
  screen.mesh.position.z = 0.45;
  holder.add(screen.mesh);

  const backing = new THREE.Mesh(
    new THREE.BoxGeometry(worldWidth + 1.2, worldHeight + 1.2, 0.7),
    frameMat
  );
  holder.add(backing);

  const topTrim = new THREE.Mesh(
    new THREE.BoxGeometry(worldWidth + 1.4, 0.35, 0.85),
    trimMat
  );
  topTrim.position.y = worldHeight / 2 + 0.55;
  holder.add(topTrim);

  // Twin support pylons
  for (const sx of [-worldWidth * 0.32, worldWidth * 0.32]) {
    const pylon = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 11, 10), frameMat);
    pylon.position.set(sx, -worldHeight / 2 - 5.2, -0.2);
    holder.add(pylon);
  }

  return { holder, screen };
}

function buildWaveRoofCanopy(
  group: THREE.Group,
  tier2InnerR: number,
  tier2OuterR: number,
  tier2TopY: number,
  whiteMat: THREE.Material,
  darkMat: THREE.Material,
  goldMat: THREE.Material
): void {
  const S = STADIUM_CONFIG.stadium;
  const rInner = tier2InnerR - 3.5;
  const rOuter = tier2OuterR + 4.5;

  // Build two majestic sweeping wave wings (South +Z and North -Z), each spanning ~134° around the oval
  const createCanopyWing = (sideSign: 1 | -1) => {
    const uSegs = 64;
    const vSegs = 10;
    const positions: number[] = [];
    const indices: number[] = [];

    const edgeInnerPts: THREE.Vector3[] = [];
    const edgeMidPts: THREE.Vector3[] = [];
    const edgeOuterPts: THREE.Vector3[] = [];

    for (let i = 0; i <= uSegs; i++) {
      const u = i / uSegs; // 0..1 across wing span
      // Sweeping arch amplitude: tallest at midpoint (u=0.5), gracefully sloping down to curved shoulders
      const arch = Math.sin(u * Math.PI);
      const yInner = tier2TopY + 5.0 + arch * 9.5;
      const yOuter = tier2TopY + 2.2 + arch * 6.0;

      // Parametric angle spanning from -1.16*PI/2 to +1.16*PI/2 mapped smoothly onto oval contour
      const theta = (u - 0.5) * Math.PI * 0.92;
      const xBase = Math.sin(theta) * (HALF_STRAIGHT + 26);

      for (let j = 0; j <= vSegs; j++) {
        const v = j / vSegs; // 0 = inner edge, 1 = outer edge
        const r = rInner + v * (rOuter - rInner);
        // Oval-consistent Z offset at xBase
        let zLocal = r;
        if (Math.abs(xBase) > HALF_STRAIGHT) {
          const dx = Math.abs(xBase) - HALF_STRAIGHT;
          zLocal = Math.sqrt(Math.max(4, r * r - dx * dx));
        }
        const z = sideSign * zLocal;
        const y = yInner + v * (yOuter - yInner) + Math.sin(v * Math.PI) * 1.1;

        positions.push(xBase, y, z);
        if (j === 0) edgeInnerPts.push(new THREE.Vector3(xBase, y, z));
        if (j === Math.floor(vSegs * 0.55)) edgeMidPts.push(new THREE.Vector3(xBase, y, z));
        if (j === vSegs) edgeOuterPts.push(new THREE.Vector3(xBase, y, z));
      }
    }

    const rowStride = vSegs + 1;
    for (let i = 0; i < uSegs; i++) {
      for (let j = 0; j < vSegs; j++) {
        const a = i * rowStride + j;
        const b = a + 1;
        const c = (i + 1) * rowStride + j;
        const d = c + 1;
        if (sideSign > 0) indices.push(a, c, b, b, c, d);
        else indices.push(a, b, c, b, d, c);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setIndex(indices);
    geo.computeVertexNormals();

    const canopyMesh = new THREE.Mesh(
      geo,
      new THREE.MeshStandardMaterial({
        color: '#F8FAFC',
        roughness: 0.35,
        metalness: 0.25,
        side: THREE.DoubleSide,
      })
    );
    canopyMesh.castShadow = true;
    canopyMesh.name = sideSign > 0 ? 'RoofCanopySouth' : 'RoofCanopyNorth';
    group.add(canopyMesh);

    // Structural underside ribs every 4th segment
    for (let i = 0; i <= uSegs; i += 4) {
      const pIn = edgeInnerPts[i];
      const pOut = edgeOuterPts[i];
      const rib = createStrutBetween(pIn, pOut, 0.26, whiteMat);
      group.add(rib);
    }

    // Gold LED strip along inner roof rim
    for (let i = 0; i < uSegs; i += 2) {
      const p1 = edgeInnerPts[i];
      const p2 = edgeInnerPts[Math.min(uSegs, i + 2)];
      const rimBar = createStrutBetween(p1, p2, 0.2, goldMat);
      group.add(rimBar);
    }

    // Slim Angled Steel Masts + Tensile Stay Cables
    for (let m = 0; m < S.mastCountPerSide; m++) {
      const idx = Math.round(((m + 0.5) / S.mastCountPerSide) * uSegs);
      const pOut = edgeOuterPts[idx];
      const pMid = edgeMidPts[idx];
      const pIn = edgeInnerPts[idx];

      const base = new THREE.Vector3(pOut.x, 0, pOut.z + sideSign * 3.5);
      const top = new THREE.Vector3(pOut.x, S.mastHeight, pOut.z + sideSign * 1.2);

      const mast = createStrutBetween(base, top, 0.42, whiteMat);
      mast.castShadow = true;
      group.add(mast);

      // Tensile stay cables from mast top to inner edge, mid roof, and outer anchor
      group.add(createStrutBetween(top, pIn, 0.06, darkMat));
      group.add(createStrutBetween(top, pMid, 0.06, darkMat));
      group.add(createStrutBetween(top, new THREE.Vector3(base.x, 0.5, base.z + sideSign * 8), 0.055, darkMat));
    }
  };

  createCanopyWing(1);
  createCanopyWing(-1);
}

function createStrutBetween(
  a: THREE.Vector3,
  b: THREE.Vector3,
  radius: number,
  mat: THREE.Material
): THREE.Mesh {
  const dir = new THREE.Vector3().subVectors(b, a);
  const len = dir.length();
  const geo = new THREE.CylinderGeometry(radius, radius * 1.1, Math.max(0.05, len), 8);
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.copy(a).addScaledVector(dir, 0.5);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  return mesh;
}

function buildExteriorFacade(
  group: THREE.Group,
  outerR: number,
  wallHeight: number,
  whiteMat: THREE.Material,
  blueMat: THREE.Material,
  goldMat: THREE.Material,
  glassMat: THREE.Material,
  pacificaTex: THREE.Texture,
  wstvTex: THREE.Texture
): void {
  // Royal blue lower facade band & gold illuminated trim strips
  const blueBand = new THREE.Mesh(
    buildExtrudedOvalWall(outerR + 0.15, 7.5, 13.5, 72),
    blueMat
  );
  const glassConcourse = new THREE.Mesh(
    buildExtrudedOvalWall(outerR + 0.12, 0.5, 7.4, 72),
    glassMat
  );
  const goldStripLow = new THREE.Mesh(
    buildExtrudedOvalWall(outerR + 0.25, 7.3, 7.75, 72),
    goldMat
  );
  const goldStripHigh = new THREE.Mesh(
    buildExtrudedOvalWall(outerR + 0.25, wallHeight - 0.6, wallHeight, 72),
    goldMat
  );
  group.add(blueBand, glassConcourse, goldStripLow, goldStripHigh);

  // Exterior architectural fins wrapping 360°
  const finSamples = sampleOvalBySpacing(outerR + 0.6, 8.2);
  const finGeo = new THREE.BoxGeometry(0.55, wallHeight + 0.8, 2.2);
  const finInstanced = new THREE.InstancedMesh(finGeo, whiteMat, finSamples.length);
  const dummy = new THREE.Object3D();
  finSamples.forEach((s, i) => {
    dummy.position.set(s.x, (wallHeight + 0.8) / 2, s.z);
    dummy.rotation.set(0, s.rotY, 0);
    dummy.updateMatrix();
    finInstanced.setMatrixAt(i, dummy.matrix);
  });
  finInstanced.instanceMatrix.needsUpdate = true;
  group.add(finInstanced);

  // Hero exterior branding panels (Pacifica emblem + WSTV) on South-West entrance side
  const extEmblem = new THREE.Mesh(
    new THREE.PlaneGeometry(14, 14),
    new THREE.MeshStandardMaterial({ map: pacificaTex, roughness: 0.45 })
  );
  extEmblem.position.set(-28, 14.5, outerR + 1.2);
  group.add(extEmblem);

  const extWstv = new THREE.Mesh(
    new THREE.PlaneGeometry(16, 8),
    new THREE.MeshStandardMaterial({ map: wstvTex, roughness: 0.4 })
  );
  extWstv.position.set(22, 13.5, outerR + 1.2);
  group.add(extWstv);
}

function buildEntrancePlazaAndTorch(
  group: THREE.Group,
  tier2OuterR: number,
  concreteMat: THREE.Material,
  whiteMat: THREE.Material,
  goldMat: THREE.Material,
  flagTex: THREE.Texture
): (elapsed: number) => void {
  // Paved South-West Grand Entrance Plaza
  const plaza = new THREE.Mesh(
    new THREE.BoxGeometry(145, 0.22, 56),
    new THREE.MeshStandardMaterial({ color: '#CBD5E1', roughness: 0.85 })
  );
  plaza.position.set(-18, -0.02, tier2OuterR + 28);
  plaza.receiveShadow = true;
  group.add(plaza);

  // Ceremonial Olympic Torch Cauldron Monument (South-West corner, matching Exterior ref)
  const torchPos = new THREE.Vector3(-82, 0, tier2OuterR + 14);
  const torchGroup = new THREE.Group();
  torchGroup.position.copy(torchPos);

  for (let s = 0; s < 3; s++) {
    const step = new THREE.Mesh(
      new THREE.BoxGeometry(10 - s * 2, 0.55, 10 - s * 2),
      concreteMat
    );
    step.position.y = 0.275 + s * 0.55;
    torchGroup.add(step);
  }

  const pedestal = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 2.6, 10.5, 6), whiteMat);
  pedestal.position.y = 6.8;
  pedestal.castShadow = true;
  torchGroup.add(pedestal);

  const bowl = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 1.4, 1.9, 16), goldMat);
  bowl.position.y = 12.6;
  torchGroup.add(bowl);

  // Animated Cauldron Particle Flame
  const flameCount = 54;
  const flamePos = new Float32Array(flameCount * 3);
  const flameSeeds = new Float32Array(flameCount);
  for (let i = 0; i < flameCount; i++) {
    flameSeeds[i] = Math.random();
    flamePos[i * 3] = (Math.random() - 0.5) * 1.4;
    flamePos[i * 3 + 1] = 13.4 + Math.random() * 4.5;
    flamePos[i * 3 + 2] = (Math.random() - 0.5) * 1.4;
  }
  const flameGeo = new THREE.BufferGeometry();
  flameGeo.setAttribute('position', new THREE.BufferAttribute(flamePos, 3));
  const flameMat = new THREE.PointsMaterial({
    color: '#FF9E1B',
    size: 1.65,
    transparent: true,
    opacity: 0.85,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const flamePts = new THREE.Points(flameGeo, flameMat);
  torchGroup.add(flamePts);

  const coreFlame = new THREE.Mesh(
    new THREE.ConeGeometry(1.45, 4.4, 10),
    new THREE.MeshBasicMaterial({ color: '#FDBA74', transparent: true, opacity: 0.88 })
  );
  coreFlame.position.y = 15.2;
  torchGroup.add(coreFlame);

  const torchLight = new THREE.PointLight('#FF9E2C', 45, 45);
  torchLight.position.y = 15.5;
  torchGroup.add(torchLight);
  group.add(torchGroup);

  // Row of 8 Flagpoles flying New Pleadland flags
  const poleMat = new THREE.MeshStandardMaterial({ color: '#E2E8F0', metalness: 0.8, roughness: 0.2 });
  const plazaFlagMat = new THREE.MeshStandardMaterial({
    map: flagTex,
    side: THREE.DoubleSide,
    roughness: 0.6,
  });
  for (let i = 0; i < STADIUM_CONFIG.stadium.plazaFlagCount; i++) {
    const fx = -64 + i * 7.5;
    const fz = tier2OuterR + 18;
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 11.5, 8), poleMat);
    pole.position.set(fx, 5.75, fz);
    group.add(pole);

    const flag = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 2.0), plazaFlagMat);
    flag.position.set(fx + 1.65, 10.3, fz);
    group.add(flag);
  }

  // Landscaped Green Planter Beds + Instanced Palm Trees around Plaza
  const planterMat = new THREE.MeshStandardMaterial({ color: '#1F5C30', roughness: 0.92 });
  [
    [-46, tier2OuterR + 36, 36, 12],
    [4, tier2OuterR + 36, 42, 12],
    [-98, tier2OuterR + 4, 14, 34],
  ].forEach(([px, pz, pw, pd]) => {
    const bed = new THREE.Mesh(new THREE.BoxGeometry(pw, 0.45, pd), planterMat);
    bed.position.set(px, 0.22, pz);
    group.add(bed);
  });

  // Procedural Palm Trees (InstancedMesh trunks + foliage crowns)
  const palmCount = STADIUM_CONFIG.stadium.palmTreeCount;
  const trunkGeo = new THREE.CylinderGeometry(0.22, 0.36, 8.5, 7);
  trunkGeo.translate(0, 4.25, 0);
  const trunkMat = new THREE.MeshStandardMaterial({ color: '#6B4C35', roughness: 0.9 });
  const crownGeo = new THREE.ConeGeometry(3.2, 2.6, 7);
  crownGeo.scale(1, -0.65, 1);
  crownGeo.translate(0, 8.8, 0);
  const crownMat = new THREE.MeshStandardMaterial({ color: '#2B7A3B', roughness: 0.85 });

  const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, palmCount);
  const crowns = new THREE.InstancedMesh(crownGeo, crownMat, palmCount);
  const dummy = new THREE.Object3D();

  for (let i = 0; i < palmCount; i++) {
    let px = 0;
    let pz = 0;
    if (i < 24) {
      px = -105 + i * 8.5;
      pz = tier2OuterR + 38 + (i % 2) * 8;
    } else {
      const a = ((i - 24) / (palmCount - 24)) * Math.PI * 2;
      px = Math.cos(a) * (HALF_STRAIGHT + tier2OuterR + 24);
      pz = Math.sin(a) * (tier2OuterR + 22);
    }
    const scale = 0.82 + (i % 5) * 0.1;
    dummy.position.set(px, 0, pz);
    dummy.rotation.set(0, i * 1.1, (i % 3 - 1) * 0.04);
    dummy.scale.setScalar(scale);
    dummy.updateMatrix();
    trunks.setMatrixAt(i, dummy.matrix);
    crowns.setMatrixAt(i, dummy.matrix);
  }
  trunks.instanceMatrix.needsUpdate = true;
  crowns.instanceMatrix.needsUpdate = true;
  group.add(trunks, crowns);

  return (elapsed: number) => {
    const posAttr = flameGeo.attributes.position as THREE.BufferAttribute;
    const arr = posAttr.array as Float32Array;
    for (let i = 0; i < flameCount; i++) {
      const phase = (elapsed * 1.8 + flameSeeds[i]) % 1;
      const spread = (1 - phase) * 1.3;
      arr[i * 3] = Math.sin(elapsed * 5 + i) * spread * 0.65;
      arr[i * 3 + 1] = 13.4 + phase * 4.8;
      arr[i * 3 + 2] = Math.cos(elapsed * 4.3 + i * 1.7) * spread * 0.65;
    }
    posAttr.needsUpdate = true;
    coreFlame.scale.set(
      1 + Math.sin(elapsed * 11) * 0.1,
      1 + Math.cos(elapsed * 9) * 0.14,
      1 + Math.sin(elapsed * 10) * 0.1
    );
    torchLight.intensity = 42 + Math.sin(elapsed * 13) * 8;
  };
}

function buildPerimeterAdBoards(
  group: THREE.Group,
  r: number,
  texPacifica: THREE.Texture,
  texPleadland: THREE.Texture,
  texWstv: THREE.Texture,
  backMat: THREE.Material
): void {
  const boardSamples = sampleOvalBySpacing(r, 7.2);
  const mats = [
    new THREE.MeshStandardMaterial({ map: texPacifica, roughness: 0.4 }),
    new THREE.MeshStandardMaterial({ map: texPleadland, roughness: 0.4 }),
    new THREE.MeshStandardMaterial({ map: texWstv, roughness: 0.4 }),
  ];

  const boardGeo = new THREE.BoxGeometry(6.6, 1.05, 0.16);
  boardSamples.forEach((s, idx) => {
    // Leave clean opening at Finish Line for camera sightline
    if (s.z > 0 && Math.abs(s.x - HALF_STRAIGHT) < 3.6) return;
    const faceMat = mats[idx % mats.length];
    const panel = new THREE.Mesh(boardGeo, [
      backMat,
      backMat,
      backMat,
      backMat,
      faceMat,
      backMat,
    ]);
    panel.position.set(s.x, 0.54, s.z);
    panel.rotation.y = s.rotY;
    group.add(panel);
  });
}

function buildBroadcastAndInfieldProps(
  group: THREE.Group,
  whiteMat: THREE.Material,
  darkMat: THREE.Material,
  blueMat: THREE.Material,
  goldMat: THREE.Material,
  wstvTex: THREE.Texture
): void {
  const yTurf = STADIUM_CONFIG.track.infieldTurfY;
  const yTrack = STADIUM_CONFIG.track.trackSurfaceY;

  // 1. Infield Canopy Tents (3 neat tents at turf edges, keeping center Pacifica emblem clear)
  const tentCoords: [number, number, string][] = [
    [26, 20, '#0033A0'],
    [-27, 20, '#F8FAFC'],
    [-24, -15, '#D4AF37'],
  ];
  tentCoords.forEach(([tx, tz, roofCol]) => {
    const tent = new THREE.Group();
    tent.position.set(tx, yTurf, tz);
    for (const lx of [-2.2, 2.2]) {
      for (const lz of [-2.2, 2.2]) {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.5, 6), whiteMat);
        leg.position.set(lx, 1.25, lz);
        tent.add(leg);
      }
    }
    const canopy = new THREE.Mesh(
      new THREE.ConeGeometry(3.4, 1.35, 4),
      new THREE.MeshStandardMaterial({ color: roofCol, roughness: 0.7 })
    );
    canopy.rotation.y = Math.PI / 4;
    canopy.position.y = 3.1;
    canopy.castShadow = true;
    tent.add(canopy);
    group.add(tent);
  });

  // 2. Officials' Tables & Chairs on Infield
  const tableCoords: [number, number][] = [
    [12, 13.5],
    [-16, -12.5],
  ];
  tableCoords.forEach(([tx, tz]) => {
    const top = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.1, 1.4), whiteMat);
    top.position.set(tx, yTurf + 0.78, tz);
    const base = new THREE.Mesh(new THREE.BoxGeometry(3.8, 0.74, 1.1), blueMat);
    base.position.set(tx, yTurf + 0.37, tz);
    group.add(top, base);
  });

  // 3. Trackside Camera Rails along Home Straight (+Z)
  const railLen = 68;
  const railZ = KERB_RADIUS - 3.2;
  const railLeft = new THREE.Mesh(new THREE.BoxGeometry(railLen, 0.14, 0.12), darkMat);
  railLeft.position.set(0, yTurf + 0.08, railZ);
  const railRight = new THREE.Mesh(new THREE.BoxGeometry(railLen, 0.14, 0.12), darkMat);
  railRight.position.set(0, yTurf + 0.08, railZ - 0.55);
  const dolly = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.35, 0.9), darkMat);
  dolly.position.set(16, yTurf + 0.32, railZ - 0.27);
  const dollyBanner = new THREE.Mesh(
    new THREE.PlaneGeometry(1.2, 0.6),
    new THREE.MeshBasicMaterial({ map: wstvTex })
  );
  dollyBanner.position.set(16, yTurf + 0.35, railZ + 0.2);
  group.add(railLeft, railRight, dolly, dollyBanner);

  // 4. Static Broadcast Camera Jib / Crane near Home Straight Finish
  const crane = new THREE.Group();
  crane.position.set(HALF_STRAIGHT + 11, yTrack, OUTER_TRACK_RADIUS + 3.4);
  const craneBase = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.65, 1.6), darkMat);
  craneBase.position.y = 0.33;
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 2.4, 8), darkMat);
  mast.position.y = 1.5;
  const boom = new THREE.Mesh(new THREE.BoxGeometry(8.5, 0.2, 0.2), goldMat);
  boom.position.set(-2.5, 3.6, -1.5);
  boom.rotation.set(0.18, -0.35, -0.25);
  const camHead = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.4, 0.65), darkMat);
  camHead.position.set(-6.0, 4.6, -2.9);
  crane.add(craneBase, mast, boom, camHead);
  group.add(crane);

  // 5. Elevated Camera Platforms on East & West Apron
  [
    [HALF_STRAIGHT + 12, yTrack, 12],
    [-HALF_STRAIGHT - 12, yTrack, -12],
  ].forEach(([px, py, pz]) => {
    const plat = new THREE.Mesh(new THREE.BoxGeometry(2.6, 1.4, 2.6), darkMat);
    plat.position.set(px, py + 0.7, pz);
    const wstvSign = new THREE.Mesh(
      new THREE.PlaneGeometry(2.4, 1.1),
      new THREE.MeshBasicMaterial({ map: wstvTex, side: THREE.DoubleSide })
    );
    wstvSign.position.set(px, py + 0.75, pz + 1.32);
    group.add(plat, wstvSign);
  });
}
