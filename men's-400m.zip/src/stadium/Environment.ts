import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { STADIUM_CONFIG, TimeOfDay } from '../config';

export class StadiumEnvironment {
  public readonly group = new THREE.Group();
  private skyMat: THREE.ShaderMaterial;
  private oceanMesh: THREE.Mesh;
  private oceanGeo: THREE.PlaneGeometry;
  private oceanBasePos: Float32Array;
  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private rimLight: THREE.DirectionalLight;
  private towerLights: THREE.SpotLight[] = [];
  private floodBeamMeshes: THREE.Mesh[] = [];
  private floodPanelMats: THREE.MeshStandardMaterial[] = [];
  private pmremRT: THREE.WebGLRenderTarget | null = null;
  private fog: THREE.FogExp2;
  private scene: THREE.Scene;

  constructor(scene: THREE.Scene, renderer: THREE.WebGLRenderer, isSoftwareGl: boolean) {
    this.scene = scene;
    this.group.name = 'StadiumEnvironment';
    const C = STADIUM_CONFIG.colors;

    // 1. Subtle atmospheric fog matched to horizon
    this.fog = new THREE.FogExp2(C.skyDayHorizon, 0.00085);
    scene.fog = this.fog;

    // 2. Procedural Sky Dome Shader
    this.skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        uTopColor: { value: new THREE.Color(C.skyDayTop) },
        uHorizonColor: { value: new THREE.Color(C.skyDayHorizon) },
        uSunDir: { value: new THREE.Vector3(-0.6, 0.45, -0.5).normalize() },
        uSunColor: { value: new THREE.Color('#FFF6D6') },
        uSunGlow: { value: 0.35 },
      },
      vertexShader: `
        varying vec3 vWorldDir;
        void main() {
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorldDir = normalize(position);
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: `
        uniform vec3 uTopColor;
        uniform vec3 uHorizonColor;
        uniform vec3 uSunDir;
        uniform vec3 uSunColor;
        uniform float uSunGlow;
        varying vec3 vWorldDir;
        void main() {
          float h = clamp(vWorldDir.y, 0.0, 1.0);
          vec3 col = mix(uHorizonColor, uTopColor, pow(h, 0.52));
          float sunAmt = max(0.0, dot(normalize(vWorldDir), normalize(uSunDir)));
          col += uSunColor * pow(sunAmt, 24.0) * uSunGlow;
          col += uSunColor * smoothstep(0.996, 0.9992, sunAmt) * (uSunGlow * 1.8);
          gl_FragColor = vec4(col, 1.0);
        }
      `,
    });
    const skyDome = new THREE.Mesh(new THREE.SphereGeometry(980, 32, 20), this.skyMat);
    skyDome.name = 'SkyDome';
    this.group.add(skyDome);

    // 3. Ground Plane & Coastal Pacific Ocean Horizon
    const coastalGround = new THREE.Mesh(
      new THREE.CircleGeometry(960, 64),
      new THREE.MeshStandardMaterial({ color: '#334155', roughness: 0.92, metalness: 0.04 })
    );
    coastalGround.rotation.x = -Math.PI / 2;
    coastalGround.position.y = -0.18;
    coastalGround.receiveShadow = true;
    this.group.add(coastalGround);

    // Distant lush tropical green coastal belt
    const coastalGreen = new THREE.Mesh(
      new THREE.RingGeometry(168, 420, 48),
      new THREE.MeshStandardMaterial({ color: '#275E38', roughness: 0.95 })
    );
    coastalGreen.rotation.x = -Math.PI / 2;
    coastalGreen.position.y = -0.12;
    this.group.add(coastalGreen);

    // Pacific Ocean horizon stretching north/east (-Z)
    this.oceanGeo = new THREE.PlaneGeometry(1800, 720, 44, 18);
    this.oceanGeo.rotateX(-Math.PI / 2);
    this.oceanBasePos = new Float32Array(this.oceanGeo.attributes.position.array);
    const oceanMat = new THREE.MeshStandardMaterial({
      color: C.oceanDay,
      roughness: 0.22,
      metalness: 0.62,
    });
    this.oceanMesh = new THREE.Mesh(this.oceanGeo, oceanMat);
    this.oceanMesh.position.set(0, -0.05, -560);
    this.oceanMesh.name = 'PacificOceanHorizon';
    this.group.add(this.oceanMesh);

    // 4. Studio/Outdoor PMREM IBL Environment (skip heavy PMREM compile on software WebGL)
    if (!isSoftwareGl) {
      const pmrem = new THREE.PMREMGenerator(renderer);
      const roomEnv = new RoomEnvironment();
      this.pmremRT = pmrem.fromScene(roomEnv, 0.04);
      scene.environment = this.pmremRT.texture;
      scene.environmentIntensity = 0.5;
      roomEnv.dispose();
      pmrem.dispose();
    }

    // 5. Three-Point Outdoor Lighting Rig
    this.hemiLight = new THREE.HemisphereLight('#DBEAFE', '#1E3A2A', 0.95);
    this.group.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight('#FFF8E7', 2.4);
    this.sunLight.position.set(-140, 110, 95);
    if (!isSoftwareGl) {
      this.sunLight.castShadow = true;
      this.sunLight.shadow.mapSize.set(2048, 2048);
      this.sunLight.shadow.camera.near = 20;
      this.sunLight.shadow.camera.far = 420;
      const d = 145;
      this.sunLight.shadow.camera.left = -d;
      this.sunLight.shadow.camera.right = d;
      this.sunLight.shadow.camera.top = d;
      this.sunLight.shadow.camera.bottom = -d;
      this.sunLight.shadow.bias = -0.0005;
      this.sunLight.shadow.normalBias = 0.03;
    }
    this.group.add(this.sunLight);

    this.rimLight = new THREE.DirectionalLight('#93C5FD', 0.75);
    this.rimLight.position.set(130, 65, -110);
    this.group.add(this.rimLight);

    // 6. Four Corner Floodlight Towers with LED Banks & Soft Beams
    this.buildFloodlightTowers();

    this.setTimeOfDay('sunset');
  }

  private buildFloodlightTowers(): void {
    const H = STADIUM_CONFIG.stadium.floodlightHeight;
    const steelMat = new THREE.MeshStandardMaterial({
      color: '#CBD5E1',
      metalness: 0.75,
      roughness: 0.28,
    });
    const darkMat = new THREE.MeshStandardMaterial({
      color: '#0F172A',
      metalness: 0.65,
      roughness: 0.35,
    });

    const towerCoords: [number, number][] = [
      [114, -76],
      [-114, -76],
      [114, 76],
      [-114, 76],
    ];

    towerCoords.forEach(([tx, tz], idx) => {
      const tower = new THREE.Group();
      tower.position.set(tx, 0, tz);
      tower.lookAt(0, 8, 0);

      // Tapered mast
      const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 1.35, H, 12), steelMat);
      mast.position.y = H / 2;
      tower.add(mast);

      // Cross-frame LED bank
      const frame = new THREE.Mesh(new THREE.BoxGeometry(10.5, 5.2, 1.2), darkMat);
      frame.position.set(0, H + 1.5, 0);
      tower.add(frame);

      const ledMat = new THREE.MeshStandardMaterial({
        color: '#FFFFFF',
        emissive: '#FFF7E0',
        emissiveIntensity: 1.4,
        roughness: 0.2,
      });
      this.floodPanelMats.push(ledMat);
      const ledFace = new THREE.Mesh(new THREE.PlaneGeometry(9.6, 4.4), ledMat);
      ledFace.position.set(0, H + 1.5, 0.65);
      tower.add(ledFace);

      // Volumetric-style soft light beam cone (additive, visible in sunset/night)
      const beamGeo = new THREE.ConeGeometry(28, 125, 20, 1, true);
      beamGeo.translate(0, -62.5, 0);
      beamGeo.rotateX(-Math.PI / 2);
      const beamMat = new THREE.MeshBasicMaterial({
        color: '#E0F2FE',
        transparent: true,
        opacity: 0.045,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
      });
      const beam = new THREE.Mesh(beamGeo, beamMat);
      beam.position.set(0, H + 1.2, 0.8);
      beam.lookAt(tower.worldToLocal(new THREE.Vector3(0, 0, 0)));
      tower.add(beam);
      this.floodBeamMeshes.push(beam);

      // Real SpotLight onto infield
      const spot = new THREE.SpotLight('#FFF8EC', 0, 260, Math.PI * 0.28, 0.65, 1.1);
      spot.position.set(tx, H + 1.2, tz);
      spot.target.position.set(idx % 2 === 0 ? 18 : -18, 0, idx < 2 ? -10 : 10);
      this.group.add(spot, spot.target);
      this.towerLights.push(spot);

      this.group.add(tower);
    });
  }

  public setTimeOfDay(tod: TimeOfDay): void {
    const C = STADIUM_CONFIG.colors;
    const oceanMat = this.oceanMesh.material as THREE.MeshStandardMaterial;

    if (tod === 'day') {
      this.skyMat.uniforms.uTopColor.value.set(C.skyDayTop);
      this.skyMat.uniforms.uHorizonColor.value.set(C.skyDayHorizon);
      this.skyMat.uniforms.uSunDir.value.set(-0.45, 0.68, 0.35).normalize();
      this.skyMat.uniforms.uSunColor.value.set('#FFFBE6');
      this.skyMat.uniforms.uSunGlow.value = 0.28;
      this.fog.color.set(C.skyDayHorizon);
      this.fog.density = 0.00065;
      oceanMat.color.set(C.oceanDay);

      this.sunLight.position.set(-110, 145, 85);
      this.sunLight.color.set('#FFFBEB');
      this.sunLight.intensity = 2.65;
      this.hemiLight.color.set('#E0F2FE');
      this.hemiLight.groundColor.set('#22442D');
      this.hemiLight.intensity = 1.05;
      this.rimLight.intensity = 0.65;
      this.scene.environmentIntensity = 0.55;

      this.towerLights.forEach((l) => (l.intensity = 0));
      this.floodBeamMeshes.forEach((b) => (b.visible = false));
      this.floodPanelMats.forEach((m) => (m.emissiveIntensity = 0.4));
    } else if (tod === 'sunset') {
      this.skyMat.uniforms.uTopColor.value.set(C.skySunsetTop);
      this.skyMat.uniforms.uHorizonColor.value.set(C.skySunsetHorizon);
      this.skyMat.uniforms.uSunDir.value.set(-0.78, 0.14, -0.58).normalize();
      this.skyMat.uniforms.uSunColor.value.set('#FDBA74');
      this.skyMat.uniforms.uSunGlow.value = 0.62;
      this.fog.color.set('#E8A682');
      this.fog.density = 0.0008;
      oceanMat.color.set(C.oceanSunset);

      this.sunLight.position.set(-160, 42, -110);
      this.sunLight.color.set('#FFD7AA');
      this.sunLight.intensity = 2.4;
      this.hemiLight.color.set('#FDE68A');
      this.hemiLight.groundColor.set('#1E293B');
      this.hemiLight.intensity = 0.85;
      this.rimLight.color.set('#60A5FA');
      this.rimLight.intensity = 0.9;
      this.scene.environmentIntensity = 0.45;

      this.towerLights.forEach((l) => (l.intensity = 420));
      this.floodBeamMeshes.forEach((b) => {
        b.visible = true;
        (b.material as THREE.MeshBasicMaterial).opacity = 0.045;
      });
      this.floodPanelMats.forEach((m) => (m.emissiveIntensity = 2.0));
    } else {
      // 'night'
      this.skyMat.uniforms.uTopColor.value.set(C.skyNightTop);
      this.skyMat.uniforms.uHorizonColor.value.set(C.skyNightHorizon);
      this.skyMat.uniforms.uSunDir.value.set(0.4, 0.5, -0.6).normalize();
      this.skyMat.uniforms.uSunColor.value.set('#93C5FD');
      this.skyMat.uniforms.uSunGlow.value = 0.08;
      this.fog.color.set(C.skyNightHorizon);
      this.fog.density = 0.00105;
      oceanMat.color.set(C.oceanNight);

      this.sunLight.position.set(90, 120, -100);
      this.sunLight.color.set('#93C5FD');
      this.sunLight.intensity = 0.65;
      this.hemiLight.color.set('#1E3A8A');
      this.hemiLight.groundColor.set('#020617');
      this.hemiLight.intensity = 0.55;
      this.rimLight.color.set('#38BDF8');
      this.rimLight.intensity = 0.7;
      this.scene.environmentIntensity = 0.28;

      this.towerLights.forEach((l) => (l.intensity = 1350));
      this.floodBeamMeshes.forEach((b) => {
        b.visible = true;
        (b.material as THREE.MeshBasicMaterial).opacity = 0.08;
      });
      this.floodPanelMats.forEach((m) => (m.emissiveIntensity = 3.2));
    }
  }

  public setShadowsEnabled(enabled: boolean): void {
    this.sunLight.castShadow = enabled;
  }

  public update(elapsedSeconds: number): void {
    // Gentle Pacific Ocean swell shimmer (lightweight vertex ripple)
    const pos = this.oceanGeo.attributes.position as THREE.BufferAttribute;
    const arr = pos.array as Float32Array;
    for (let i = 0; i < pos.count; i++) {
      const bx = this.oceanBasePos[i * 3];
      const bz = this.oceanBasePos[i * 3 + 2];
      arr[i * 3 + 1] = Math.sin(bx * 0.03 + elapsedSeconds * 1.1) * 0.25 +
        Math.cos(bz * 0.04 + elapsedSeconds * 0.85) * 0.2;
    }
    pos.needsUpdate = true;
  }

  public dispose(): void {
    this.group.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
        if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
        else obj.material.dispose();
      }
    });
    this.pmremRT?.dispose();
  }
}
