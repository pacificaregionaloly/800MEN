import React, { useState } from 'react';
import {
  Camera,
  ChevronDown,
  ChevronUp,
  Compass,
  Gauge,
  Monitor,
  Moon,
  Orbit,
  Route,
  Sun,
  Sunset,
  Tag,
  Users,
  Waves,
} from 'lucide-react';
import { StadiumAPI, StadiumJSONState } from '../api/StadiumAPI';
import { CameraPresetId, STADIUM_CONFIG, TimeOfDay } from '../config';
import { BoardsPanel } from './BoardsPanel';

interface StadiumHUDProps {
  api: StadiumAPI | null;
  state: StadiumJSONState;
  fps: number;
}

const PRESET_ORDER: CameraPresetId[] = [
  'exterior',
  'aerial',
  'overhead',
  'finishLine',
  'homeStraight',
  'backStraight',
  'standsView',
  'infield',
];

export const StadiumHUD: React.FC<StadiumHUDProps> = ({ api, state, fps }) => {
  const [dockOpen, setDockOpen] = useState(true);
  const [boardsOpen, setBoardsOpen] = useState(false);
  const [showFps, setShowFps] = useState(true);

  const timeOptions: { id: TimeOfDay; label: string; icon: React.ReactNode }[] = [
    { id: 'day', label: 'Day', icon: <Sun className="h-3.5 w-3.5" /> },
    { id: 'sunset', label: 'Sunset', icon: <Sunset className="h-3.5 w-3.5" /> },
    { id: 'night', label: 'Night', icon: <Moon className="h-3.5 w-3.5" /> },
  ];

  return (
    <div className="pointer-events-none fixed inset-0 z-20 flex flex-col justify-between p-3 sm:p-4">
      {/* Top Bar */}
      <header className="flex flex-wrap items-start justify-between gap-2">
        {/* Top-Left Brand & Self-Check Readout */}
        <div className="pointer-events-auto flex items-center gap-3 rounded-xl border border-[#d4af37]/45 bg-[#041029]/95 px-3.5 py-2 text-white shadow-xl">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#0033a0] font-display text-sm font-extrabold tracking-wider text-[#f5c542] ring-1 ring-[#f5c542]/50">
            WSTV
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display text-base sm:text-lg font-bold tracking-wide uppercase leading-none">
                {STADIUM_CONFIG.venue.name}
              </h1>
              <span className="rounded bg-[#0033a0] px-1.5 py-0.5 font-mono text-[10px] font-semibold text-[#f5c542]">
                2026
              </span>
            </div>
            <div className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-0.5 text-[11px] text-slate-300">
              <span>
                {STADIUM_CONFIG.venue.city}, {STADIUM_CONFIG.venue.country}
              </span>
              <span className="text-slate-500">|</span>
              <span className="font-mono text-[#7dd3fc]">
                Track L1: {state.measuredLapLengthMeters.toFixed(2)} m
              </span>
              <span className="text-slate-500 hidden sm:inline">|</span>
              <span className="hidden sm:inline font-mono text-slate-300">
                {state.totalSeatsBuilt.toLocaleString()} seats
              </span>
              {showFps && (
                <>
                  <span className="text-slate-500">|</span>
                  <span className="font-mono text-[#f5c542]">{fps} FPS</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Top-Right Quick Controls */}
        <div className="pointer-events-auto flex flex-wrap items-center gap-1.5 rounded-xl border border-white/15 bg-[#041029]/95 p-1.5 shadow-xl">
          {/* Time of Day */}
          <div className="flex items-center rounded-lg bg-[#07183c] p-0.5" role="group" aria-label="Lighting Time of Day">
            {timeOptions.map((opt) => {
              const active = state.timeOfDay === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => api?.setTimeOfDay(opt.id)}
                  aria-pressed={active}
                  className={`flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium transition-colors focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                    active
                      ? 'bg-[#0033a0] text-[#f5c542]'
                      : 'text-slate-300 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  {opt.icon}
                  <span className="hidden sm:inline">{opt.label}</span>
                </button>
              );
            })}
          </div>

          <button
            type="button"
            onClick={() => api?.cameras.setAutoOrbit(!state.autoOrbit)}
            aria-pressed={state.autoOrbit}
            title="Toggle Auto-Orbit Showcase"
            className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
              state.autoOrbit
                ? 'bg-[#0033a0] text-[#f5c542] ring-1 ring-[#f5c542]/60'
                : 'bg-[#07183c] text-slate-200 hover:bg-white/10'
            }`}
          >
            <Orbit className="h-3.5 w-3.5" />
            <span className="hidden md:inline">Auto-Orbit</span>
          </button>

          <button
            type="button"
            onClick={() => api?.setDebugCenterline(!state.debugCenterline)}
            aria-pressed={state.debugCenterline}
            title="Toggle Closed 400m Track Centerline Debug Loop"
            className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
              state.debugCenterline
                ? 'bg-[#d4af37] text-[#041029] font-bold'
                : 'bg-[#07183c] text-slate-200 hover:bg-white/10'
            }`}
          >
            <Route className="h-3.5 w-3.5" />
            <span className="hidden md:inline">400m Loop</span>
          </button>

          <button
            type="button"
            onClick={() => api?.people.setLabelsVisible(!state.showLabels)}
            aria-pressed={state.showLabels}
            title="Toggle Runner & Staff Tags"
            className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
              state.showLabels
                ? 'bg-[#0033a0] text-white'
                : 'bg-[#07183c] text-slate-300 hover:bg-white/10'
            }`}
          >
            <Tag className="h-3.5 w-3.5" />
            <span className="hidden lg:inline">Tags</span>
          </button>

          <button
            type="button"
            onClick={() => api?.setPerformanceMode(!state.performanceMode)}
            aria-pressed={state.performanceMode}
            title="Toggle Performance Mode (lowers shadows, crowd density & pixel ratio)"
            className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
              state.performanceMode
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-[#07183c] text-slate-200 hover:bg-white/10'
            }`}
          >
            <Gauge className="h-3.5 w-3.5" />
            <span className="hidden lg:inline">Perf</span>
          </button>

          <button
            type="button"
            onClick={() => api?.setTargetFps(state.targetFps === 30 ? 60 : 30)}
            title="Switch Frame Rate Cap (30 FPS / 60 FPS)"
            className="rounded-lg bg-[#07183c] px-2 py-1.5 font-mono text-[11px] font-semibold text-[#7dd3fc] hover:bg-white/10 focus-visible:outline-2 focus-visible:outline-[#f5c542]"
          >
            {state.targetFps} FPS Cap
          </button>

          <button
            type="button"
            onClick={() => setShowFps((v) => !v)}
            aria-pressed={showFps}
            title="Toggle FPS Counter"
            className={`rounded-lg px-2 py-1.5 font-mono text-[11px] font-semibold focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
              showFps ? 'bg-[#0033a0] text-[#f5c542]' : 'bg-[#07183c] text-slate-300'
            }`}
          >
            FPS
          </button>

          <button
            type="button"
            onClick={() => setBoardsOpen((v) => !v)}
            aria-expanded={boardsOpen}
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
              boardsOpen
                ? 'bg-[#d4af37] text-[#041029]'
                : 'bg-[#0033a0] text-white hover:bg-[#144d9e]'
            }`}
          >
            <Monitor className="h-3.5 w-3.5" />
            <span>Boards &amp; Text</span>
          </button>
        </div>
      </header>

      {boardsOpen && (
        <div className="pointer-events-auto">
          <BoardsPanel api={api} state={state} onClose={() => setBoardsOpen(false)} />
        </div>
      )}

      {/* Bottom Collapsible Control Dock */}
      <footer className="pointer-events-auto mx-auto w-full max-w-5xl">
        <div className="rounded-xl border border-[#d4af37]/35 bg-[#041029]/95 text-white shadow-2xl">
          <div className="flex items-center justify-between px-3.5 py-2 border-b border-white/10">
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <Compass className="h-3.5 w-3.5 text-[#f5c542]" />
              <span className="font-semibold text-white">
                {STADIUM_CONFIG.venue.gamesTitle}
              </span>
              <span className="hidden sm:inline text-slate-400">
                · Drag to orbit · Scroll/pinch to zoom · Right-drag to pan
              </span>
            </div>
            <button
              type="button"
              onClick={() => setDockOpen((v) => !v)}
              aria-expanded={dockOpen}
              className="flex items-center gap-1 rounded px-2 py-0.5 text-xs font-medium text-slate-300 hover:bg-white/10 hover:text-white focus-visible:outline-2 focus-visible:outline-[#f5c542]"
            >
              {dockOpen ? (
                <>
                  <span>Hide Controls</span>
                  <ChevronDown className="h-3.5 w-3.5" />
                </>
              ) : (
                <>
                  <span>Controls</span>
                  <ChevronUp className="h-3.5 w-3.5" />
                </>
              )}
            </button>
          </div>

          {dockOpen && (
            <div className="flex flex-col gap-3 p-3 lg:flex-row lg:items-center lg:justify-between">
              {/* Camera Presets */}
              <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Camera Presets">
                <span className="mr-1 flex items-center gap-1 text-[11px] font-semibold tracking-wider text-[#f5c542] uppercase">
                  <Camera className="h-3.5 w-3.5" />
                  Cam
                </span>
                {PRESET_ORDER.map((id) => {
                  const active = state.cameraPreset === id;
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => api?.cameras.goTo(id)}
                      aria-pressed={active}
                      className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                        active
                          ? 'bg-[#0033a0] text-white ring-1 ring-[#f5c542]'
                          : 'bg-[#07183c] text-slate-300 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      {STADIUM_CONFIG.cameras[id].label}
                    </button>
                  );
                })}
              </div>

              {/* Crowd Sliders & Cheer Wave */}
              <div className="flex flex-wrap items-center gap-3 border-t border-white/10 pt-2.5 lg:border-t-0 lg:border-l lg:pl-3 lg:pt-0">
                <label className="flex items-center gap-2 text-xs text-slate-200">
                  <Users className="h-3.5 w-3.5 text-[#7dd3fc]" />
                  <span>Fill</span>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    step={5}
                    value={state.crowdFillPercent}
                    onChange={(e) => api?.setCrowdFill(Number(e.target.value))}
                    className="w-20 accent-[#f5c542]"
                  />
                  <span className="w-8 font-mono text-[11px] text-[#f5c542]">
                    {state.crowdFillPercent}%
                  </span>
                </label>

                <label className="flex items-center gap-2 text-xs text-slate-200">
                  <span>Density</span>
                  <input
                    type="range"
                    min={10}
                    max={100}
                    step={5}
                    value={Math.round(state.crowdDensity * 100)}
                    onChange={(e) => api?.setCrowdDensity(Number(e.target.value) / 100)}
                    className="w-20 accent-[#38bdf8]"
                  />
                  <span className="w-8 font-mono text-[11px] text-[#7dd3fc]">
                    {Math.round(state.crowdDensity * 100)}%
                  </span>
                </label>

                <button
                  type="button"
                  onClick={() => api?.setCheerWave(!state.cheerWave)}
                  aria-pressed={state.cheerWave}
                  className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-[#f5c542] ${
                    state.cheerWave
                      ? 'bg-[#d4af37] text-[#041029]'
                      : 'bg-[#07183c] text-slate-200 hover:bg-white/10'
                  }`}
                >
                  <Waves className="h-3.5 w-3.5" />
                  <span>Cheer Wave</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </footer>
    </div>
  );
};
