import * as THREE from 'three';
import type { StadiumAPI } from '../../src/api/StadiumAPI';
import type { TrackPoint } from '../../src/track/trackGeometry';

export const EVENT_LAYER_NAME = 'EventLayer_Men100m';
export const HOME_STRAIGHT_LENGTH = 84.39;
export const RACE_DISTANCE_METERS = 100.0;
export const RUNUP_EXTENSION_METERS = RACE_DISTANCE_METERS - HOME_STRAIGHT_LENGTH; // 15.61 m
export const TRACK_SURFACE_Y = 0.04;
export const EXTENSION_SURFACE_Y = TRACK_SURFACE_Y + 0.008;
export const LANE_WIDTH = 1.22;
export const LINE_WIDTH = 0.05;

export interface EventLanePath {
  lane: number;
  startX: number;
  finishX: number;
  laneCenterZ: number;
  pointAtRaceDistance: (raceDistanceMeters: number, lateralOffsetM?: number) => TrackPoint;
}

function createExtensionSurfaceTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#1551A1';
  ctx.fillRect(0, 0, 256, 256);

  for (let i = 0; i < 1600; i++) {
    const x = (i * 73) % 256;
    const y = (i * 139) % 256;
    ctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.045)' : 'rgba(4,16,45,0.08)';
    ctx.fillRect(x, y, 2, 2);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(6, 3);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createStartLaneNumberTexture(
  lane: number,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, 128, 128);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 88px "Barlow Condensed", sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(String(lane), 64, 68);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createWindGaugeTexture(windText: string, legal: boolean): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  drawWindGaugeCanvas(canvas, windText, legal);
  return canvas;
}

function drawWindGaugeCanvas(
  canvas: HTMLCanvasElement,
  windText: string,
  legal: boolean
): void {
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#041029';
  ctx.fillRect(0, 0, 256, 128);
  ctx.strokeStyle = '#D4AF37';
  ctx.lineWidth = 4;
  ctx.strokeRect(4, 4, 248, 120);

  ctx.fillStyle = '#93C5FD';
  ctx.font = 'bold 20px "Barlow Condensed", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('WSTV WIND GAUGE · 100M', 128, 28);

  ctx.fillStyle = legal ? '#4ADE80' : '#FBBF24';
  ctx.font = 'bold 48px "JetBrains Mono", monospace';
  ctx.fillText(windText, 128, 78);

  ctx.fillStyle = '#E2E8F0';
  ctx.font = 'bold 16px "Barlow Condensed", sans-serif';
  ctx.fillText(legal ? 'LEGAL (<= +2.0 m/s)' : 'WIND-AIDED (> +2.0 m/s)', 128, 108);
}

export class EventTrackLayer {
  public readonly group: THREE.Group;
  private readonly stadium: StadiumAPI;
  private readonly lanePaths = new Map<number, EventLanePath>();
  private readonly blockLedMaterials = new Map<number, THREE.MeshStandardMaterial>();
  private readonly windFlags: Array<{ pivot: THREE.Group; cloth: THREE.Mesh }> = [];
  private readonly recallConesGroup = new THREE.Group();
  private readonly gunFlashMesh: THREE.Mesh;
  private readonly gunSmokeMesh: THREE.Mesh;
  private readonly windGaugeCanvas: HTMLCanvasElement;
  private readonly windGaugeTex: THREE.CanvasTexture;
  private readonly disposables: Array<{ dispose: () => void }> = [];

  private gunFxTimer = -1;
  private windMps = 0;

  constructor(stadium: StadiumAPI) {
    this.stadium = stadium;
    this.group = new THREE.Group();
    this.group.name = EVENT_LAYER_NAME;

    const maxAnisotropy = Math.min(8, stadium.renderer.capabilities.getMaxAnisotropy());

    // Measure 100.00 m back from Finish Line using stadium.getTrackPath(lane)
    const lane1Path = stadium.getTrackPath(1);
    const lane8Path = stadium.getTrackPath(8);
    const finishPt1 = lane1Path.pointAt(HOME_STRAIGHT_LENGTH);
    const joinPt1 = lane1Path.pointAt(0);
    const joinPt8 = lane8Path.pointAt(0);

    const finishX = finishPt1.position.x; // +42.195
    const joinX = joinPt1.position.x; // -42.195
    const startX = finishX - RACE_DISTANCE_METERS; // -57.805
    const extBackX = startX - 3.2; // -61.005 (apron behind blocks)

    const innerZ = joinPt1.position.z - LANE_WIDTH * 0.5; // 36.50
    const outerZ = joinPt8.position.z + LANE_WIDTH * 0.5; // 46.26
    const totalTrackWidth = outerZ - innerZ; // 9.76
    const centerZ = (innerZ + outerZ) * 0.5;

    for (let lane = 1; lane <= 8; lane++) {
      const stadiumPath = stadium.getTrackPath(lane);
      const joinPt = stadiumPath.pointAt(0);
      const laneCenterZ = joinPt.position.z;

      this.lanePaths.set(lane, {
        lane,
        startX,
        finishX,
        laneCenterZ,
        pointAtRaceDistance: (raceDist: number, lateralOffsetM = 0): TrackPoint => {
          if (raceDist >= RUNUP_EXTENSION_METERS) {
            const pt = stadiumPath.pointAt(raceDist - RUNUP_EXTENSION_METERS);
            const normalX = -pt.tangent.z;
            const normalZ = pt.tangent.x;
            return {
              position: new THREE.Vector3(
                pt.position.x + normalX * lateralOffsetM,
                TRACK_SURFACE_Y,
                pt.position.z + normalZ * lateralOffsetM
              ),
              heading: pt.heading,
              tangent: pt.tangent.clone(),
            };
          }
          // Straight 15.61 m run-up extension behind x = -42.195
          const x = startX + raceDist;
          return {
            position: new THREE.Vector3(
              x,
              EXTENSION_SURFACE_Y,
              laneCenterZ + lateralOffsetM
            ),
            heading: Math.PI / 2,
            tangent: new THREE.Vector3(1, 0, 0),
          };
        },
      });
    }

    // 1. Additive Blue 100m Run-Up Extension Strip (seamless match to stadium track)
    const extLen = joinX - extBackX;
    const extCenterX = (extBackX + joinX) * 0.5;

    const surfaceTex = createExtensionSurfaceTexture(maxAnisotropy);
    this.disposables.push(surfaceTex);
    const surfaceMat = new THREE.MeshStandardMaterial({
      map: surfaceTex,
      roughness: 0.78,
      metalness: 0.02,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });
    this.disposables.push(surfaceMat);

    const extStripGeo = new THREE.PlaneGeometry(extLen, totalTrackWidth);
    extStripGeo.rotateX(-Math.PI / 2);
    this.disposables.push(extStripGeo);
    const extStrip = new THREE.Mesh(extStripGeo, surfaceMat);
    extStrip.position.set(extCenterX, EXTENSION_SURFACE_Y, centerZ);
    extStrip.receiveShadow = true;
    extStrip.name = 'RunUpExtension100m';
    this.group.add(extStrip);

    // Matching light-grey side aprons along the run-up extension
    const apronMat = new THREE.MeshStandardMaterial({
      color: '#94A3B8',
      roughness: 0.88,
      metalness: 0.04,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });
    this.disposables.push(apronMat);

    const outerApronGeo = new THREE.PlaneGeometry(extLen, 2.2);
    outerApronGeo.rotateX(-Math.PI / 2);
    this.disposables.push(outerApronGeo);
    const outerApron = new THREE.Mesh(outerApronGeo, apronMat);
    outerApron.position.set(extCenterX, EXTENSION_SURFACE_Y - 0.002, outerZ + 1.1);
    outerApron.receiveShadow = true;
    this.group.add(outerApron);

    const innerApronGeo = new THREE.PlaneGeometry(extLen, 1.8);
    innerApronGeo.rotateX(-Math.PI / 2);
    this.disposables.push(innerApronGeo);
    const innerApron = new THREE.Mesh(innerApronGeo, apronMat);
    innerApron.position.set(extCenterX, EXTENSION_SURFACE_Y - 0.002, innerZ - 0.9);
    innerApron.receiveShadow = true;
    this.group.add(innerApron);

    // White inner kerb along extension
    const kerbMat = new THREE.MeshStandardMaterial({
      color: '#F8FAFC',
      roughness: 0.35,
      metalness: 0.35,
    });
    this.disposables.push(kerbMat);
    const kerbGeo = new THREE.BoxGeometry(extLen, 0.05, 0.09);
    this.disposables.push(kerbGeo);
    const kerbMesh = new THREE.Mesh(kerbGeo, kerbMat);
    kerbMesh.position.set(extCenterX, EXTENSION_SURFACE_Y + 0.025, innerZ - 0.045);
    this.group.add(kerbMesh);

    // 2. White Lane Lines along Run-Up + 100m Start Line
    const lineMat = new THREE.MeshBasicMaterial({
      color: '#FFFFFF',
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2,
    });
    this.disposables.push(lineMat);

    const laneLineGeo = new THREE.PlaneGeometry(extLen, LINE_WIDTH);
    laneLineGeo.rotateX(-Math.PI / 2);
    this.disposables.push(laneLineGeo);

    for (let b = 0; b <= 8; b++) {
      const z = innerZ + b * LANE_WIDTH;
      const lineMesh = new THREE.Mesh(laneLineGeo, lineMat);
      lineMesh.position.set(extCenterX, EXTENSION_SURFACE_Y + 0.003, z);
      this.group.add(lineMesh);
    }

    const startLineGeo = new THREE.PlaneGeometry(0.08, totalTrackWidth);
    startLineGeo.rotateX(-Math.PI / 2);
    this.disposables.push(startLineGeo);
    const startLineMesh = new THREE.Mesh(startLineGeo, lineMat);
    startLineMesh.position.set(startX, EXTENSION_SURFACE_Y + 0.004, centerZ);
    startLineMesh.name = 'StartLine100m';
    this.group.add(startLineMesh);

    // 3. Lane Numbers (1..8) + Starting Blocks per lane
    const metalMat = new THREE.MeshStandardMaterial({
      color: '#CBD5E1',
      metalness: 0.78,
      roughness: 0.25,
    });
    const pedalMat = new THREE.MeshStandardMaterial({
      color: '#0F172A',
      roughness: 0.65,
      metalness: 0.25,
    });
    const padMat = new THREE.MeshStandardMaterial({
      color: '#0033A0',
      roughness: 0.8,
      metalness: 0.05,
    });
    this.disposables.push(metalMat, pedalMat, padMat);

    const numPlaneGeo = new THREE.PlaneGeometry(0.75, 0.75);
    numPlaneGeo.rotateX(-Math.PI / 2);
    const railGeo = new THREE.BoxGeometry(0.86, 0.035, 0.09);
    const pedalGeo = new THREE.BoxGeometry(0.14, 0.14, 0.12);
    const sensorGeo = new THREE.BoxGeometry(0.12, 0.06, 0.14);
    const ledGeo = new THREE.BoxGeometry(0.04, 0.025, 0.06);
    this.disposables.push(numPlaneGeo, railGeo, pedalGeo, sensorGeo, ledGeo);

    for (let lane = 1; lane <= 8; lane++) {
      const lp = this.lanePaths.get(lane)!;
      const numTex = createStartLaneNumberTexture(lane, maxAnisotropy);
      this.disposables.push(numTex);
      const numMat = new THREE.MeshBasicMaterial({
        map: numTex,
        transparent: true,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -3,
        polygonOffsetUnits: -3,
      });
      this.disposables.push(numMat);

      const numMesh = new THREE.Mesh(numPlaneGeo, numMat);
      numMesh.position.set(startX + 0.72, EXTENSION_SURFACE_Y + 0.005, lp.laneCenterZ);
      this.group.add(numMesh);

      // Composite starting block assembly behind start line
      const blockGroup = new THREE.Group();
      blockGroup.name = `StartingBlock_Lane${lane}`;
      blockGroup.position.set(startX - 0.52, EXTENSION_SURFACE_Y, lp.laneCenterZ);

      const rail = new THREE.Mesh(railGeo, metalMat);
      rail.position.set(0, 0.018, 0);
      rail.castShadow = true;
      blockGroup.add(rail);

      const frontPedal = new THREE.Mesh(pedalGeo, pedalMat);
      frontPedal.position.set(0.16, 0.08, -0.11);
      frontPedal.rotation.z = -0.52;
      frontPedal.castShadow = true;
      blockGroup.add(frontPedal);

      const frontPad = new THREE.Mesh(pedalGeo, padMat);
      frontPad.scale.set(0.3, 0.92, 0.9);
      frontPad.position.set(0.18, 0.09, -0.11);
      frontPad.rotation.z = -0.52;
      blockGroup.add(frontPad);

      const rearPedal = new THREE.Mesh(pedalGeo, pedalMat);
      rearPedal.position.set(-0.18, 0.085, 0.11);
      rearPedal.rotation.z = -0.62;
      rearPedal.castShadow = true;
      blockGroup.add(rearPedal);

      const sensorPod = new THREE.Mesh(sensorGeo, pedalMat);
      sensorPod.position.set(-0.42, 0.03, 0);
      blockGroup.add(sensorPod);

      const ledMat = new THREE.MeshStandardMaterial({
        color: '#22C55E',
        emissive: '#16A34A',
        emissiveIntensity: 0.7,
        roughness: 0.3,
      });
      this.disposables.push(ledMat);
      this.blockLedMaterials.set(lane, ledMat);

      const ledMesh = new THREE.Mesh(ledGeo, ledMat);
      ledMesh.position.set(-0.42, 0.065, 0);
      blockGroup.add(ledMesh);

      this.group.add(blockGroup);
    }

    // 4. Starter Stand + Gun Flash & Smoke (at startX - 0.8, outerZ + 1.45)
    const starterGroup = new THREE.Group();
    starterGroup.position.set(startX - 0.8, EXTENSION_SURFACE_Y, outerZ + 1.45);
    const standBase = new THREE.Mesh(
      new THREE.BoxGeometry(1.1, 0.28, 0.9),
      new THREE.MeshStandardMaterial({ color: '#0033A0', roughness: 0.6 })
    );
    standBase.position.y = 0.14;
    standBase.castShadow = true;
    const standRim = new THREE.Mesh(
      new THREE.BoxGeometry(1.14, 0.06, 0.94),
      new THREE.MeshStandardMaterial({ color: '#D4AF37', metalness: 0.6, roughness: 0.3 })
    );
    standRim.position.y = 0.28;
    const micPole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.025, 0.03, 1.35, 8),
      metalMat
    );
    micPole.position.set(0.35, 0.85, -0.3);
    this.disposables.push(
      standBase.geometry,
      standBase.material as THREE.Material,
      standRim.geometry,
      standRim.material as THREE.Material,
      micPole.geometry
    );
    starterGroup.add(standBase, standRim, micPole);

    const flashGeo = new THREE.SphereGeometry(0.26, 10, 10);
    const flashMat = new THREE.MeshBasicMaterial({
      color: '#FEF08A',
      transparent: true,
      opacity: 0.95,
    });
    this.gunFlashMesh = new THREE.Mesh(flashGeo, flashMat);
    this.gunFlashMesh.position.set(0.15, 1.65, -0.35);
    this.gunFlashMesh.visible = false;

    const smokeGeo = new THREE.SphereGeometry(0.38, 10, 10);
    const smokeMat = new THREE.MeshBasicMaterial({
      color: '#E2E8F0',
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    });
    this.gunSmokeMesh = new THREE.Mesh(smokeGeo, smokeMat);
    this.gunSmokeMesh.position.set(0.15, 1.75, -0.35);
    this.gunSmokeMesh.visible = false;
    this.disposables.push(flashGeo, flashMat, smokeGeo, smokeMat);
    starterGroup.add(this.gunFlashMesh, this.gunSmokeMesh);
    this.group.add(starterGroup);

    // 5. Wind Gauge Tripod & LED Display (50m mark, infield apron)
    const windGroup = new THREE.Group();
    windGroup.position.set(-8.0, TRACK_SURFACE_Y, innerZ - 1.35);
    const poleGeo = new THREE.CylinderGeometry(0.035, 0.05, 1.25, 10);
    const poleMesh = new THREE.Mesh(poleGeo, pedalMat);
    poleMesh.position.y = 0.625;
    const headGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.18, 12);
    const headMesh = new THREE.Mesh(headGeo, metalMat);
    headMesh.position.y = 1.32;

    this.windGaugeCanvas = createWindGaugeTexture('+0.0 m/s', true);
    this.windGaugeTex = new THREE.CanvasTexture(this.windGaugeCanvas);
    this.windGaugeTex.colorSpace = THREE.SRGBColorSpace;
    const screenGeo = new THREE.BoxGeometry(1.15, 0.58, 0.08);
    const screenMat = new THREE.MeshBasicMaterial({ map: this.windGaugeTex });
    const screenMesh = new THREE.Mesh(screenGeo, screenMat);
    screenMesh.position.set(0, 0.78, 0);
    screenMesh.rotation.y = Math.PI; // face stands / track
    this.disposables.push(
      poleGeo,
      headGeo,
      screenGeo,
      screenMat,
      this.windGaugeTex
    );
    windGroup.add(poleMesh, headMesh, screenMesh);
    this.group.add(windGroup);

    // 6. Animated Wind Flags near track (start & finish infield apron)
    const flagPoleGeo = new THREE.CylinderGeometry(0.025, 0.03, 2.2, 8);
    const flagClothGeo = new THREE.PlaneGeometry(0.68, 0.24, 6, 1);
    flagClothGeo.translate(0.34, 0, 0);
    const flagClothMat = new THREE.MeshStandardMaterial({
      color: '#F5C542',
      roughness: 0.65,
      side: THREE.DoubleSide,
    });
    this.disposables.push(flagPoleGeo, flagClothGeo, flagClothMat);

    [
      [startX + 4, innerZ - 1.4],
      [finishX - 6, innerZ - 1.4],
    ].forEach(([fx, fz]) => {
      const post = new THREE.Mesh(flagPoleGeo, metalMat);
      post.position.set(fx, TRACK_SURFACE_Y + 1.1, fz);
      this.group.add(post);

      const pivot = new THREE.Group();
      pivot.position.set(fx, TRACK_SURFACE_Y + 2.08, fz);
      const cloth = new THREE.Mesh(flagClothGeo, flagClothMat);
      pivot.add(cloth);
      this.group.add(pivot);
      this.windFlags.push({ pivot, cloth });
    });

    // 7. Finish-line optical photo-finish emitter cones & tape markers
    const coneGeo = new THREE.ConeGeometry(0.13, 0.34, 10);
    const coneMat = new THREE.MeshStandardMaterial({
      color: '#F5C542',
      roughness: 0.45,
    });
    const laserGeo = new THREE.BoxGeometry(0.015, 0.015, totalTrackWidth + 0.6);
    const laserMat = new THREE.MeshBasicMaterial({
      color: '#EF4444',
      transparent: true,
      opacity: 0.55,
    });
    this.disposables.push(coneGeo, coneMat, laserGeo, laserMat);

    const coneIn = new THREE.Mesh(coneGeo, coneMat);
    coneIn.position.set(finishX, TRACK_SURFACE_Y + 0.17, innerZ - 0.35);
    const coneOut = new THREE.Mesh(coneGeo, coneMat);
    coneOut.position.set(finishX, TRACK_SURFACE_Y + 0.17, outerZ + 0.35);
    const finishLaser = new THREE.Mesh(laserGeo, laserMat);
    finishLaser.position.set(finishX, TRACK_SURFACE_Y + 0.92, centerZ);
    this.group.add(coneIn, coneOut, finishLaser);

    // 8. False-Start Recall Cones (hidden unless FALSE_START_RECALL)
    const redConeMat = new THREE.MeshStandardMaterial({
      color: '#DC2626',
      emissive: '#991B1B',
      emissiveIntensity: 0.4,
      roughness: 0.45,
    });
    this.disposables.push(redConeMat);
    for (let lane = 1; lane <= 8; lane++) {
      const lp = this.lanePaths.get(lane)!;
      const rc = new THREE.Mesh(coneGeo, redConeMat);
      rc.position.set(startX + 4.5, EXTENSION_SURFACE_Y + 0.17, lp.laneCenterZ);
      this.recallConesGroup.add(rc);
    }
    this.recallConesGroup.visible = false;
    this.group.add(this.recallConesGroup);

    stadium.scene.add(this.group);
  }

  public getLanePath(lane: number): EventLanePath {
    return this.lanePaths.get(lane) ?? this.lanePaths.get(1)!;
  }

  public setWind(mps: number, legal: boolean): void {
    this.windMps = mps;
    const text = `${mps >= 0 ? '+' : ''}${mps.toFixed(1)} m/s`;
    drawWindGaugeCanvas(this.windGaugeCanvas, text, legal);
    this.windGaugeTex.needsUpdate = true;
  }

  public setRecallVisible(visible: boolean, offendingLane?: number | null): void {
    this.recallConesGroup.visible = visible;
    this.blockLedMaterials.forEach((mat, lane) => {
      if (visible && offendingLane === lane) {
        mat.color.set('#EF4444');
        mat.emissive.set('#DC2626');
        mat.emissiveIntensity = 1.4;
      } else {
        mat.color.set('#22C55E');
        mat.emissive.set('#16A34A');
        mat.emissiveIntensity = 0.7;
      }
    });
  }

  public triggerGunFlash(): void {
    this.gunFxTimer = 0;
    this.gunFlashMesh.visible = true;
    this.gunSmokeMesh.visible = true;
    this.gunSmokeMesh.scale.setScalar(0.5);
    this.gunSmokeMesh.position.y = 1.75;
  }

  public updateVisuals(elapsedSeconds: number, dt: number): void {
    // Animate gun flash & smoke
    if (this.gunFxTimer >= 0) {
      this.gunFxTimer += dt;
      this.gunFlashMesh.visible = this.gunFxTimer < 0.14;
      if (this.gunFxTimer < 1.6) {
        this.gunSmokeMesh.visible = true;
        const p = this.gunFxTimer / 1.6;
        this.gunSmokeMesh.scale.setScalar(0.5 + p * 2.1);
        this.gunSmokeMesh.position.y = 1.75 + p * 1.4;
        (this.gunSmokeMesh.material as THREE.MeshBasicMaterial).opacity =
          0.55 * (1 - p);
      } else {
        this.gunSmokeMesh.visible = false;
        this.gunFxTimer = -1;
      }
    }

    // Animate wind flags according to wind speed & direction
    const absWind = Math.abs(this.windMps);
    const dirSign = this.windMps >= 0 ? 1 : -1;
    this.windFlags.forEach((f, idx) => {
      const flutter = Math.sin(elapsedSeconds * (4.5 + absWind * 3.2) + idx) * (0.08 + absWind * 0.04);
      const yaw = dirSign > 0 ? 0 : Math.PI;
      f.pivot.rotation.y = yaw + flutter;
      const droop = Math.max(0.08, 0.7 - absWind * 0.24);
      f.cloth.rotation.z = -droop + Math.cos(elapsedSeconds * 7 + idx) * 0.05;
    });
  }

  public dispose(): void {
    this.stadium.scene.remove(this.group);
    this.disposables.forEach((d) => d.dispose());
  }
}
