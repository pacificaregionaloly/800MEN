import type { StadiumAPI } from '../../src/api/StadiumAPI';
import type {
  RaceCommand,
  RaceIncidentRecord,
  RaceResultsPayload,
  RaceSetupPayload,
  RaceState,
} from '../api/types';
import { validateSetupPayload } from '../api/validation';
import type { WavesportsApiClient } from '../api/WavesportsApiClient';
import { MockWavesportsApi } from '../api/MockWavesportsApi';
import {
  sampleAthleteFrame,
  WavesportsAI,
  type RacePlan,
} from '../ai/WavesportsAI';
import { AthleteManager } from '../athletes/AthleteManager';
import { BoardController } from '../director/BoardController';
import {
  BroadcastDirector,
  type EventCameraId,
} from '../director/BroadcastDirector';
import { RaceAudioFX } from './AudioFX';
import { createFixedStepLoop, type SimClockAPI } from './FixedStepLoop';
import { EventTrackLayer } from './TrackExtension';

export interface RaceControllerUIState {
  apiConnectionState: 'connecting' | 'connected' | 'error';
  apiModeLabel: string;
  isMock: boolean;
  apiError: string | null;
  raceState: RaceState;
  raceId: string;
  seed: number | null;
  windMps: number | null;
  windLegal: boolean | null;
  raceClockSec: number;
  allowManualStart: boolean;
  isReplay: boolean;
  replaySpeed: number;
  simPaused: boolean;
  directorEnabled: boolean;
  directorUserOverride: boolean;
  selectedCamera: EventCameraId;
  liveMiniView: boolean;
  muted: boolean;
  setup: RaceSetupPayload | null;
  plan: RacePlan | null;
  visibleIncidents: RaceIncidentRecord[];
  latestHeadline: string;
  latestCaption: string;
  resultsPosted: boolean;
}

export class RaceController {
  private readonly stadium: StadiumAPI;
  private readonly apiClient: WavesportsApiClient;
  private readonly raceId: string;
  private readonly pollIntervalMs: number;
  private readonly ai = new WavesportsAI();
  private readonly sim: SimClockAPI;
  private readonly trackLayer: EventTrackLayer;
  private readonly athletes: AthleteManager;
  private readonly boards: BoardController;
  private readonly director: BroadcastDirector;
  private readonly audio = new RaceAudioFX();
  private readonly onUIUpdate: (state: RaceControllerUIState) => void;

  private raceState: RaceState = 'WAITING_FOR_API';
  private apiConnectionState: 'connecting' | 'connected' | 'error' = 'connecting';
  private apiError: string | null = null;
  private setup: RaceSetupPayload | null = null;
  private plan: RacePlan | null = null;

  private phaseClockSec = 0;
  private raceClockSec = 0;
  private currentAttemptIdx = 0;
  private gunFiredThisAttempt = false;
  private recallGunFiredThisAttempt = false;
  private isReplay = false;
  private replaySpeed = 1.0;
  private resultsPosted = false;
  private postingResults = false;

  private visibleIncidents: RaceIncidentRecord[] = [];
  private seenIncidentKeys = new Set<string>();
  private latestHeadline = "MEN'S 100 METRES";
  private latestCaption = 'Waiting for Wavesports API…';
  private lastUiEmitMs = 0;

  private disposed = false;
  private setupPollTimer: number | null = null;
  private commandPollTimer: number | null = null;
  private unsubscribeRealtime: (() => void) | null = null;
  private setupBackoffMs = 2000;
  private lastCommandIso: string | undefined;

  private unsubFixed: () => void;
  private unsubRender: () => void;

  constructor(options: {
    stadium: StadiumAPI;
    apiClient: WavesportsApiClient;
    raceId: string;
    pollIntervalMs: number;
    onUIUpdate: (state: RaceControllerUIState) => void;
  }) {
    this.stadium = options.stadium;
    this.apiClient = options.apiClient;
    this.raceId = options.raceId;
    this.pollIntervalMs = options.pollIntervalMs;
    this.onUIUpdate = options.onUIUpdate;

    this.sim = createFixedStepLoop(this.stadium);
    this.trackLayer = new EventTrackLayer(this.stadium);
    this.athletes = new AthleteManager(this.stadium, this.trackLayer);
    this.boards = new BoardController(this.stadium);
    this.director = new BroadcastDirector(this.stadium, () => this.emitUI(true));

    this.unsubFixed = this.sim.addFixedUpdateCallback((_simTime, fixedDt) => {
      this.stepSimulation(fixedDt);
    });
    this.unsubRender = this.sim.addRenderCallback((_alpha, elapsed, rawDt) => {
      this.stepRender(elapsed, rawDt);
    });

    this.athletes.spawnWaitingLineup();
    this.emitUI(true);
    this.startSetupPolling();
    this.startCommandChannel();
  }

  public getApiClient(): WavesportsApiClient {
    return this.apiClient;
  }

  public getSimClock(): SimClockAPI {
    return this.sim;
  }

  public setDirectorEnabled(enabled: boolean): void {
    this.director.setDirectorEnabled(enabled);
  }

  public selectCamera(camId: EventCameraId): void {
    this.director.selectCamera(camId);
  }

  public resetView(): void {
    this.director.resetView();
  }

  public setLiveMiniView(enabled: boolean): void {
    this.boards.setLiveMiniViewEnabled(enabled);
    this.emitUI(true);
  }

  public setMuted(muted: boolean): void {
    this.audio.setMuted(muted);
    this.emitUI(true);
  }

  public triggerManualStart(): void {
    this.audio.unlock();
    if (!this.setup?.allowManualStart) return;
    if (this.raceState !== 'READY') return;
    this.beginStartSequence();
  }

  public startReplay(speed: 1 | 0.25): void {
    this.audio.unlock();
    if (
      !this.plan ||
      (this.raceState !== 'FINISHED' && this.raceState !== 'RESULTS_POSTED')
    ) {
      return;
    }
    this.isReplay = true;
    this.replaySpeed = speed;
    this.sim.setTimeScale(speed);
    this.sim.resume();
    this.raceClockSec = 0;
    this.phaseClockSec = 0;
    this.gunFiredThisAttempt = false;
    this.trackLayer.setRecallVisible(false);
    this.currentAttemptIdx = this.plan.finalAttemptIndex;
    this.raceState = 'RUNNING';
    this.latestHeadline = `WSTV REPLAY (${speed}x)`;
    this.latestCaption = `Replaying Men's 100m Final at ${speed}x speed`;
    this.director.setDirectorEnabled(true);
    this.emitUI(true);
  }

  public stopReplay(): void {
    if (!this.isReplay || !this.plan) return;
    this.isReplay = false;
    this.replaySpeed = 1.0;
    this.sim.setTimeScale(1.0);
    this.sim.resume();
    this.raceClockSec = this.plan.totalSimDurationSec;
    this.raceState = this.resultsPosted ? 'RESULTS_POSTED' : 'FINISHED';
    this.latestHeadline = 'OFFICIAL RESULTS';
    this.latestCaption = this.plan.postRaceSummary;
    this.emitUI(true);
  }

  public togglePause(): void {
    if (this.sim.isPaused()) this.sim.resume();
    else this.sim.pause();
    this.emitUI(true);
  }

  /** Dev-only helper when MockWavesportsApi is active */
  public devMockTrigger(action: 'start' | 'reset' | 'new_seed'): void {
    if (!import.meta.env.DEV || !(this.apiClient instanceof MockWavesportsApi)) {
      return;
    }
    this.audio.unlock();
    if (action === 'start') {
      this.apiClient.enqueueCommand({
        command: 'start',
        issuedAt: new Date().toISOString(),
      });
    } else if (action === 'reset') {
      this.apiClient.enqueueCommand({ command: 'reset' });
    } else if (action === 'new_seed') {
      const nextSeed = Math.floor(100000 + Math.random() * 899999);
      this.apiClient.setSeed(nextSeed);
      this.apiClient.enqueueCommand({ command: 'reset' });
    }
  }

  private startSetupPolling(): void {
    if (this.disposed) return;
    const poll = async () => {
      if (this.disposed) return;
      if (this.raceState !== 'WAITING_FOR_API') return;

      try {
        const raw = await this.apiClient.fetchSetup(this.raceId);
        if (this.disposed) return;

        this.raceState = 'SETUP_RECEIVED';
        const validation = validateSetupPayload(raw);
        if (!validation.valid || !validation.data) {
          const errStr = `Invalid setup payload: ${validation.errors.slice(0, 2).join(' ')}`;
          this.raceState = 'WAITING_FOR_API';
          this.apiConnectionState = 'error';
          this.apiError = errStr;
          this.boards.showWaitingState(errStr);
          this.emitUI(true);
          void this.safePostStatus({ status: 'VALIDATION_FAILED', detail: errStr });
          this.scheduleNextSetupPoll(true);
          return;
        }

        this.handleValidatedSetup(validation.data);
      } catch (err) {
        if (this.disposed) return;
        const msg = err instanceof Error ? err.message : 'Unable to reach Wavesports API';
        this.raceState = 'WAITING_FOR_API';
        this.apiConnectionState = 'error';
        this.apiError = msg;
        this.boards.showWaitingState(msg);
        this.emitUI(true);
        void this.safePostStatus({ status: 'API_ERROR', detail: msg });
        this.scheduleNextSetupPoll(true);
      }
    };

    void poll();
  }

  private scheduleNextSetupPoll(isRetry: boolean): void {
    if (this.disposed) return;
    if (this.setupPollTimer !== null) {
      window.clearTimeout(this.setupPollTimer);
    }
    if (isRetry) {
      this.setupBackoffMs = Math.min(15000, Math.round(this.setupBackoffMs * 1.5));
    } else {
      this.setupBackoffMs = this.pollIntervalMs;
    }
    this.setupPollTimer = window.setTimeout(() => {
      if (!this.disposed && this.raceState === 'WAITING_FOR_API') {
        this.startSetupPolling();
      }
    }, this.setupBackoffMs);
  }

  private startCommandChannel(): void {
    if (this.apiClient.subscribeCommands) {
      this.unsubscribeRealtime = this.apiClient.subscribeCommands(
        this.raceId,
        (cmd) => this.handleCommand(cmd),
        () => {
          // Realtime stream dropped; HTTP polling remains active as resilient fallback
        }
      );
    }

    const pollCmds = async () => {
      if (this.disposed) return;
      try {
        const cmds = await this.apiClient.pollCommands(
          this.raceId,
          this.lastCommandIso
        );
        cmds.forEach((cmd) => this.handleCommand(cmd));
      } catch {
        // Non-fatal; command polling continues
      }
      if (!this.disposed) {
        this.commandPollTimer = window.setTimeout(pollCmds, this.pollIntervalMs);
      }
    };
    this.commandPollTimer = window.setTimeout(pollCmds, 800);
  }

  private handleCommand(cmd: RaceCommand): void {
    if (this.disposed) return;
    if (cmd.command === 'start') {
      this.lastCommandIso = cmd.issuedAt;
      if (this.raceState === 'READY') {
        this.beginStartSequence();
      }
    } else if (cmd.command === 'abort') {
      this.latestHeadline = 'RACE ABORTED';
      this.latestCaption = cmd.reason || 'Race aborted by Wavesports API.';
      this.sim.setTimeScale(1.0);
      this.isReplay = false;
      this.trackLayer.setRecallVisible(true);
      if (this.setup && this.plan) {
        this.raceState = 'READY';
        this.phaseClockSec = 0;
        this.raceClockSec = 0;
        void this.safePostStatus({ status: 'ABORTED', detail: cmd.reason });
      } else {
        this.resetToWaiting();
      }
      this.emitUI(true);
    } else if (cmd.command === 'reset') {
      this.resetToWaiting();
    }
  }

  private handleValidatedSetup(setup: RaceSetupPayload): void {
    this.setup = setup;
    this.apiConnectionState = 'connected';
    this.apiError = null;
    this.setupBackoffMs = this.pollIntervalMs;
    this.raceState = 'VALIDATED';
    this.visibleIncidents = [];
    this.seenIncidentKeys.clear();
    this.resultsPosted = false;
    this.postingResults = false;
    this.isReplay = false;
    this.sim.setTimeScale(1.0);

    // Run deterministic Wavesports AI once upon validation
    const plan = this.ai.plan(setup);
    this.plan = plan;
    this.trackLayer.setWind(plan.windMps, plan.windLegal);
    this.trackLayer.setRecallVisible(false);
    this.boards.activateEventBoards();

    void this.safePostStatus({ status: 'VALIDATED' });

    // Record any late_dns immediately in call room
    const skipIds = new Set<string>();
    plan.athleteRuns.forEach((run) => {
      if (run.initialDns || run.lateDns) {
        skipIds.add(run.athlete.athleteId);
      }
    });
    plan.incidents
      .filter((i) => i.type === 'late_dns')
      .forEach((i) => this.pushVisibleIncident(i));

    // Place athletes in call-room walkout
    this.athletes.spawnRoster(setup.athletes, skipIds);
    this.raceState = 'ATHLETES_ON_TRACK';
    this.phaseClockSec = 0;
    this.raceClockSec = 0;
    this.currentAttemptIdx = 0;
    this.latestHeadline = "CALL ROOM WALKOUT · MEN'S 100M";
    this.latestCaption = `${setup.venue} · Wind ${plan.windMps >= 0 ? '+' : ''}${plan.windMps.toFixed(
      1
    )} m/s`;
    void this.safePostStatus({ status: 'ATHLETES_ON_TRACK' });
    this.emitUI(true);
  }

  private beginStartSequence(): void {
    if (!this.plan) return;
    this.currentAttemptIdx = 0;
    this.enterOnYourMarks();
  }

  private enterOnYourMarks(): void {
    if (!this.plan) return;
    this.raceState = 'ON_YOUR_MARKS';
    this.phaseClockSec = 0;
    this.raceClockSec = 0;
    this.gunFiredThisAttempt = false;
    this.recallGunFiredThisAttempt = false;
    this.trackLayer.setRecallVisible(false);
    this.latestHeadline = 'ON YOUR MARKS';
    this.latestCaption =
      this.currentAttemptIdx > 0
        ? `Restart #${this.currentAttemptIdx}: Athletes settle back into the blocks.`
        : 'Athletes settle into the starting blocks.';
    this.audio.playCommandTone(520, 0.1);
    void this.safePostStatus({ status: 'ON_YOUR_MARKS' });
    this.emitUI(true);
  }

  private enterSet(): void {
    this.raceState = 'SET';
    this.phaseClockSec = 0;
    this.latestHeadline = 'SET';
    this.latestCaption = 'Tension builds across all lanes — awaiting the gun.';
    this.audio.playCommandTone(740, 0.08);
    void this.safePostStatus({ status: 'SET' });
    this.emitUI(true);
  }

  private stepSimulation(fixedDt: number): void {
    if (
      this.raceState === 'WAITING_FOR_API' ||
      this.raceState === 'SETUP_RECEIVED' ||
      this.raceState === 'VALIDATED'
    ) {
      this.athletes.getAllEntities().forEach((ent) => {
        this.athletes.updateAthleteState(
          ent.setup.athleteId,
          -0.55,
          0,
          0,
          'still',
          fixedDt,
          this.sim.getSimTime()
        );
      });
      return;
    }

    if (!this.plan || !this.setup) return;

    this.phaseClockSec += fixedDt;

    if (this.raceState === 'ATHLETES_ON_TRACK') {
      // All 8 athletes lined up still at the 100m starting line
      this.athletes.getAllEntities().forEach((ent) => {
        this.athletes.updateAthleteState(
          ent.setup.athleteId,
          -0.55,
          0,
          0,
          'still',
          fixedDt,
          this.sim.getSimTime()
        );
      });

      // Cycle lane introductions while athletes stand still at the line
      const entities = this.athletes.getAllEntities();
      if (entities.length > 0) {
        const idx = Math.min(
          entities.length - 1,
          Math.floor((this.phaseClockSec / 1.6) * entities.length)
        );
        const ath = entities[idx].setup;
        this.latestHeadline = `LANE ${ath.lane} · ${ath.name.toUpperCase()} (${ath.nationCode})`;
        this.latestCaption = this.plan.laneIntros.get(ath.athleteId) ?? '';
      }

      if (this.phaseClockSec >= 1.6) {
        this.raceState = 'READY';
        this.phaseClockSec = 0;
        this.latestHeadline = 'RUNNERS AT THE LINE';
        this.latestCaption = this.setup.scheduledStartTime
          ? `Awaiting scheduled start (${this.setup.scheduledStartTime}) or API start command.`
          : 'All 8 athletes still at the 100m start line — awaiting start command.';
        void this.safePostStatus({ status: 'READY' });
        this.emitUI(true);
      }
    } else if (this.raceState === 'READY') {
      this.athletes.getAllEntities().forEach((ent) => {
        this.athletes.updateAthleteState(
          ent.setup.athleteId,
          -0.55,
          0,
          0,
          'still',
          fixedDt,
          this.sim.getSimTime()
        );
      });

      // Check scheduledStartTime automatically
      if (this.setup.scheduledStartTime) {
        const targetMs = Date.parse(this.setup.scheduledStartTime);
        if (Number.isFinite(targetMs) && Date.now() >= targetMs) {
          this.beginStartSequence();
        }
      }
    } else if (this.raceState === 'ON_YOUR_MARKS') {
      this.athletes.getAllEntities().forEach((ent) => {
        const run = this.plan!.athleteRuns.get(ent.setup.athleteId);
        const dqPrior =
          run?.dqOnAttempt !== undefined && run.dqOnAttempt < this.currentAttemptIdx;
        this.athletes.updateAthleteState(
          ent.setup.athleteId,
          -0.45,
          0,
          0,
          'on_your_marks',
          fixedDt,
          this.sim.getSimTime(),
          !dqPrior
        );
      });

      if (this.phaseClockSec >= 1.8) {
        this.enterSet();
      }
    } else if (this.raceState === 'SET') {
      const attempt = this.plan.attempts[this.currentAttemptIdx];
      const holdSec = attempt ? attempt.holdDurationSec : 1.9;

      // Handle pre-gun false start twitch if planned
      const falseStartInc = attempt?.incidents.find(
        (i) => i.type === 'false_start'
      );
      const triggerPreGun =
        falseStartInc &&
        falseStartInc.atTime < 0 &&
        this.phaseClockSec >= holdSec + falseStartInc.atTime;

      this.athletes.getAllEntities().forEach((ent) => {
        const run = this.plan!.athleteRuns.get(ent.setup.athleteId);
        const dqPrior =
          run?.dqOnAttempt !== undefined && run.dqOnAttempt < this.currentAttemptIdx;
        const isFalseStarter =
          triggerPreGun && falseStartInc?.athleteId === ent.setup.athleteId;
        this.athletes.updateAthleteState(
          ent.setup.athleteId,
          isFalseStarter ? 0.35 : -0.32,
          0,
          0,
          isFalseStarter ? 'false_start_twitch' : 'set_crouch',
          fixedDt,
          this.sim.getSimTime(),
          !dqPrior
        );
      });

      if (triggerPreGun && !this.recallGunFiredThisAttempt && attempt) {
        this.triggerRecall(attempt, falseStartInc!);
        return;
      }

      if (this.phaseClockSec >= holdSec) {
        // Fire starting gun!
        this.gunFiredThisAttempt = true;
        this.trackLayer.triggerGunFlash();
        this.audio.playStartingGun(false);
        this.raceState = 'RUNNING';
        this.raceClockSec = 0;
        this.phaseClockSec = 0;

        if (!attempt?.recalled && !this.isReplay) {
          this.latestHeadline = 'AWAY THEY GO!';
          this.latestCaption = "Clean break! The Men's 100 Metres is underway!";
          void this.safePostStatus({ status: 'RUNNING' });
        }
        this.emitUI(true);
      }
    } else if (this.raceState === 'FALSE_START_RECALL') {
      const attempt = this.plan.attempts[this.currentAttemptIdx];
      this.athletes.getAllEntities().forEach((ent) => {
        const run = this.plan!.athleteRuns.get(ent.setup.athleteId);
        const dqPrior =
          run?.dqOnAttempt !== undefined && run.dqOnAttempt < this.currentAttemptIdx;
        const isOffender = attempt?.offendingAthleteId === ent.setup.athleteId;
        this.athletes.updateAthleteState(
          ent.setup.athleteId,
          isOffender ? 0.4 : -0.55,
          0,
          0,
          isOffender ? 'disappointed' : 'still',
          fixedDt,
          this.sim.getSimTime(),
          !dqPrior
        );
      });

      if (this.phaseClockSec >= 3.0) {
        this.currentAttemptIdx++;
        if (this.currentAttemptIdx >= this.plan.attempts.length) {
          this.currentAttemptIdx = this.plan.finalAttemptIndex;
        }
        this.enterOnYourMarks();
      }
    } else if (this.raceState === 'RUNNING') {
      this.raceClockSec += fixedDt;

      // Check post-gun false start or equipment recall on non-replay attempt
      const attempt = this.plan.attempts[this.currentAttemptIdx];
      if (!this.isReplay && attempt?.recalled && !this.recallGunFiredThisAttempt) {
        const recallAt = attempt.recallAtTimeSec ?? 0.25;
        if (this.raceClockSec >= recallAt) {
          this.triggerRecall(attempt, attempt.incidents[0]);
          return;
        }
      }

      // Replay gun flash at t=0
      if (this.isReplay && !this.gunFiredThisAttempt) {
        this.gunFiredThisAttempt = true;
        this.trackLayer.triggerGunFlash();
        this.audio.playStartingGun(false);
      }

      // Position and animate every athlete from deterministic RacePlan frames
      this.athletes.getAllEntities().forEach((ent) => {
        const run = this.plan!.athleteRuns.get(ent.setup.athleteId);
        if (!run) return;
        const dqPrior =
          run.dqOnAttempt !== undefined && run.dqOnAttempt <= this.currentAttemptIdx && !this.isReplay
            ? run.dqOnAttempt < this.currentAttemptIdx
            : run.dqOnAttempt !== undefined;
        if (dqPrior) {
          this.athletes.updateAthleteState(
            ent.setup.athleteId,
            -2,
            0,
            0,
            'disappointed',
            fixedDt,
            this.sim.getSimTime(),
            false
          );
          return;
        }

        const sample = sampleAthleteFrame(run, this.raceClockSec);
        this.athletes.updateAthleteState(
          ent.setup.athleteId,
          sample.distanceM,
          sample.lateralOffsetM,
          sample.speedMps,
          sample.pose,
          fixedDt,
          this.sim.getSimTime(),
          true
        );
      });

      // Live incidents & commentary cues
      if (!this.isReplay) {
        this.plan.incidents.forEach((inc) => {
          if (
            inc.attempt === this.currentAttemptIdx &&
            inc.type !== 'late_dns' &&
            inc.atTime <= this.raceClockSec
          ) {
            this.pushVisibleIncident(inc);
          }
        });
      }

      for (const cue of this.plan.commentaryCues) {
        if (
          this.raceClockSec >= cue.atRaceTime &&
          this.raceClockSec < cue.atRaceTime + 2.8
        ) {
          this.latestHeadline = cue.headline;
          this.latestCaption = cue.line;
        }
      }

      if (this.raceClockSec >= this.plan.totalSimDurationSec) {
        if (this.isReplay) {
          this.stopReplay();
        } else {
          this.enterFinished();
        }
      }
    } else if (this.raceState === 'FINISHED' || this.raceState === 'RESULTS_POSTED') {
      // Keep final post-race poses smoothly animated
      this.athletes.getAllEntities().forEach((ent) => {
        const run = this.plan!.athleteRuns.get(ent.setup.athleteId);
        if (!run || run.dqOnAttempt !== undefined) return;
        const sample = sampleAthleteFrame(run, this.plan!.totalSimDurationSec);
        this.athletes.updateAthleteState(
          ent.setup.athleteId,
          sample.distanceM,
          sample.lateralOffsetM,
          0,
          sample.pose,
          fixedDt,
          this.sim.getSimTime(),
          true
        );
      });
    }

    this.syncBoardSnapshot();
    this.emitUI(false);
  }

  private triggerRecall(
    attempt: RacePlan['attempts'][number],
    incident: RaceIncidentRecord
  ): void {
    this.recallGunFiredThisAttempt = true;
    this.trackLayer.triggerGunFlash();
    this.trackLayer.setRecallVisible(true, incident.lane);
    this.audio.playStartingGun(true);
    this.raceState = 'FALSE_START_RECALL';
    this.phaseClockSec = 0;

    if (incident) {
      this.pushVisibleIncident(incident);
    }

    const ath = this.setup?.athletes.find(
      (a) => a.athleteId === attempt.offendingAthleteId
    );
    this.latestHeadline =
      attempt.recallReason === 'equipment_issue'
        ? 'EQUIPMENT RECALL'
        : 'FALSE START — RED CARD';
    this.latestCaption = incident?.detail ?? 'Recall gun fired — runners return to blocks.';

    this.boards.updateSnapshot({
      raceState: 'FALSE_START_RECALL',
      recallIncident: incident ?? null,
      latestHeadline: this.latestHeadline,
      latestCaption: this.latestCaption,
    });

    void this.safePostStatus({
      status:
        attempt.recallReason === 'equipment_issue' ? 'RECALL' : 'FALSE_START',
      athleteId: ath?.athleteId,
      detail: incident?.detail,
    });
    this.emitUI(true);
  }

  private enterFinished(): void {
    if (!this.plan) return;
    this.raceState = 'FINISHED';
    this.latestHeadline = 'OFFICIAL FINISH';
    this.latestCaption = this.plan.postRaceSummary;
    this.syncBoardSnapshot();
    this.emitUI(true);

    if (!this.resultsPosted && !this.postingResults) {
      this.postingResults = true;
      const payload: RaceResultsPayload = {
        ...this.plan.resultsPayload,
        completedAt: new Date().toISOString(),
      };
      void this.postResultsAndFinalize(payload);
    }
  }

  private async postResultsAndFinalize(payload: RaceResultsPayload): Promise<void> {
    try {
      await this.apiClient.postResults(this.raceId, payload);
      if (this.disposed) return;
      this.resultsPosted = true;
      this.raceState = 'RESULTS_POSTED';
      await this.safePostStatus({ status: 'RESULTS_POSTED' });
    } catch (err) {
      if (this.disposed) return;
      this.apiError =
        err instanceof Error ? `Results POST failed: ${err.message}` : 'Results POST failed';
    } finally {
      this.postingResults = false;
      this.syncBoardSnapshot();
      this.emitUI(true);
    }
  }

  private stepRender(elapsedSec: number, rawDt: number): void {
    this.trackLayer.updateVisuals(elapsedSec, rawDt);

    const leaderPos = this.athletes.getLeaderPosition();
    this.director.update(
      this.raceState,
      this.raceClockSec,
      this.isReplay,
      leaderPos,
      rawDt
    );

    if (this.raceState === 'RUNNING' && this.boards.isLiveMiniViewEnabled()) {
      this.boards.renderLiveMiniView(leaderPos);
    }
  }

  private pushVisibleIncident(inc: RaceIncidentRecord): void {
    const key = `${inc.attempt}:${inc.type}:${inc.athleteId ?? 'none'}`;
    if (this.seenIncidentKeys.has(key)) return;
    this.seenIncidentKeys.add(key);
    this.visibleIncidents = [...this.visibleIncidents, inc];
  }

  private syncBoardSnapshot(): void {
    const liveOrder = this.athletes
      .getAllEntities()
      .filter((e) => e.person.root.visible)
      .map((e) => ({
        lane: e.setup.lane,
        shortName: e.setup.shortName,
        nationCode: e.setup.nationCode,
        distanceM: e.currentDistanceM,
        speedMps: e.currentSpeedMps,
        status: e.currentPose,
      }))
      .sort((a, b) => b.distanceM - a.distanceM);

    this.boards.updateSnapshot({
      raceState: this.raceState,
      errorMsg: this.apiError,
      setup: this.setup,
      plan: this.plan,
      raceClockSec: this.raceClockSec,
      isReplay: this.isReplay,
      replaySpeed: this.replaySpeed,
      liveOrder,
      latestHeadline: this.latestHeadline,
      latestCaption: this.latestCaption,
    });
  }

  private async safePostStatus(update: {
    status: string;
    athleteId?: string;
    detail?: string;
  }): Promise<void> {
    try {
      await this.apiClient.postStatus(this.raceId, update);
    } catch {
      // Status reporting is best-effort when API is unreachable
    }
  }

  public resetToWaiting(): void {
    this.athletes.spawnWaitingLineup();
    this.trackLayer.setRecallVisible(false);
    this.trackLayer.setWind(0, true);
    this.setup = null;
    this.plan = null;
    this.raceState = 'WAITING_FOR_API';
    this.apiConnectionState = 'connecting';
    this.apiError = null;
    this.phaseClockSec = 0;
    this.raceClockSec = 0;
    this.currentAttemptIdx = 0;
    this.isReplay = false;
    this.replaySpeed = 1.0;
    this.sim.setTimeScale(1.0);
    this.sim.resume();
    this.resultsPosted = false;
    this.postingResults = false;
    this.visibleIncidents = [];
    this.seenIncidentKeys.clear();
    this.latestHeadline = "MEN'S 100 METRES";
    this.latestCaption = 'Waiting for Wavesports API…';
    this.boards.showWaitingState(null);
    this.emitUI(true);
    this.startSetupPolling();
  }

  private emitUI(force: boolean): void {
    const now = performance.now();
    if (!force && now - this.lastUiEmitMs < 90) return;
    this.lastUiEmitMs = now;

    this.onUIUpdate({
      apiConnectionState: this.apiConnectionState,
      apiModeLabel: this.apiClient.modeLabel,
      isMock: this.apiClient.isMock,
      apiError: this.apiError,
      raceState: this.raceState,
      raceId: this.setup?.raceId ?? this.raceId,
      seed: this.setup?.seed ?? null,
      windMps: this.plan?.windMps ?? null,
      windLegal: this.plan?.windLegal ?? null,
      raceClockSec: this.raceClockSec,
      allowManualStart: Boolean(this.setup?.allowManualStart),
      isReplay: this.isReplay,
      replaySpeed: this.replaySpeed,
      simPaused: this.sim.isPaused(),
      directorEnabled: this.director.isDirectorEnabled(),
      directorUserOverride: this.director.hasUserOverride(),
      selectedCamera: this.director.getSelectedCamera(),
      liveMiniView: this.boards.isLiveMiniViewEnabled(),
      muted: this.audio.isMuted(),
      setup: this.setup,
      plan: this.plan,
      visibleIncidents: this.visibleIncidents,
      latestHeadline: this.latestHeadline,
      latestCaption: this.latestCaption,
      resultsPosted: this.resultsPosted,
    });
  }

  public dispose(): void {
    this.disposed = true;
    if (this.setupPollTimer !== null) window.clearTimeout(this.setupPollTimer);
    if (this.commandPollTimer !== null) window.clearTimeout(this.commandPollTimer);
    this.unsubscribeRealtime?.();
    this.unsubFixed();
    this.unsubRender();
    this.director.dispose();
    this.athletes.cleanupAll();
    this.boards.dispose();
    this.trackLayer.dispose();
    this.sim.dispose();
    this.audio.dispose();
  }
}
