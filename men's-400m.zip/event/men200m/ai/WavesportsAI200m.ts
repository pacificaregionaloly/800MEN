import type {
  AthleteRaceResult200m,
  AthleteSetup200m,
  RaceIncidentRecord200m,
  RaceResultsPayload200m,
  RaceSetupPayload200m,
} from '../api/types';
import { mergeIncidentRates200m } from '../config/incidents';
import {
  type CommentaryContext200m,
  type CommentaryCue200m,
  type CommentaryGenerator200m,
  TemplateCommentaryGenerator200m,
} from './commentary';
import { SeededRNG200m } from './seededRng';

export type AthletePoseAction200m =
  | 'still'
  | 'walkout'
  | 'stretch_shakeout'
  | 'on_your_marks'
  | 'set_crouch'
  | 'false_start_twitch'
  | 'sprint'
  | 'stumble'
  | 'fall_slide'
  | 'pull_up_injured'
  | 'limp'
  | 'lean_finish'
  | 'celebrate'
  | 'disappointed';

export interface AthleteFrameSample200m {
  distanceM: number;
  speedMps: number;
  lateralOffsetM: number;
  pose: AthletePoseAction200m;
}

export interface PlannedAttempt200m {
  attemptIndex: number;
  holdDurationSec: number;
  activeAthleteIds: string[];
  recalled: boolean;
  recallReason?: 'false_start' | 'equipment_issue';
  recallAtTimeSec?: number;
  offendingAthleteId?: string;
  incidents: RaceIncidentRecord200m[];
}

export interface PlannedAthleteRun200m {
  athlete: AthleteSetup200m;
  initialDns: boolean;
  lateDns: boolean;
  dqOnAttempt?: number;
  reactionTimeSec: number;
  topSpeedMps: number;
  splits: { '50': number; '100': number; '150': number };
  bendTimeSec: number;
  straightTimeSec: number;
  exactFinishTimeSec: number | null;
  displayFinishTimeSec: number | null;
  status: 'finished' | 'DQ' | 'DNF' | 'DNS';
  reason?: string;
  notes: string[];
  frames: AthleteFrameSample200m[];
}

export interface RacePlan200m {
  setup: RaceSetupPayload200m;
  seed: number;
  windMps: number;
  windLegal: boolean;
  attempts: PlannedAttempt200m[];
  finalAttemptIndex: number;
  totalSimDurationSec: number;
  athleteRuns: Map<string, PlannedAthleteRun200m>;
  incidents: RaceIncidentRecord200m[];
  results: AthleteRaceResult200m[];
  resultsPayload: RaceResultsPayload200m;
  laneIntros: Map<string, string>;
  commentaryCues: CommentaryCue200m[];
  postRaceSummary: string;
}

const FIXED_HZ = 30;
const FIXED_DT = 1 / FIXED_HZ;
const SUBSTEPS = 10;
const SUB_DT = FIXED_DT / SUBSTEPS;

const BEND_EXIT_DIST_M = 115.61; // 200.00 - 84.39 m home straight
const KERB_RADIUS_M = 36.5;
const LANE_WIDTH_M = 1.22;

function getLaneRunningRadius(lane: number): number {
  return KERB_RADIUS_M + (lane - 1) * LANE_WIDTH_M + 0.2;
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

function roundTo(v: number, decimals: number): number {
  const f = Math.pow(10, decimals);
  return Math.round(v * f) / f;
}

/**
 * Self-contained Wavesports AI race engine for Men's 200 Metres.
 * Deterministic under seeded RNG; simulates bend physics, curve technique,
 * speed endurance, home-straight wind, and rare incidents.
 */
export class WavesportsAI200m {
  private readonly commentary: CommentaryGenerator200m;

  constructor(
    commentaryGenerator: CommentaryGenerator200m = new TemplateCommentaryGenerator200m()
  ) {
    this.commentary = commentaryGenerator;
  }

  public plan(setup: RaceSetupPayload200m): RacePlan200m {
    const rng = new SeededRNG200m(setup.seed);
    const rates = mergeIncidentRates200m(setup.incidentOverrides);

    // 1. Seeded home-straight wind in [-1.5, +3.0] m/s
    const rawWind = rng.range(-1.5, 3.0);
    const windMps = roundTo(rawWind, 1);
    const windLegal = windMps <= setup.rules.windLimitMps;

    const allIncidents: RaceIncidentRecord200m[] = [];
    const attempts: PlannedAttempt200m[] = [];
    const dqMap = new Map<string, { attempt: number; reason: string }>();
    const lateDnsSet = new Set<string>();

    // Lane introductions
    const laneIntros = new Map<string, string>();
    setup.athletes.forEach((a) => {
      laneIntros.set(a.athleteId, this.commentary.generateLaneIntro(a, setup));
    });

    // 2. Evaluate initial DNS & rare call-room late DNS
    const eligibleAthletes: AthleteSetup200m[] = [];
    setup.athletes
      .slice()
      .sort((a, b) => a.lane - b.lane)
      .forEach((ath) => {
        if (ath.status === 'dns') {
          return;
        }
        if (rng.next() < rates.lateDnsRate && eligibleAthletes.length >= 2) {
          lateDnsSet.add(ath.athleteId);
          allIncidents.push({
            type: 'late_dns',
            code: 'LATE_DNS_CALL_ROOM',
            athleteId: ath.athleteId,
            lane: ath.lane,
            attempt: 0,
            atTime: -18.0,
            detail: `${ath.name} withdrew in the call room prior to track walkout.`,
          });
          return;
        }
        eligibleAthletes.push(ath);
      });

    let activeRoster = [...eligibleAthletes];
    if (activeRoster.length === 0) {
      activeRoster = setup.athletes.filter((a) => a.status === 'active');
    }

    // 3. Simulate start attempts (false starts + equipment block slips up to maxRecalls)
    let attemptIdx = 0;
    while (attemptIdx <= rates.maxRecalls) {
      const holdDurationSec = roundTo(rng.range(1.5, 2.5), 2);
      const canRecall = attemptIdx < rates.maxRecalls && activeRoster.length > 2;
      const attemptIncidents: RaceIncidentRecord200m[] = [];

      if (
        canRecall &&
        rng.next() < rates.equipmentBlockSlipRate * activeRoster.length
      ) {
        const affected = rng.pick(activeRoster);
        const slipTime = roundTo(rng.range(0.05, 0.25), 3);
        const inc: RaceIncidentRecord200m = {
          type: 'equipment_issue',
          code: 'BLOCK_SLIP_RECALL',
          athleteId: affected.athleteId,
          lane: affected.lane,
          attempt: attemptIdx,
          atTime: slipTime,
          detail: `Angled block pad slipped in Lane ${affected.lane} (${affected.shortName}); recall fired.`,
        };
        attemptIncidents.push(inc);
        allIncidents.push(inc);
        attempts.push({
          attemptIndex: attemptIdx,
          holdDurationSec,
          activeAthleteIds: activeRoster.map((a) => a.athleteId),
          recalled: true,
          recallReason: 'equipment_issue',
          recallAtTimeSec: slipTime,
          offendingAthleteId: affected.athleteId,
          incidents: attemptIncidents,
        });
        attemptIdx++;
        continue;
      }

      let falseStarter: { ath: AthleteSetup200m; atTime: number } | null = null;
      if (canRecall) {
        for (const ath of activeRoster) {
          const composureFactor = 1.45 - (ath.ratings.composure / 100) * 0.9;
          const eagernessFactor = 0.8 + (ath.ratings.reaction / 100) * 0.4;
          const pFalse = clamp(
            rates.falseStartBaseRate * composureFactor * eagernessFactor,
            0,
            0.35
          );
          if (rng.next() < pFalse) {
            const atTime = roundTo(rng.range(-0.14, 0.085), 3);
            if (!falseStarter || atTime < falseStarter.atTime) {
              falseStarter = { ath, atTime };
            }
          }
        }
      }

      if (falseStarter) {
        const inc: RaceIncidentRecord200m = {
          type: 'false_start',
          code: 'FALSE_START_UNDER_100MS',
          athleteId: falseStarter.ath.athleteId,
          lane: falseStarter.ath.lane,
          attempt: attemptIdx,
          atTime: falseStarter.atTime,
          detail: `${falseStarter.ath.name} (Lane ${
            falseStarter.ath.lane
          }) reacted at ${falseStarter.atTime.toFixed(3)}s (< 0.100s threshold).`,
        };
        attemptIncidents.push(inc);
        allIncidents.push(inc);

        if (setup.rules.falseStartDisqualifies) {
          dqMap.set(falseStarter.ath.athleteId, {
            attempt: attemptIdx,
            reason: 'false_start',
          });
          activeRoster = activeRoster.filter(
            (a) => a.athleteId !== falseStarter!.ath.athleteId
          );
        }

        attempts.push({
          attemptIndex: attemptIdx,
          holdDurationSec,
          activeAthleteIds: [
            ...activeRoster.map((a) => a.athleteId),
            ...(setup.rules.falseStartDisqualifies
              ? [falseStarter.ath.athleteId]
              : []),
          ],
          recalled: true,
          recallReason: 'false_start',
          recallAtTimeSec: Math.max(0.25, falseStarter.atTime + 0.35),
          offendingAthleteId: falseStarter.ath.athleteId,
          incidents: attemptIncidents,
        });
        attemptIdx++;
        continue;
      }

      attempts.push({
        attemptIndex: attemptIdx,
        holdDurationSec,
        activeAthleteIds: activeRoster.map((a) => a.athleteId),
        recalled: false,
        incidents: [],
      });
      break;
    }

    const finalAttemptIndex = attempts[attempts.length - 1].attemptIndex;

    // 4. Plan Men's 200m physics & in-race incidents
    interface RunnerPhysicsSpec {
      ath: AthleteSetup200m;
      reactionTime: number;
      maxSpeed: number;
      accelRate: number;
      fadeRate: number;
      bendPenaltyFactor: number;
      stumbledStart: boolean;
      stumbleLoss: number;
      fallAtDist: number | null;
      injuryAtDist: number | null;
      laneViolation: boolean;
      laneViolationInside: boolean;
      laneViolationAdvantage: boolean;
      breakout: boolean;
      collisionAtDist: number | null;
      notes: string[];
    }

    const specs = new Map<string, RunnerPhysicsSpec>();

    activeRoster.forEach((ath) => {
      const r = ath.ratings;
      const formFactor = rng.gaussian(0, 0.0085 * (1.25 - r.consistency / 120));
      const breakout = rng.next() < rates.breakoutPerformanceRate;
      const notes: string[] = [];

      // Reaction time: ~0.12 - 0.22 s
      const baseReact = 0.205 - (r.reaction / 100) * 0.075;
      const reactNoise = rng.gaussian(0, 0.011 * (1.2 - r.composure / 140));
      const reactionTime = roundTo(clamp(baseReact + reactNoise, 0.115, 0.232), 3);

      // Base top speed calibrated for 19.70 - 20.60s winning times, field up to ~21.2s
      // Peak speed ~11.4 - 12.2 m/s
      const baseTopSpeed = 10.22 + (r.topSpeed / 100) * 1.56;
      const breakoutBoost = breakout ? rng.range(0.12, 0.20) : 0;
      const maxSpeed = clamp(
        (baseTopSpeed + breakoutBoost) * (1 + formFactor),
        10.45,
        12.20
      );

      // Acceleration over first 35-60 m
      const accelRate =
        0.35 + (r.acceleration / 100) * 0.15 + (r.technique / 100) * 0.04;

      // Speed endurance & fade over last 60-80 m (120-200 m)
      const fadeRate = Math.max(
        0.095,
        0.215 - (r.speedEndurance / 100) * 0.115
      );

      // Bend penalty: tighter radius in inner lanes increases curve drag; high technique mitigates it
      const runR = getLaneRunningRadius(ath.lane);
      const tightnessRatio = Math.max(0, 45.24 / runR - 1); // ~0.233 in L1 down to 0 in L8
      const techMitigation = 1.25 - (r.technique / 100) * 0.65; // ~0.60..1.25
      const bendPenaltyFactor = 0.032 + tightnessRatio * 0.145 * techMitigation;

      const stumbleProb =
        rates.stumbledStartRate * (1.4 - r.technique / 110);
      const stumbledStart = rng.next() < stumbleProb;
      const stumbleLoss = stumbledStart ? rng.range(0.20, 0.38) : 0;

      // Fall occurs on the bend (~16 - 102 m)
      const fallProb =
        rates.fallOrTripRate *
        (1.5 - (r.technique + r.composure) / 160) *
        (1 + tightnessRatio * 0.8);
      const willFall = rng.next() < fallProb;
      const fallAtDist = willFall ? roundTo(rng.range(16, 102), 1) : null;

      // Mid-race injury typically on the straight (~118 - 185 m)
      const injuryProb =
        rates.injuryPullUpRate *
        (1.45 - r.durability / 110) *
        (0.85 + r.topSpeed / 250);
      const willInjure = !willFall && rng.next() < injuryProb;
      const injuryAtDist = willInjure ? roundTo(rng.range(118, 185), 1) : null;

      // Lane violation on the bend: more likely in inner lanes and with lower technique
      const innerLaneBias = 1.55 - (ath.lane - 1) * 0.14; // ~1.55 in L1, ~0.57 in L8
      const laneViolationProb =
        rates.laneViolationRate *
        innerLaneBias *
        (1.45 - r.technique / 105);
      const laneViolation =
        !willFall && !willInjure && rng.next() < laneViolationProb;
      // Stepping inside inner line (curb/line shortcut) is an advantage -> DQ
      const laneViolationInside = laneViolation && (ath.lane <= 5 || rng.next() < 0.72);
      const laneViolationAdvantage = laneViolationInside;

      if (breakout) {
        notes.push('Breakout performance');
        allIncidents.push({
          type: 'great_performance',
          code: 'BREAKOUT_RUN',
          athleteId: ath.athleteId,
          lane: ath.lane,
          attempt: finalAttemptIndex,
          atTime: 11.5,
          detail: `${ath.name} ran an inspired curve and powered clear down the straight!`,
        });
      }
      if (stumbledStart) {
        notes.push('Stumbled start');
        allIncidents.push({
          type: 'stumbled_start',
          code: 'BLOCK_STUMBLE',
          athleteId: ath.athleteId,
          lane: ath.lane,
          attempt: finalAttemptIndex,
          atTime: roundTo(reactionTime + 0.35, 3),
          detail: `${ath.name} stumbled pushing out of the angled blocks in Lane ${ath.lane}.`,
        });
      }

      specs.set(ath.athleteId, {
        ath,
        reactionTime,
        maxSpeed,
        accelRate,
        fadeRate,
        bendPenaltyFactor,
        stumbledStart,
        stumbleLoss,
        fallAtDist,
        injuryAtDist,
        laneViolation,
        laneViolationInside,
        laneViolationAdvantage,
        breakout,
        collisionAtDist: null,
        notes,
      });
    });

    // Rare collision brush between adjacent lanes after a stumble or drift
    activeRoster.forEach((ath) => {
      const sp = specs.get(ath.athleteId)!;
      if (sp.stumbledStart || (sp.laneViolation && !sp.laneViolationInside)) {
        const neighbor = activeRoster.find(
          (other) => Math.abs(other.lane - ath.lane) === 1
        );
        if (neighbor && rng.next() < rates.collisionBrushRate * 6) {
          const nSpec = specs.get(neighbor.athleteId)!;
          const brushDist = roundTo(rng.range(45, 110), 1);
          sp.collisionAtDist = brushDist;
          nSpec.collisionAtDist = brushDist;
          sp.notes.push('Lane brush');
          nSpec.notes.push('Brushed by adjacent runner');
          allIncidents.push({
            type: 'collision',
            code: 'LANE_BRUSH_CONTACT',
            athleteId: ath.athleteId,
            lane: ath.lane,
            attempt: finalAttemptIndex,
            atTime: roundTo(brushDist / 9.8, 2),
            detail: `Shoulder brush on the bend between Lane ${ath.lane} (${ath.shortName}) and Lane ${neighbor.lane} (${neighbor.shortName}).`,
          });
        }
      }
    });

    // 5. Integrate physics at high-res substeps and record 1/30s frames
    const maxSimSeconds = 27.5;
    const numFrames = Math.ceil(maxSimSeconds * FIXED_HZ);

    const athleteRuns = new Map<string, PlannedAthleteRun200m>();
    const snap50 = new Map<string, number>();
    const snapBendExit = new Map<string, number>();
    const snap150 = new Map<string, number>();

    setup.athletes.forEach((ath) => {
      const isInitialDns = ath.status === 'dns';
      const isLateDns = lateDnsSet.has(ath.athleteId);
      const dqEntry = dqMap.get(ath.athleteId);

      if (isInitialDns || isLateDns || dqEntry) {
        athleteRuns.set(ath.athleteId, {
          athlete: ath,
          initialDns: isInitialDns,
          lateDns: isLateDns,
          dqOnAttempt: dqEntry?.attempt,
          reactionTimeSec: 0,
          topSpeedMps: 0,
          splits: { '50': 0, '100': 0, '150': 0 },
          bendTimeSec: 0,
          straightTimeSec: 0,
          exactFinishTimeSec: null,
          displayFinishTimeSec: null,
          status: dqEntry ? 'DQ' : 'DNS',
          reason: dqEntry
            ? dqEntry.reason
            : isLateDns
            ? 'late_withdrawal'
            : 'dns',
          notes: dqEntry
            ? [`Disqualified (Attempt #${dqEntry.attempt + 1}): ${dqEntry.reason}`]
            : [isLateDns ? 'Late call-room withdrawal' : 'Did not start'],
          frames: [],
        });
        return;
      }

      const sp = specs.get(ath.athleteId)!;
      let dist = 0;
      let speed = 0;
      let peakSpeed = 0;
      let fallen = false;
      let injured = false;
      let injuryTimer = 0;
      let collisionTriggered = false;
      let laneViolationLogged = false;
      let bendTimeExact = 0;
      let finishTimeExact: number | null = null;

      const splitCross: Record<'50' | '100' | '150', number> = {
        '50': 0,
        '100': 0,
        '150': 0,
      };
      const frames: AthleteFrameSample200m[] = [];

      for (let f = 0; f <= numFrames; f++) {
        const frameTime = f * FIXED_DT;

        if (Math.abs(frameTime - 5.5) < FIXED_DT * 0.6) {
          snap50.set(ath.athleteId, dist);
        }
        if (Math.abs(frameTime - 11.4) < FIXED_DT * 0.6) {
          snapBendExit.set(ath.athleteId, dist);
        }
        if (Math.abs(frameTime - 14.8) < FIXED_DT * 0.6) {
          snap150.set(ath.athleteId, dist);
        }

        let pose: AthletePoseAction200m = 'sprint';
        if (frameTime < sp.reactionTime) {
          pose = 'set_crouch';
        } else if (fallen) {
          pose = 'fall_slide';
        } else if (injured) {
          pose = speed > 1.2 ? 'pull_up_injured' : 'limp';
        } else if (
          sp.stumbledStart &&
          frameTime >= sp.reactionTime + 0.1 &&
          frameTime <= sp.reactionTime + 0.85
        ) {
          pose = 'stumble';
        } else if (
          dist >= 197.2 &&
          dist <= 201.4 &&
          (finishTimeExact !== null ? frameTime < finishTimeExact + 0.2 : dist <= 200.6)
        ) {
          pose = 'lean_finish';
        } else if (finishTimeExact !== null && frameTime > finishTimeExact + 1.8) {
          pose = 'disappointed'; // Winner updated to 'celebrate' after ranking
        }

        // Lateral drift during bend lane violation (negative = inward, positive = wide)
        const driftSign = sp.laneViolationInside ? -1 : 1;
        const lateralOffsetM = sp.laneViolation
          ? driftSign * Math.sin(clamp((dist - 55) / 50, 0, 1) * Math.PI) * 0.56
          : 0;

        frames.push({
          distanceM: dist,
          speedMps: speed,
          lateralOffsetM,
          pose,
        });

        for (let s = 0; s < SUBSTEPS; s++) {
          const tNow = frameTime + s * SUB_DT;
          if (tNow < sp.reactionTime) {
            speed = 0;
            continue;
          }

          if (!fallen && sp.fallAtDist !== null && dist >= sp.fallAtDist) {
            fallen = true;
            allIncidents.push({
              type: 'fall',
              code: 'BEND_SLIP_FALL',
              athleteId: ath.athleteId,
              lane: ath.lane,
              attempt: finalAttemptIndex,
              atTime: roundTo(tNow, 2),
              detail: `${ath.name} slipped on the bend at ${dist.toFixed(1)}m and slid out (DNF).`,
            });
          }

          if (
            !injured &&
            !fallen &&
            sp.injuryAtDist !== null &&
            dist >= sp.injuryAtDist
          ) {
            injured = true;
            injuryTimer = 0;
            allIncidents.push({
              type: 'injury',
              code: 'HAMSTRING_PULL_UP',
              athleteId: ath.athleteId,
              lane: ath.lane,
              attempt: finalAttemptIndex,
              atTime: roundTo(tNow, 2),
              detail: `${ath.name} suffered a hamstring pull at ${dist.toFixed(
                1
              )}m and pulled up (DNF).`,
            });
          }

          if (
            !laneViolationLogged &&
            sp.laneViolation &&
            dist >= 78 &&
            !fallen &&
            !injured
          ) {
            laneViolationLogged = true;
            sp.notes.push(
              sp.laneViolationAdvantage
                ? 'Lane infringement (inside line DQ)'
                : 'Drifted wide on bend'
            );
            allIncidents.push({
              type: 'lane_violation',
              code: sp.laneViolationAdvantage
                ? 'LANE_LINE_INSIDE_DQ'
                : 'LANE_DRIFT_WARNING',
              athleteId: ath.athleteId,
              lane: ath.lane,
              attempt: finalAttemptIndex,
              atTime: roundTo(tNow, 2),
              detail: sp.laneViolationAdvantage
                ? `${ath.name} stepped inside the inner lane line on the bend near ${dist.toFixed(
                    0
                  )}m (DQ).`
                : `${ath.name} drifted wide near ${dist.toFixed(0)}m without gaining an advantage.`,
            });
          }

          if (
            !collisionTriggered &&
            sp.collisionAtDist !== null &&
            dist >= sp.collisionAtDist
          ) {
            collisionTriggered = true;
            speed *= 0.87;
          }

          if (fallen) {
            speed = Math.max(0, speed - 7.4 * SUB_DT);
          } else if (injured) {
            injuryTimer += SUB_DT;
            speed = Math.max(0, speed - 4.0 * SUB_DT);
            if (injuryTimer > 2.6) speed = 0;
          } else if (finishTimeExact !== null) {
            const after = tNow - finishTimeExact;
            if (after < 0.45) {
              speed = Math.max(0, speed - 1.4 * SUB_DT);
            } else {
              speed = Math.max(0, speed - 4.0 * SUB_DT);
            }
          } else {
            const sinceReact = tNow - sp.reactionTime;
            const onBend = dist < BEND_EXIT_DIST_M;
            const windMult = onBend
              ? 1 + windMps * 0.0014
              : 1 + windMps * 0.0052;

            let targetTop = sp.maxSpeed * windMult;
            if (onBend) {
              targetTop *= 1 - sp.bendPenaltyFactor;
            }
            if (sp.stumbledStart && sinceReact < 1.1) {
              targetTop *= 1 - sp.stumbleLoss * (1 - sinceReact / 1.1);
            }

            // Speed endurance fade over last 80m (120-200m)
            const fadeDist = Math.max(0, dist - 120);
            const fadedTarget = targetTop * (1 - sp.fadeRate * (fadeDist / 80));
            const dv = (fadedTarget - speed) * sp.accelRate * SUB_DT;
            speed = Math.max(0, speed + dv);
          }

          if (speed > peakSpeed) peakSpeed = speed;

          const prevDist = dist;
          dist += speed * SUB_DT;

          ([50, 100, 150] as const).forEach((mark) => {
            const key = String(mark) as '50' | '100' | '150';
            if (splitCross[key] === 0 && prevDist < mark && dist >= mark) {
              const frac = (mark - prevDist) / Math.max(1e-6, dist - prevDist);
              splitCross[key] = roundTo(tNow + frac * SUB_DT, 2);
            }
          });

          if (
            bendTimeExact === 0 &&
            prevDist < BEND_EXIT_DIST_M &&
            dist >= BEND_EXIT_DIST_M
          ) {
            const frac =
              (BEND_EXIT_DIST_M - prevDist) / Math.max(1e-6, dist - prevDist);
            bendTimeExact = tNow + frac * SUB_DT;
          }

          if (finishTimeExact === null && prevDist < 200 && dist >= 200) {
            const frac = (200 - prevDist) / Math.max(1e-6, dist - prevDist);
            finishTimeExact = roundTo(tNow + frac * SUB_DT, 3);
          }
        }
      }

      let status: 'finished' | 'DQ' | 'DNF' = 'finished';
      let reason: string | undefined;
      if (fallen) {
        status = 'DNF';
        reason = 'fall';
      } else if (injured) {
        status = 'DNF';
        reason = 'injury';
      } else if (sp.laneViolation && sp.laneViolationAdvantage) {
        status = 'DQ';
        reason = 'lane_violation';
      }

      if (
        status === 'finished' &&
        ath.personalBest &&
        finishTimeExact &&
        finishTimeExact < ath.personalBest
      ) {
        sp.notes.push(`New PB (${finishTimeExact.toFixed(2)}s)`);
      }

      const bendTime = bendTimeExact > 0 ? roundTo(bendTimeExact, 2) : 0;
      const straightTime =
        finishTimeExact !== null && bendTimeExact > 0
          ? roundTo(finishTimeExact - bendTimeExact, 2)
          : 0;

      athleteRuns.set(ath.athleteId, {
        athlete: ath,
        initialDns: false,
        lateDns: false,
        reactionTimeSec: sp.reactionTime,
        topSpeedMps: roundTo(peakSpeed, 2),
        splits: splitCross,
        bendTimeSec: bendTime,
        straightTimeSec: straightTime,
        exactFinishTimeSec: status === 'finished' ? finishTimeExact : null,
        displayFinishTimeSec:
          status === 'finished' && finishTimeExact !== null
            ? roundTo(finishTimeExact, 2)
            : null,
        status,
        reason,
        notes: sp.notes,
        frames,
      });
    });

    // 6. Rank finishers by exact 0.001 s time
    const allRuns = Array.from(athleteRuns.values());
    const finishers = allRuns
      .filter((r) => r.status === 'finished' && r.exactFinishTimeSec !== null)
      .sort((a, b) => a.exactFinishTimeSec! - b.exactFinishTimeSec!);

    const winnerId = finishers[0]?.athlete.athleteId;
    if (winnerId) {
      const wRun = athleteRuns.get(winnerId)!;
      wRun.frames.forEach((fr, idx) => {
        if (
          wRun.exactFinishTimeSec &&
          idx * FIXED_DT > wRun.exactFinishTimeSec + 1.6
        ) {
          fr.pose = 'celebrate';
        }
      });
    }

    const rankById = new Map<string, number>();
    finishers.forEach((r, idx) => rankById.set(r.athlete.athleteId, idx + 1));

    const results: AthleteRaceResult200m[] = allRuns
      .slice()
      .sort((a, b) => {
        const ra = rankById.get(a.athlete.athleteId);
        const rb = rankById.get(b.athlete.athleteId);
        if (ra !== undefined && rb !== undefined) return ra - rb;
        if (ra !== undefined) return -1;
        if (rb !== undefined) return 1;
        return a.athlete.lane - b.athlete.lane;
      })
      .map((run) => {
        const rank = rankById.get(run.athlete.athleteId) ?? null;
        if (run.status === 'finished') {
          return {
            rank,
            lane: run.athlete.lane,
            athleteId: run.athlete.athleteId,
            name: run.athlete.name,
            shortName: run.athlete.shortName,
            nation: run.athlete.nation,
            nationCode: run.athlete.nationCode,
            bib: run.athlete.bib,
            time: run.displayFinishTimeSec ?? undefined,
            exactTime: run.exactFinishTimeSec ?? undefined,
            reactionTime: run.reactionTimeSec,
            splits: { ...run.splits },
            bendTime: run.bendTimeSec,
            straightTime: run.straightTimeSec,
            topSpeedMps: run.topSpeedMps,
            status: 'finished',
            notes: [...run.notes],
          };
        }
        return {
          rank: null,
          lane: run.athlete.lane,
          athleteId: run.athlete.athleteId,
          name: run.athlete.name,
          shortName: run.athlete.shortName,
          nation: run.athlete.nation,
          nationCode: run.athlete.nationCode,
          bib: run.athlete.bib,
          reactionTime: run.reactionTimeSec > 0 ? run.reactionTimeSec : undefined,
          bendTime: run.bendTimeSec > 0 ? run.bendTimeSec : undefined,
          status: run.status,
          reason: run.reason,
          notes: [...run.notes],
        };
      });

    const lastFinish =
      finishers.length > 0
        ? finishers[finishers.length - 1].exactFinishTimeSec ?? 20.6
        : 20.6;
    const totalSimDurationSec = Math.min(
      maxSimSeconds,
      Math.max(22.0, lastFinish + 3.4)
    );

    const findLeader = (snap: Map<string, number>) => {
      let bestAth: AthleteSetup200m | undefined;
      let bestDist = -1;
      snap.forEach((d, id) => {
        if (d > bestDist) {
          bestDist = d;
          bestAth = setup.athletes.find((a) => a.athleteId === id);
        }
      });
      return bestAth;
    };

    const sortedIncidents = allIncidents
      .slice()
      .sort((a, b) => a.attempt - b.attempt || a.atTime - b.atTime);

    const avgBendExit =
      finishers.length > 0
        ? finishers[0].bendTimeSec || 11.4
        : 11.4;

    const commentaryCtx: CommentaryContext200m = {
      setup,
      windMps,
      windLegal,
      incidents: sortedIncidents,
      results,
    };

    const commentaryCues = this.commentary.generateRaceCues(
      commentaryCtx,
      {
        leaderAt50: findLeader(snap50),
        leaderAtBendExit: findLeader(snapBendExit),
        leaderAt150: findLeader(snap150),
        bendExitTimeSec: avgBendExit,
      },
      rng
    );
    const postRaceSummary =
      this.commentary.generatePostRaceSummary(commentaryCtx);

    const resultsPayload: RaceResultsPayload200m = {
      raceId: setup.raceId,
      seed: setup.seed,
      completedAt: new Date().toISOString(),
      wind: { mps: windMps, legal: windLegal },
      incidents: sortedIncidents,
      results: results.map((r) => ({ ...r })),
    };

    return {
      setup,
      seed: setup.seed,
      windMps,
      windLegal,
      attempts,
      finalAttemptIndex,
      totalSimDurationSec,
      athleteRuns,
      incidents: sortedIncidents,
      results,
      resultsPayload,
      laneIntros,
      commentaryCues,
      postRaceSummary,
    };
  }
}

export function sampleAthleteFrame200m(
  run: PlannedAthleteRun200m,
  raceTimeSec: number
): AthleteFrameSample200m {
  if (run.frames.length === 0) {
    return {
      distanceM: 0,
      speedMps: 0,
      lateralOffsetM: 0,
      pose: 'disappointed',
    };
  }
  if (raceTimeSec <= 0) {
    return run.frames[0];
  }
  const exactIdx = raceTimeSec * FIXED_HZ;
  const i0 = Math.min(run.frames.length - 1, Math.floor(exactIdx));
  const i1 = Math.min(run.frames.length - 1, i0 + 1);
  const alpha = exactIdx - i0;
  const f0 = run.frames[i0];
  const f1 = run.frames[i1];
  return {
    distanceM: f0.distanceM + (f1.distanceM - f0.distanceM) * alpha,
    speedMps: f0.speedMps + (f1.speedMps - f0.speedMps) * alpha,
    lateralOffsetM:
      f0.lateralOffsetM + (f1.lateralOffsetM - f0.lateralOffsetM) * alpha,
    pose: f0.pose,
  };
}
