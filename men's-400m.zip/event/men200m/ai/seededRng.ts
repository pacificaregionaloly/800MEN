/**
 * Deterministic seeded PRNG (Mulberry32) so the same setup payload + seed
 * produces the identical Men's 200m race, wind, incidents, and splits on every device.
 */
export class SeededRNG200m {
  private state: number;

  constructor(seed: number) {
    this.state = (seed | 0) ^ 0x9e3779b9;
    if (this.state === 0) this.state = 0x6d2b79f5;
  }

  /** Uniform float in [0, 1) */
  public next(): number {
    let t = (this.state += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  /** Uniform float in [min, max) */
  public range(min: number, max: number): number {
    return min + (max - min) * this.next();
  }

  /** Standard normal N(mean, stdDev^2) via Box-Muller */
  public gaussian(mean = 0, stdDev = 1): number {
    const u1 = Math.max(1e-7, this.next());
    const u2 = this.next();
    const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    return mean + z * stdDev;
  }

  /** Deterministic pick from non-empty array */
  public pick<T>(items: readonly T[]): T {
    return items[Math.floor(this.next() * items.length)];
  }
}
