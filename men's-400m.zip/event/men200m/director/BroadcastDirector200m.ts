import * as THREE from 'three';
import type { StadiumAPI } from '../../../src/api/StadiumAPI';
import type { RaceState200m } from '../api/types';

export type EventCameraId200m =
  | 'auto'
  | 'blocksHeadOn'
  | 'staggerOverview'
  | 'bendCam'
  | 'topDownOval'
  | 'trackingRail'
  | 'straightHeadOn'
  | 'finishLine'
  | 'photoFinish'
  | 'replayCam';

export interface LeaderCameraTarget200m {
  position: THREE.Vector3;
  heading: number;
  distanceM: number;
  onBend: boolean;
}

/**
 * Men's 200m broadcast camera director.
 * Covers staggered bend starts, dynamic West Bend tracking, top-down oval,
 * home straight head-on/rail, finish line, and photo finish.
 * Immediately yields to user mouse/wheel/touch so OrbitControls never fights.
 */
export class BroadcastDirector200m {
  private readonly stadium: StadiumAPI;
  private directorEnabled = true;
  private userTookOrbitControl = false;
  private selectedCamera: EventCameraId200m = 'auto';

  private readonly currentPos = new THREE.Vector3();
  private readonly currentTarget = new THREE.Vector3();
  private readonly desiredPos = new THREE.Vector3();
  private readonly desiredTarget = new THREE.Vector3();
  private currentFov = 44;
  private desiredFov = 44;
  private initializedCamera = false;

  private lastStadiumPreset: string;

  private readonly onUserPointer = () => {
    if (!this.userTookOrbitControl) {
      this.userTookOrbitControl = true;
      this.onStateChangeCallback?.();
    }
  };

  private onStateChangeCallback?: () => void;

  constructor(stadium: StadiumAPI, onStateChange?: () => void) {
    this.stadium = stadium;
    this.onStateChangeCallback = onStateChange;
    this.lastStadiumPreset = stadium.state.cameraPreset;

    const dom = stadium.renderer.domElement;
    dom.addEventListener('pointerdown', this.onUserPointer, { passive: true });
    dom.addEventListener('wheel', this.onUserPointer, { passive: true });
    dom.addEventListener('touchstart', this.onUserPointer, { passive: true });
  }

  public isDirectorEnabled(): boolean {
    return this.directorEnabled;
  }

  public hasUserOverride(): boolean {
    return this.userTookOrbitControl;
  }

  public getSelectedCamera(): EventCameraId200m {
    return this.selectedCamera;
  }

  public setDirectorEnabled(enabled: boolean): void {
    this.directorEnabled = enabled;
    if (enabled) {
      this.userTookOrbitControl = false;
      this.initializedCamera = false;
      this.lastStadiumPreset = this.stadium.state.cameraPreset;
    }
    this.onStateChangeCallback?.();
  }

  public selectCamera(camId: EventCameraId200m): void {
    this.selectedCamera = camId;
    this.directorEnabled = true;
    this.userTookOrbitControl = false;
    this.initializedCamera = false;
    if (camId === 'topDownOval') {
      this.stadium.cameras.goTo('overhead');
    }
    this.lastStadiumPreset = this.stadium.state.cameraPreset;
    this.onStateChangeCallback?.();
  }

  public resetView(): void {
    this.userTookOrbitControl = false;
    this.initializedCamera = false;
    this.selectedCamera = 'auto';
    this.directorEnabled = true;
    this.stadium.cameras.goTo('homeStraight');
    this.lastStadiumPreset = this.stadium.state.cameraPreset;
    this.onStateChangeCallback?.();
  }

  public update(
    raceState: RaceState200m,
    raceClockSec: number,
    isReplay: boolean,
    leader: LeaderCameraTarget200m | null,
    dt: number
  ): void {
    if (this.stadium.state.cameraPreset !== this.lastStadiumPreset) {
      this.lastStadiumPreset = this.stadium.state.cameraPreset;
      if (!this.userTookOrbitControl) {
        this.userTookOrbitControl = true;
        this.onStateChangeCallback?.();
      }
      return;
    }

    if (!this.directorEnabled || this.userTookOrbitControl) {
      return;
    }

    const activeCam = this.resolveActiveCamera(
      raceState,
      raceClockSec,
      isReplay,
      leader
    );
    const lx = leader ? leader.position.x : -42.2;
    const lz = leader ? leader.position.z : 0;

    switch (activeCam) {
      case 'staggerOverview':
        // High West-Bend stands perspective framing all 8 staggered starts from Lane 1 to Lane 8
        this.desiredPos.set(-86.0, 21.0, -14.0);
        this.desiredTarget.set(-55.0, 0.8, -36.5);
        this.desiredFov = 46;
        break;

      case 'blocksHeadOn':
        // Down the West Bend looking head-on into the angled staggered blocks toward Lane 4/5
        this.desiredPos.set(-82.5, 2.4, -22.5);
        this.desiredTarget.set(-55.0, 0.9, -37.8);
        this.desiredFov = 38;
        break;

      case 'bendCam': {
        if (leader && leader.onBend) {
          // Orbit smoothly outside the bend tangent following the pack around the curve
          const tx = Math.sin(leader.heading);
          const tz = Math.cos(leader.heading);
          // Outward radial vector (to runner's right = -tz, +tx)
          const outX = -tz;
          const outZ = tx;
          this.desiredPos.set(
            lx + outX * 11.5 - tx * 3.5,
            4.2,
            lz + outZ * 11.5 - tz * 3.5
          );
          this.desiredTarget.set(lx + tx * 2.5, 1.0, lz + tz * 2.5);
          this.desiredFov = 40;
        } else {
          // Exiting West Bend onto Home Straight
          this.desiredPos.set(-48.0, 4.5, 55.0);
          this.desiredTarget.set(-28.0, 1.0, 41.38);
          this.desiredFov = 40;
        }
        break;
      }

      case 'topDownOval':
        this.desiredPos.set(-12.0, 126.0, 0.5);
        this.desiredTarget.set(-12.0, 0.0, 0.0);
        this.desiredFov = 48;
        break;

      case 'trackingRail': {
        const clampedX = THREE.MathUtils.clamp(lx, -45, 43);
        this.desiredPos.set(clampedX - 1.5, 2.65, 54.0);
        this.desiredTarget.set(clampedX + 2.8, 1.05, 41.38);
        this.desiredFov = 40;
        break;
      }

      case 'straightHeadOn':
        this.desiredPos.set(49.5, 2.1, 41.38);
        this.desiredTarget.set(Math.min(35, lx), 1.0, 41.38);
        this.desiredFov = 34;
        break;

      case 'finishLine':
        this.desiredPos.set(47.2, 2.35, 49.6);
        this.desiredTarget.set(42.195, 1.05, 41.38);
        this.desiredFov = 35;
        break;

      case 'photoFinish':
        this.desiredPos.set(42.195, 1.85, 53.2);
        this.desiredTarget.set(42.195, 0.9, 40.5);
        this.desiredFov = 24;
        break;

      case 'replayCam': {
        const clampedX = THREE.MathUtils.clamp(lx, -58, 45);
        this.desiredPos.set(50.5, 1.85, 34.4);
        this.desiredTarget.set(clampedX, 1.0, 41.38);
        this.desiredFov = 36;
        break;
      }
    }

    if (!this.initializedCamera) {
      this.currentPos.copy(this.stadium.camera.position);
      this.currentTarget.copy(this.desiredTarget);
      this.currentFov = this.stadium.camera.fov;
      this.initializedCamera = true;
    }

    const lambda =
      activeCam === 'trackingRail' || activeCam === 'bendCam' ? 7.5 : 5.2;
    const alpha = 1 - Math.exp(-lambda * Math.max(0.001, dt));
    this.currentPos.lerp(this.desiredPos, alpha);
    this.currentTarget.lerp(this.desiredTarget, alpha);
    this.currentFov += (this.desiredFov - this.currentFov) * alpha;

    this.stadium.camera.position.copy(this.currentPos);
    if (Math.abs(this.stadium.camera.fov - this.currentFov) > 0.02) {
      this.stadium.camera.fov = this.currentFov;
      this.stadium.camera.updateProjectionMatrix();
    }
    this.stadium.camera.lookAt(this.currentTarget);
  }

  private resolveActiveCamera(
    raceState: RaceState200m,
    raceClockSec: number,
    isReplay: boolean,
    leader: LeaderCameraTarget200m | null
  ): Exclude<EventCameraId200m, 'auto'> {
    if (this.selectedCamera !== 'auto') {
      return this.selectedCamera;
    }
    if (isReplay) {
      if (raceClockSec < 11.4) return 'bendCam';
      return raceClockSec > 18.2 ? 'photoFinish' : 'replayCam';
    }
    switch (raceState) {
      case 'WAITING_FOR_API':
      case 'SETUP_RECEIVED':
      case 'VALIDATED':
      case 'ATHLETES_ON_TRACK':
      case 'READY':
      case 'ON_YOUR_MARKS':
      case 'FALSE_START_RECALL':
        return 'staggerOverview';
      case 'SET':
        return 'blocksHeadOn';
      case 'RUNNING': {
        if (raceClockSec < 2.6) return 'blocksHeadOn';
        if (leader ? leader.distanceM < 116 : raceClockSec < 11.5) return 'bendCam';
        if (leader ? leader.distanceM < 182 : raceClockSec < 18.2) return 'trackingRail';
        return 'finishLine';
      }
      case 'FINISHED':
      case 'RESULTS_POSTED':
        return 'finishLine';
      default:
        return 'staggerOverview';
    }
  }

  public dispose(): void {
    const dom = this.stadium.renderer.domElement;
    dom.removeEventListener('pointerdown', this.onUserPointer);
    dom.removeEventListener('wheel', this.onUserPointer);
    dom.removeEventListener('touchstart', this.onUserPointer);
  }
}
