import type { IncidentConfigRates200m } from '../config/incidents';
import type {
  RaceCommand200m,
  RaceResultsPayload200m,
  RaceSetupPayload200m,
  RaceStatusUpdate200m,
} from './types';
import type { WavesportsApiClient200m } from './WavesportsApiClient';

const SAMPLE_SETUP_200M: RaceSetupPayload200m = {
  raceId: 'men-200m-final-1',
  event: 'men_200m',
  round: 'final',
  heat: 1,
  seed: 739204,
  scheduledStartTime: null,
  allowManualStart: true,
  venue: 'Klemonserrat Stadium',
  rules: {
    falseStartDisqualifies: true,
    windLimitMps: 2.0,
  },
  incidentOverrides: null,
  athletes: [
    {
      athleteId: 'ath_201',
      lane: 1,
      name: 'Kitione Wari',
      shortName: 'WARI',
      nation: 'Papua New Guinea',
      nationCode: 'PNG',
      bib: '201',
      kit: { primary: '#CE1126', secondary: '#FCD116', accent: '#111827' },
      ratings: {
        reaction: 75,
        acceleration: 78,
        topSpeed: 82,
        speedEndurance: 81,
        consistency: 78,
        composure: 77,
        durability: 82,
        technique: 76,
      },
      personalBest: 20.42,
      seasonBest: 20.51,
      status: 'active',
    },
    {
      athleteId: 'ath_202',
      lane: 2,
      name: 'Ratu Jone Naisara',
      shortName: 'NAISARA',
      nation: 'Fiji',
      nationCode: 'FIJ',
      bib: '202',
      kit: { primary: '#002868', secondary: '#68BFE5', accent: '#FFFFFF' },
      ratings: {
        reaction: 79,
        acceleration: 82,
        topSpeed: 85,
        speedEndurance: 84,
        consistency: 81,
        composure: 79,
        durability: 83,
        technique: 82,
      },
      personalBest: 20.19,
      seasonBest: 20.26,
      status: 'active',
    },
    {
      athleteId: 'ath_203',
      lane: 3,
      name: 'Sione Vaioleti',
      shortName: 'VAIOLETI',
      nation: 'Tonga',
      nationCode: 'TON',
      bib: '203',
      kit: { primary: '#C10000', secondary: '#FFFFFF', accent: '#F5C542' },
      ratings: {
        reaction: 81,
        acceleration: 86,
        topSpeed: 89,
        speedEndurance: 87,
        consistency: 84,
        composure: 82,
        durability: 85,
        technique: 86,
      },
      personalBest: 20.04,
      seasonBest: 20.11,
      status: 'active',
    },
    {
      athleteId: 'ath_204',
      lane: 4,
      name: 'Liam Henderson',
      shortName: 'HENDERSON',
      nation: 'Australia',
      nationCode: 'AUS',
      bib: '204',
      kit: { primary: '#00843D', secondary: '#FFCD00', accent: '#FFFFFF' },
      ratings: {
        reaction: 84,
        acceleration: 88,
        topSpeed: 93,
        speedEndurance: 92,
        consistency: 88,
        composure: 86,
        durability: 87,
        technique: 90,
      },
      personalBest: 19.86,
      seasonBest: 19.93,
      status: 'active',
    },
    {
      athleteId: 'ath_205',
      lane: 5,
      name: 'Kaelen Tuiasosopo',
      shortName: 'TUIASOSOPO',
      nation: 'New Pleadland',
      nationCode: 'NPL',
      bib: '205',
      kit: { primary: '#0033A0', secondary: '#FFFFFF', accent: '#D4AF37' },
      ratings: {
        reaction: 86,
        acceleration: 90,
        topSpeed: 95,
        speedEndurance: 91,
        consistency: 89,
        composure: 87,
        durability: 86,
        technique: 92,
      },
      personalBest: 19.79,
      seasonBest: 19.85,
      status: 'active',
    },
    {
      athleteId: 'ath_206',
      lane: 6,
      name: 'Tane Te Aho',
      shortName: 'TE AHO',
      nation: 'New Zealand',
      nationCode: 'NZL',
      bib: '206',
      kit: { primary: '#111827', secondary: '#FFFFFF', accent: '#94A3B8' },
      ratings: {
        reaction: 82,
        acceleration: 86,
        topSpeed: 90,
        speedEndurance: 88,
        consistency: 85,
        composure: 83,
        durability: 84,
        technique: 87,
      },
      personalBest: 19.98,
      seasonBest: 20.05,
      status: 'active',
    },
    {
      athleteId: 'ath_207',
      lane: 7,
      name: 'Malakai Ravouvou',
      shortName: 'RAVOUVOU',
      nation: 'Samoa',
      nationCode: 'SAM',
      bib: '207',
      kit: { primary: '#002B7F', secondary: '#CE1126', accent: '#FFFFFF' },
      ratings: {
        reaction: 78,
        acceleration: 84,
        topSpeed: 88,
        speedEndurance: 85,
        consistency: 80,
        composure: 75,
        durability: 82,
        technique: 83,
      },
      personalBest: 20.14,
      seasonBest: 20.22,
      status: 'active',
    },
    {
      athleteId: 'ath_208',
      lane: 8,
      name: 'Reuben Manuleleua',
      shortName: 'MANULELEUA',
      nation: 'Solomon Islands',
      nationCode: 'SOL',
      bib: '208',
      kit: { primary: '#0051BA', secondary: '#215B33', accent: '#FCD116' },
      ratings: {
        reaction: 76,
        acceleration: 80,
        topSpeed: 84,
        speedEndurance: 82,
        consistency: 79,
        composure: 78,
        durability: 83,
        technique: 80,
      },
      personalBest: 20.36,
      seasonBest: 20.44,
      status: 'active',
    },
  ],
};

/**
 * Dev-only Mock Wavesports API for Men's 200m.
 * Off by default; enabled only via ?mock=1 or MOCK_API=true in dev builds.
 */
export class MockWavesportsApi200m implements WavesportsApiClient200m {
  public readonly modeLabel = 'MOCK API – DEV ONLY';
  public readonly isMock = true;

  private commandQueue: RaceCommand200m[] = [];
  private statusHistory: RaceStatusUpdate200m[] = [];
  private lastResults: RaceResultsPayload200m | null = null;
  private seedOverride: number | null;
  private cleanRace: boolean;

  constructor(options?: { seedOverride?: number | null; cleanRace?: boolean }) {
    if (!import.meta.env.DEV) {
      throw new Error(
        'MockWavesportsApi200m is strictly disabled in production builds.'
      );
    }
    this.seedOverride = options?.seedOverride ?? null;
    this.cleanRace = Boolean(options?.cleanRace);
  }

  public enqueueCommand(command: RaceCommand200m): void {
    this.commandQueue.push(command);
  }

  public setSeed(seed: number): void {
    this.seedOverride = Math.round(seed);
  }

  public getStatusHistory(): RaceStatusUpdate200m[] {
    return [...this.statusHistory];
  }

  public getLastResults(): RaceResultsPayload200m | null {
    return this.lastResults;
  }

  public async fetchSetup(raceId: string): Promise<RaceSetupPayload200m> {
    await new Promise((r) => setTimeout(r, 220));
    const incidentOverrides: Partial<IncidentConfigRates200m> | null = this.cleanRace
      ? {
          falseStartBaseRate: 0,
          stumbledStartRate: 0,
          fallOrTripRate: 0,
          injuryPullUpRate: 0,
          laneViolationRate: 0,
          collisionBrushRate: 0,
          lateDnsRate: 0,
          equipmentBlockSlipRate: 0,
        }
      : null;

    return {
      ...SAMPLE_SETUP_200M,
      raceId: raceId || SAMPLE_SETUP_200M.raceId,
      seed: this.seedOverride ?? SAMPLE_SETUP_200M.seed,
      incidentOverrides,
      athletes: SAMPLE_SETUP_200M.athletes.map((a) => ({
        ...a,
        kit: { ...a.kit },
        ratings: { ...a.ratings },
      })),
    };
  }

  public async pollCommands(): Promise<RaceCommand200m[]> {
    if (this.commandQueue.length === 0) return [];
    const items = [...this.commandQueue];
    this.commandQueue = [];
    return items;
  }

  public async postStatus(
    _raceId: string,
    update: RaceStatusUpdate200m
  ): Promise<void> {
    this.statusHistory.push({
      ...update,
      timestamp: update.timestamp ?? new Date().toISOString(),
    });
  }

  public async postResults(
    _raceId: string,
    results: RaceResultsPayload200m
  ): Promise<void> {
    this.lastResults = results;
    console.info('[MockWavesportsApi200m] Results received:', results);
  }
}
