import type { IncidentConfigRates_Men400m } from '../config/incidents';

export type RaceState_Men400m =
  | 'WAITING_FOR_API'
  | 'SETUP_RECEIVED'
  | 'VALIDATED'
  | 'ATHLETES_ON_TRACK'
  | 'READY'
  | 'ON_YOUR_MARKS'
  | 'SET'
  | 'RUNNING'
  | 'FALSE_START_RECALL'
  | 'FINISHED'
  | 'RESULTS_POSTED';

export type PacingStrategy_Men400m =
  | 'fast_out'
  | 'even_paced'
  | 'controlled_finish';

export interface AthleteKit_Men400m {
  primary: string;
  secondary: string;
  accent: string;
}

export interface AthleteRatings_Men400m {
  reaction: number;
  acceleration: number;
  topSpeed: number;
  speedEndurance: number;
  consistency: number;
  composure: number;
  durability: number;
  technique: number;
}

export type AthleteInitialStatus_Men400m = 'active' | 'dns';

export interface AthleteSetup_Men400m {
  athleteId: string;
  lane: number;
  name: string;
  shortName: string;
  nation: string;
  nationCode: string;
  bib: string;
  kit: AthleteKit_Men400m;
  ratings: AthleteRatings_Men400m;
  personalBest?: number;
  seasonBest?: number;
  status: AthleteInitialStatus_Men400m;
}

export interface RaceRules_Men400m {
  falseStartDisqualifies: boolean;
  windLimitMps: number;
}

export interface RaceSetupPayload_Men400m {
  raceId: string;
  event: 'men_400m';
  round: string;
  heat: number;
  seed: number;
  scheduledStartTime?: string | null;
  allowManualStart: boolean;
  venue: string;
  rules: RaceRules_Men400m;
  incidentOverrides?: Partial<IncidentConfigRates_Men400m> | null;
  athletes: AthleteSetup_Men400m[];
}

export type RaceCommand_Men400m =
  | { command: 'start'; issuedAt: string }
  | { command: 'abort'; reason?: string }
  | { command: 'reset' };

export interface RaceStatusUpdate_Men400m {
  status: string;
  athleteId?: string;
  detail?: string;
  timestamp?: string;
}

export type IncidentType_Men400m =
  | 'false_start'
  | 'stumbled_start'
  | 'fall'
  | 'injury'
  | 'lane_violation'
  | 'fatigue_collapse'
  | 'collision'
  | 'late_dns'
  | 'equipment_issue'
  | 'great_performance';

export interface RaceIncidentRecord_Men400m {
  type: IncidentType_Men400m;
  code: string;
  athleteId: string | null;
  lane: number | null;
  attempt: number;
  atTime: number;
  detail: string;
}

export type AthleteResultStatus_Men400m = 'finished' | 'DQ' | 'DNF' | 'DNS';

export interface AthleteRaceResult_Men400m {
  rank: number | null;
  lane: number;
  athleteId: string;
  name: string;
  shortName: string;
  nation: string;
  nationCode: string;
  bib: string;
  time?: number;
  exactTime?: number;
  reactionTime?: number;
  splits?: {
    '100': number;
    '200': number;
    '300': number;
  };
  firstHalf?: number;
  secondHalf?: number;
  topSpeedMps?: number;
  pacingStrategy?: PacingStrategy_Men400m;
  status: AthleteResultStatus_Men400m;
  reason?: string;
  notes: string[];
}

export interface RaceResultsPayload_Men400m {
  raceId: string;
  seed: number;
  completedAt: string;
  wind: {
    mps: number;
    legal: boolean;
  };
  incidents: RaceIncidentRecord_Men400m[];
  results: AthleteRaceResult_Men400m[];
}
