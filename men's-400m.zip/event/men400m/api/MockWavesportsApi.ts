import type { IncidentConfigRates_Men400m } from '../config/incidents';
import type {
  RaceCommand_Men400m,
  RaceResultsPayload_Men400m,
  RaceSetupPayload_Men400m,
  RaceStatusUpdate_Men400m,
} from './types';
import type { WavesportsApiClient_Men400m } from './WavesportsApiClient';

const SAMPLE_SETUP_MEN400M: RaceSetupPayload_Men400m = {
  raceId: 'men-400m-final-1',
  event: 'men_400m',
  round: 'final',
  heat: 1,
  seed: 400826,
  scheduledStartTime: null,
  allowManualStart: true,
  venue: 'Klemonserrat Stadium',
  rules: {
    falseStartDisqualifies: true,
    windLimitMps: 2.0,
  },
  incidentOverrides: null,
  athletes: [
    {
      athleteId: 'ath_401',
      lane: 1,
      name: 'Mose Kaukau',
      shortName: 'KAUKAU',
      nation: 'Papua New Guinea',
      nationCode: 'PNG',
      bib: '401',
      kit: { primary: '#CE1126', secondary: '#FCD116', accent: '#111827' },
      ratings: {
        reaction: 76,
        acceleration: 79,
        topSpeed: 82,
        speedEndurance: 84,
        consistency: 80,
        composure: 79,
        durability: 84,
        technique: 78,
      },
      personalBest: 45.48,
      seasonBest: 45.62,
      status: 'active',
    },
    {
      athleteId: 'ath_402',
      lane: 2,
      name: 'Iliesa Koroi',
      shortName: 'KOROI',
      nation: 'Fiji',
      nationCode: 'FIJ',
      bib: '402',
      kit: { primary: '#002868', secondary: '#68BFE5', accent: '#FFFFFF' },
      ratings: {
        reaction: 80,
        acceleration: 82,
        topSpeed: 86,
        speedEndurance: 88,
        consistency: 83,
        composure: 82,
        durability: 85,
        technique: 83,
      },
      personalBest: 44.96,
      seasonBest: 45.12,
      status: 'active',
    },
    {
      athleteId: 'ath_403',
      lane: 3,
      name: 'Tevita Faleafa',
      shortName: 'FALEAFA',
      nation: 'Tonga',
      nationCode: 'TON',
      bib: '403',
      kit: { primary: '#C10000', secondary: '#FFFFFF', accent: '#F5C542' },
      ratings: {
        reaction: 81,
        acceleration: 85,
        topSpeed: 89,
        speedEndurance: 89,
        consistency: 85,
        composure: 84,
        durability: 86,
        technique: 85,
      },
      personalBest: 44.62,
      seasonBest: 44.78,
      status: 'active',
    },
    {
      athleteId: 'ath_404',
      lane: 4,
      name: 'Callum McAllister',
      shortName: 'MCALLISTER',
      nation: 'Australia',
      nationCode: 'AUS',
      bib: '404',
      kit: { primary: '#00843D', secondary: '#FFCD00', accent: '#FFFFFF' },
      ratings: {
        reaction: 84,
        acceleration: 87,
        topSpeed: 93,
        speedEndurance: 94,
        consistency: 90,
        composure: 88,
        durability: 89,
        technique: 90,
      },
      personalBest: 44.08,
      seasonBest: 44.19,
      status: 'active',
    },
    {
      athleteId: 'ath_405',
      lane: 5,
      name: 'Nikau Tamati',
      shortName: 'TAMATI',
      nation: 'New Pleadland',
      nationCode: 'NPL',
      bib: '405',
      kit: { primary: '#0033A0', secondary: '#FFFFFF', accent: '#D4AF37' },
      ratings: {
        reaction: 85,
        acceleration: 89,
        topSpeed: 94,
        speedEndurance: 95,
        consistency: 91,
        composure: 89,
        durability: 88,
        technique: 92,
      },
      personalBest: 43.94,
      seasonBest: 44.05,
      status: 'active',
    },
    {
      athleteId: 'ath_406',
      lane: 6,
      name: 'Wiremu Henare',
      shortName: 'HENARE',
      nation: 'New Zealand',
      nationCode: 'NZL',
      bib: '406',
      kit: { primary: '#111827', secondary: '#FFFFFF', accent: '#94A3B8' },
      ratings: {
        reaction: 82,
        acceleration: 86,
        topSpeed: 90,
        speedEndurance: 91,
        consistency: 86,
        composure: 85,
        durability: 86,
        technique: 88,
      },
      personalBest: 44.41,
      seasonBest: 44.55,
      status: 'active',
    },
    {
      athleteId: 'ath_407',
      lane: 7,
      name: 'Aleki Tuipulotu',
      shortName: 'TUIPULOTU',
      nation: 'Samoa',
      nationCode: 'SAM',
      bib: '407',
      kit: { primary: '#002B7F', secondary: '#CE1126', accent: '#FFFFFF' },
      ratings: {
        reaction: 79,
        acceleration: 84,
        topSpeed: 88,
        speedEndurance: 86,
        consistency: 81,
        composure: 78,
        durability: 83,
        technique: 84,
      },
      personalBest: 44.85,
      seasonBest: 45.02,
      status: 'active',
    },
    {
      athleteId: 'ath_408',
      lane: 8,
      name: 'Benson Maenu',
      shortName: 'MAENU',
      nation: 'Solomon Islands',
      nationCode: 'SOL',
      bib: '408',
      kit: { primary: '#0051BA', secondary: '#215B33', accent: '#FCD116' },
      ratings: {
        reaction: 77,
        acceleration: 80,
        topSpeed: 85,
        speedEndurance: 85,
        consistency: 81,
        composure: 80,
        durability: 84,
        technique: 81,
      },
      personalBest: 45.28,
      seasonBest: 45.44,
      status: 'active',
    },
  ],
};

/**
 * Dev-only Mock Wavesports API for Men's 400 Metres.
 * Off by default; enabled only via ?mock=1 or MOCK_API=true in dev builds.
 */
export class MockWavesportsApi_Men400m implements WavesportsApiClient_Men400m {
  public readonly modeLabel = 'MOCK API – DEV ONLY';
  public readonly isMock = true;

  private commandQueue: RaceCommand_Men400m[] = [];
  private statusHistory: RaceStatusUpdate_Men400m[] = [];
  private lastResults: RaceResultsPayload_Men400m | null = null;
  private seedOverride: number | null;
  private cleanRace: boolean;

  constructor(options?: { seedOverride?: number | null; cleanRace?: boolean }) {
    if (!import.meta.env.DEV) {
      throw new Error(
        'MockWavesportsApi_Men400m is strictly disabled in production builds.'
      );
    }
    this.seedOverride = options?.seedOverride ?? null;
    this.cleanRace = Boolean(options?.cleanRace);
  }

  public enqueueCommand(command: RaceCommand_Men400m): void {
    this.commandQueue.push(command);
  }

  public setSeed(seed: number): void {
    this.seedOverride = Math.round(seed);
  }

  public getStatusHistory(): RaceStatusUpdate_Men400m[] {
    return [...this.statusHistory];
  }

  public getLastResults(): RaceResultsPayload_Men400m | null {
    return this.lastResults;
  }

  public async fetchSetup(raceId: string): Promise<RaceSetupPayload_Men400m> {
    await new Promise((r) => setTimeout(r, 220));
    const incidentOverrides: Partial<IncidentConfigRates_Men400m> | null =
      this.cleanRace
        ? {
            falseStartBaseRate: 0,
            stumbledStartRate: 0,
            fallOrTripRate: 0,
            injuryPullUpRate: 0,
            laneViolationRate: 0,
            fatigueCollapseRate: 0,
            collisionBrushRate: 0,
            lateDnsRate: 0,
            equipmentBlockSlipRate: 0,
          }
        : null;

    return {
      ...SAMPLE_SETUP_MEN400M,
      raceId: raceId || SAMPLE_SETUP_MEN400M.raceId,
      seed: this.seedOverride ?? SAMPLE_SETUP_MEN400M.seed,
      incidentOverrides,
      athletes: SAMPLE_SETUP_MEN400M.athletes.map((a) => ({
        ...a,
        kit: { ...a.kit },
        ratings: { ...a.ratings },
      })),
    };
  }

  public async pollCommands(): Promise<RaceCommand_Men400m[]> {
    if (this.commandQueue.length === 0) return [];
    const items = [...this.commandQueue];
    this.commandQueue = [];
    return items;
  }

  public async postStatus(
    _raceId: string,
    update: RaceStatusUpdate_Men400m
  ): Promise<void> {
    this.statusHistory.push({
      ...update,
      timestamp: update.timestamp ?? new Date().toISOString(),
    });
  }

  public async postResults(
    _raceId: string,
    results: RaceResultsPayload_Men400m
  ): Promise<void> {
    this.lastResults = results;
    console.info('[MockWavesportsApi_Men400m] Results received:', results);
  }
}
