import type { StadiumAPI } from '../../../src/api/StadiumAPI';

export const FIXED_TIMESTEP_HZ_MEN400M = 30;
export const FIXED_DT_MEN400M = 1 / FIXED_TIMESTEP_HZ_MEN400M;

export type FixedUpdateCallback_Men400m = (
  simTimeSec: number,
  fixedDt: number
) => void;
export type RenderInterpolationCallback_Men400m = (
  alpha: number,
  frameElapsedSec: number,
  rawDt: number
) => void;

export interface SimClockAPI_Men400m {
  pause: () => void;
  resume: () => void;
  isPaused: () => boolean;
  setTimeScale: (scale: number) => void;
  getTimeScale: () => number;
  getSimTime: () => number;
  resetSimTime: (toSeconds?: number) => void;
  addFixedUpdateCallback: (fn: FixedUpdateCallback_Men400m) => () => void;
  addRenderCallback: (fn: RenderInterpolationCallback_Men400m) => () => void;
  dispose: () => void;
}

/**
 * Deterministic 30 Hz fixed-timestep simulation loop layered over
 * `stadium.addUpdateCallback` without modifying the stadium's SceneController.
 */
export function createFixedStepLoop_Men400m(
  stadium: StadiumAPI
): SimClockAPI_Men400m {
  let paused = false;
  let timeScale = 1.0;
  let simTime = 0;
  let accumulator = 0;

  const fixedCallbacks = new Set<FixedUpdateCallback_Men400m>();
  const renderCallbacks = new Set<RenderInterpolationCallback_Men400m>();

  const unsubscribeStadium = stadium.addUpdateCallback((elapsed, dt) => {
    const safeDt = Math.min(0.1, Math.max(0, dt));

    if (!paused) {
      accumulator += safeDt * timeScale;
      let steps = 0;
      while (accumulator >= FIXED_DT_MEN400M && steps < 12) {
        simTime += FIXED_DT_MEN400M;
        accumulator -= FIXED_DT_MEN400M;
        fixedCallbacks.forEach((fn) => fn(simTime, FIXED_DT_MEN400M));
        steps++;
      }
      if (steps >= 12) {
        accumulator = 0;
      }
    }

    const alpha = Math.max(0, Math.min(1, accumulator / FIXED_DT_MEN400M));
    renderCallbacks.forEach((fn) => fn(alpha, elapsed, safeDt));
  });

  return {
    pause: () => {
      paused = true;
    },
    resume: () => {
      paused = false;
    },
    isPaused: () => paused,
    setTimeScale: (scale: number) => {
      timeScale = Math.max(0.05, Math.min(4.0, scale));
    },
    getTimeScale: () => timeScale,
    getSimTime: () => simTime,
    resetSimTime: (toSeconds = 0) => {
      simTime = toSeconds;
      accumulator = 0;
    },
    addFixedUpdateCallback: (fn) => {
      fixedCallbacks.add(fn);
      return () => fixedCallbacks.delete(fn);
    },
    addRenderCallback: (fn) => {
      renderCallbacks.add(fn);
      return () => renderCallbacks.delete(fn);
    },
    dispose: () => {
      unsubscribeStadium();
      fixedCallbacks.clear();
      renderCallbacks.clear();
    },
  };
}
