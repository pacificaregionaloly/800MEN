import type {
  AthleteRaceResult_Men400m,
  AthleteSetup_Men400m,
  PacingStrategy_Men400m,
  RaceIncidentRecord_Men400m,
  RaceSetupPayload_Men400m,
} from '../api/types';
import { SeededRNG_Men400m } from './seededRng';

export interface CommentaryCue_Men400m {
  atRaceTime: number;
  headline: string;
  line: string;
  phase: 'intro' | 'start' | 'recall' | 'live' | 'incident' | 'finish' | 'post';
}

export interface CommentaryContext_Men400m {
  setup: RaceSetupPayload_Men400m;
  windMps: number;
  incidents: RaceIncidentRecord_Men400m[];
  results: AthleteRaceResult_Men400m[];
}

/**
 * Pluggable Commentary Generator interface so template generation can later
 * be swapped with an LLM-backed implementation.
 */
export interface CommentaryGenerator_Men400m {
  generateLaneIntro(
    athlete: AthleteSetup_Men400m,
    setup: RaceSetupPayload_Men400m
  ): string;
  generateStartPrompt(
    stage: 'on_your_marks' | 'set' | 'gun',
    attempt: number
  ): string;
  generateIncidentCall(
    incident: RaceIncidentRecord_Men400m,
    athlete: AthleteSetup_Men400m | undefined
  ): string;
  generateRaceCues(
    ctx: CommentaryContext_Men400m,
    snapshots: {
      leaderAt100?: AthleteSetup_Men400m;
      leaderAt200?: AthleteSetup_Men400m;
      leaderAt300?: AthleteSetup_Men400m;
      leaderAtHomeEntry?: AthleteSetup_Men400m;
      fadingRunner?: AthleteSetup_Men400m;
      pacingById: Map<string, PacingStrategy_Men400m>;
    },
    rng: SeededRNG_Men400m
  ): CommentaryCue_Men400m[];
  generatePostRaceSummary(ctx: CommentaryContext_Men400m): string;
}

export class TemplateCommentaryGenerator_Men400m
  implements CommentaryGenerator_Men400m
{
  public generateLaneIntro(
    athlete: AthleteSetup_Men400m,
    setup: RaceSetupPayload_Men400m
  ): string {
    const pbStr = athlete.personalBest
      ? `PB ${athlete.personalBest.toFixed(2)}s`
      : "Pacifica Men's 400m contender";
    const sbStr = athlete.seasonBest
      ? ` · SB ${athlete.seasonBest.toFixed(2)}s`
      : '';
    return `Lane ${athlete.lane} (400m stagger): ${athlete.name} (${athlete.nationCode}) — ${pbStr}${sbStr} · ${setup.round.toUpperCase()} Heat ${setup.heat}`;
  }

  public generateStartPrompt(
    stage: 'on_your_marks' | 'set' | 'gun',
    attempt: number
  ): string {
    const restartTag = attempt > 0 ? ` (Restart #${attempt})` : '';
    if (stage === 'on_your_marks') {
      return `The men's 400m field settles into the staggered blocks along the first bend${restartTag}.`;
    }
    if (stage === 'set') {
      return `Set… coiled for one full lap around Klemonserrat Stadium${restartTag}.`;
    }
    return `BANG! Clean break — the Men's 400 Metres is underway for one full lap!`;
  }

  public generateIncidentCall(
    incident: RaceIncidentRecord_Men400m,
    athlete: AthleteSetup_Men400m | undefined
  ): string {
    const who = athlete
      ? `${athlete.shortName} (Lane ${athlete.lane}, ${athlete.nationCode})`
      : 'Track official alert';
    switch (incident.type) {
      case 'false_start':
        return `RECALL GUN! False start charged to ${who} (${incident.atTime.toFixed(
          3
        )}s) — he sees the red card!`;
      case 'equipment_issue':
        return `RECALL! Starting block slip in Lane ${
          incident.lane ?? '?'
        } — the men's field returns to the blocks, no penalty.`;
      case 'stumbled_start':
        return `${who} stumbles pushing out of the angled blocks and fights to recover his stride!`;
      case 'fall':
        return `DRAMA ON THE BEND! ${who} loses his footing on the curve and goes down — he is DNF!`;
      case 'injury':
        return `${who} pulls up clutching his hamstring on the back half and limps to a halt (DNF).`;
      case 'lane_violation':
        return `Bend judges flag a lane-line infringement on ${who} as he rounds the curve.`;
      case 'fatigue_collapse':
        return `${who} is tying up heavily in the final 100 m — his legs give way after a blistering early pace!`;
      case 'collision':
        return `Tight shoulder brush on the bend involving ${who} as runners track their lanes!`;
      case 'late_dns':
        return `Late withdrawal in the call room: ${who} is scratched before the men's final (DNS).`;
      case 'great_performance':
        return `REMARKABLE LAP! ${who} is powering clear through the final bend and home straight!`;
    }
  }

  public generateRaceCues(
    ctx: CommentaryContext_Men400m,
    snapshots: {
      leaderAt100?: AthleteSetup_Men400m;
      leaderAt200?: AthleteSetup_Men400m;
      leaderAt300?: AthleteSetup_Men400m;
      leaderAtHomeEntry?: AthleteSetup_Men400m;
      fadingRunner?: AthleteSetup_Men400m;
      pacingById: Map<string, PacingStrategy_Men400m>;
    },
    rng: SeededRNG_Men400m
  ): CommentaryCue_Men400m[] {
    const cues: CommentaryCue_Men400m[] = [];
    const finishers = ctx.results.filter((r) => r.status === 'finished');
    const winner = finishers[0];
    const runnerUp = finishers[1];

    cues.push({
      atRaceTime: 0.0,
      headline: "AWAY IN THE MEN'S 400 METRES!",
      line: rng.pick([
        "Clean start! Eight men drive out across the full-lap stagger in the Men's 400 Metres!",
        'The gun cracks across Klemonserrat Stadium and the men charge into the first bend!',
        'Every runner stays in his own lane for one full 400-metre lap!',
      ]),
      phase: 'live',
    });

    if (snapshots.leaderAt100) {
      const a = snapshots.leaderAt100;
      const strat = snapshots.pacingById.get(a.athleteId);
      const paceNote =
        strat === 'fast_out'
          ? 'He is attacking hard early!'
          : 'Smooth rhythm off the first bend.';
      cues.push({
        atRaceTime: 11.2,
        headline: '100M — LEADING ON THE STAGGER',
        line: `${a.name} (${a.nationCode}, Lane ${a.lane}) leads on the stagger onto the back straight! ${paceNote}`,
        phase: 'live',
      });
    }

    cues.push({
      atRaceTime: 16.5,
      headline: 'DOWN THE BACK STRAIGHT',
      line: 'Halfway down the back straight — the men settle into their 400 m cruising gears.',
      phase: 'live',
    });

    if (snapshots.leaderAt200) {
      const b = snapshots.leaderAt200;
      cues.push({
        atRaceTime: 21.6,
        headline: '200M SPLIT — INTO THE FINAL BEND',
        line: `${b.shortName} (${b.nationCode}, Lane ${b.lane}) hits 200 m first as the men's field enters the final bend!`,
        phase: 'live',
      });
    }

    if (snapshots.leaderAt300) {
      const c = snapshots.leaderAt300;
      const leadChanged =
        snapshots.leaderAt200 &&
        snapshots.leaderAt200.athleteId !== c.athleteId;
      cues.push({
        atRaceTime: 32.5,
        headline: leadChanged
          ? 'LEAD CHANGE AT 300M!'
          : '300M — APPROACHING HOME STRAIGHT!',
        line: leadChanged
          ? `${c.shortName} surges past on the final bend to seize command at 300 m!`
          : `${c.shortName} holds the stagger advantage coming off the final bend at 300 m!`,
        phase: 'live',
      });
    }

    if (snapshots.leaderAtHomeEntry) {
      const d = snapshots.leaderAtHomeEntry;
      cues.push({
        atRaceTime: 34.8,
        headline: 'ENTERING THE HOME STRAIGHT!',
        line: `${d.shortName} (${d.nationCode}) swings onto the home straight first — now the stagger unwinds and the true order appears!`,
        phase: 'live',
      });
    }

    if (snapshots.fadingRunner) {
      const f = snapshots.fadingRunner;
      cues.push({
        atRaceTime: 38.2,
        headline: 'TYING UP IN THE FINAL 100M!',
        line: `${f.shortName} (Lane ${f.lane}) is fighting lactic acid now, his stride shortening down the home straight!`,
        phase: 'live',
      });
    }

    // Live calls for in-race incidents
    ctx.incidents.forEach((inc) => {
      if (
        inc.type === 'stumbled_start' ||
        inc.type === 'fall' ||
        inc.type === 'injury' ||
        inc.type === 'collision' ||
        inc.type === 'lane_violation' ||
        inc.type === 'fatigue_collapse' ||
        inc.type === 'great_performance'
      ) {
        const ath = ctx.setup.athletes.find(
          (a) => a.athleteId === inc.athleteId
        );
        cues.push({
          atRaceTime: Math.max(0.25, inc.atTime),
          headline: inc.type.replace(/_/g, ' ').toUpperCase(),
          line: this.generateIncidentCall(inc, ath),
          phase: 'incident',
        });
      }
    });

    if (winner) {
      const margin =
        runnerUp && winner.exactTime && runnerUp.exactTime
          ? runnerUp.exactTime - winner.exactTime
          : null;
      const winTime = (winner.time ?? 0).toFixed(2);
      const isPhoto = margin !== null && margin < 0.04;
      const windTag = `Wind ${ctx.windMps >= 0 ? '+' : ''}${ctx.windMps.toFixed(
        1
      )} m/s (info)`;

      cues.push({
        atRaceTime: Math.max(41.5, winner.time ?? 44.2),
        headline: isPhoto
          ? 'PHOTO FINISH IN THE 400M!'
          : `${winner.shortName} WINS MEN'S 400M GOLD!`,
        line:
          isPhoto && runnerUp
            ? `Photo finish at the line! ${winner.name} (${winner.nationCode}) dips ahead of ${runnerUp.shortName} in ${winTime}s (${(
                margin! * 1000
              ).toFixed(0)} ms) · ${windTag}`
            : `${winner.name} (${winner.nationCode}) storms home to win the Men's 400 Metres in ${winTime}s! · ${windTag}`,
        phase: 'finish',
      });
    }

    cues.sort((a, b) => a.atRaceTime - b.atRaceTime);
    return cues;
  }

  public generatePostRaceSummary(ctx: CommentaryContext_Men400m): string {
    const finishers = ctx.results.filter((r) => r.status === 'finished');
    const windStr = `Wind ${ctx.windMps >= 0 ? '+' : ''}${ctx.windMps.toFixed(
      1
    )} m/s (info only)`;
    if (finishers.length === 0) {
      return `No finishers recorded in ${ctx.setup.raceId} (${windStr}).`;
    }
    const w = finishers[0];
    const second = finishers[1];
    const secondTxt = second
      ? `, edging ${second.shortName} (${second.nationCode}, ${second.time?.toFixed(
          2
        )}s)`
      : '';
    const splitsTxt =
      w.firstHalf && w.secondHalf
        ? ` (splits ${w.firstHalf.toFixed(2)}s / ${w.secondHalf.toFixed(2)}s)`
        : '';
    const incCount = ctx.incidents.length;
    const incTxt =
      incCount > 0
        ? ` · ${incCount} official incident(s) logged.`
        : ' · Clean lap.';
    return `${w.name} (${w.nationCode}) wins the Men's 400 Metres in ${(
      w.time ?? 0
    ).toFixed(2)}s${splitsTxt}${secondTxt} · ${windStr}${incTxt}`;
  }
}
