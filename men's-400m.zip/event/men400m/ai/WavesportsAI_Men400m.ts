import type {
  AthleteRaceResult_Men400m,
  AthleteSetup_Men400m,
  PacingStrategy_Men400m,
  RaceIncidentRecord_Men400m,
  RaceResultsPayload_Men400m,
  RaceSetupPayload_Men400m,
} from '../api/types';
import { mergeIncidentRates_Men400m } from '../config/incidents';
import { MEN_400M_PHYSICS } from '../config/physics';
import {
  type CommentaryContext_Men400m,
  type CommentaryCue_Men400m,
  type CommentaryGenerator_Men400m,
  TemplateCommentaryGenerator_Men400m,
} from './commentary';
import { SeededRNG_Men400m } from './seededRng';

export type AthletePoseAction_Men400m =
  | 'still'
  | 'walkout'
  | 'stretch_shakeout'
  | 'on_your_marks'
  | 'set_crouch'
  | 'false_start_twitch'
  | 'sprint'
  | 'tying_up'
  | 'stumble'
  | 'fall_slide'
  | 'pull_up_injured'
  | 'limp'
  | 'lean_finish'
  | 'collapse_finish'
  | 'celebrate'
  | 'disappointed';

export interface AthleteFrameSample_Men400m {
  distanceM: number;
  speedMps: number;
  lateralOffsetM: number;
  pose: AthletePoseAction_Men400m;
}

export interface PlannedAttempt_Men400m {
  attemptIndex: number;
  holdDurationSec: number;
  activeAthleteIds: string[];
  recalled: boolean;
  recallReason?: 'false_start' | 'equipment_issue';
  recallAtTimeSec?: number;
  offendingAthleteId?: string;
  incidents: RaceIncidentRecord_Men400m[];
}

export interface PlannedAthleteRun_Men400m {
  athlete: AthleteSetup_Men400m;
  initialDns: boolean;
  lateDns: boolean;
  dqOnAttempt?: number;
  pacingStrategy: PacingStrategy_Men400m;
  reactionTimeSec: number;
  topSpeedMps: number;
  splits: { '100': number; '200': number; '300': number };
  firstHalfSec: number;
  secondHalfSec: number;
  exactFinishTimeSec: number | null;
  displayFinishTimeSec: number | null;
  status: 'finished' | 'DQ' | 'DNF' | 'DNS';
  reason?: string;
  notes: string[];
  frames: AthleteFrameSample_Men400m[];
}

export interface RacePlan_Men400m {
  setup: RaceSetupPayload_Men400m;
  seed: number;
  windMps: number;
  windLegal: boolean;
  attempts: PlannedAttempt_Men400m[];
  finalAttemptIndex: number;
  totalSimDurationSec: number;
  athleteRuns: Map<string, PlannedAthleteRun_Men400m>;
  incidents: RaceIncidentRecord_Men400m[];
  results: AthleteRaceResult_Men400m[];
  resultsPayload: RaceResultsPayload_Men400m;
  laneIntros: Map<string, string>;
  commentaryCues: CommentaryCue_Men400m[];
  postRaceSummary: string;
}

const FIXED_HZ = MEN_400M_PHYSICS.fixedHz;
const FIXED_DT = 1 / FIXED_HZ;
const SUBSTEPS = MEN_400M_PHYSICS.substeps;
const SUB_DT = FIXED_DT / SUBSTEPS;

const STRAIGHT_LEN_M = 84.39;
const KERB_RADIUS_M = 36.5;
const LANE_WIDTH_M = 1.22;

function getLaneRunningRadius(lane: number): number {
  return KERB_RADIUS_M + (lane - 1) * LANE_WIDTH_M + 0.2;
}

function isPointOnBendForLane(lane: number, dist: number): boolean {
  const r = getLaneRunningRadius(lane);
  const bendArc = Math.PI * r;
  const perim = 2 * STRAIGHT_LEN_M + 2 * bendArc;
  const ovalOffset = perim - MEN_400M_PHYSICS.raceDistanceM;
  const u = ovalOffset + dist;
  const w = ((u % perim) + perim) % perim;
  if (w < bendArc) {
    return w > 0.04 && bendArc - w > 0.04;
  }
  const sBack = w - bendArc;
  if (sBack < STRAIGHT_LEN_M) return false;
  const sWest = sBack - STRAIGHT_LEN_M;
  if (sWest < bendArc) return true;
  return false;
}

function getSegmentDistanceWindow(
  lane: number,
  target: 'east_bend' | 'west_bend'
): [number, number] {
  const r = getLaneRunningRadius(lane);
  const bendArc = Math.PI * r;
  const perim = 2 * STRAIGHT_LEN_M + 2 * bendArc;
  const ovalOffset = perim - MEN_400M_PHYSICS.raceDistanceM;
  if (target === 'east_bend') {
    const startD = Math.max(8, 0 - ovalOffset);
    const endD = Math.max(startD + 12, bendArc - ovalOffset - 4);
    return [startD, endD];
  }
  const westStartW = bendArc + STRAIGHT_LEN_M;
  const startD = westStartW - ovalOffset + 6;
  const endD = westStartW + bendArc - ovalOffset - 6;
  return [startD, endD];
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

function roundTo(v: number, decimals: number): number {
  const f = Math.pow(10, decimals);
  return Math.round(v * f) / f;
}

/**
 * Self-contained Wavesports AI race engine for Men's 400 Metres.
 * Deterministic under seeded RNG; simulates full-lap staggered start,
 * 3 pacing strategies (fast_out, even_paced, controlled_finish),
 * double-bend physics, last-100m tying-up fatigue, and rare incidents.
 */
export class WavesportsAI_Men400m {
  private readonly commentary: CommentaryGenerator_Men400m;

  constructor(
    commentaryGenerator: CommentaryGenerator_Men400m = new TemplateCommentaryGenerator_Men400m()
  ) {
    this.commentary = commentaryGenerator;
  }

  private choosePacingStrategy(
    ath: AthleteSetup_Men400m,
    rng: SeededRNG_Men400m
  ): PacingStrategy_Men400m {
    const { composure, speedEndurance, consistency } = ath.ratings;
    const discipline =
      (composure * 0.45 + speedEndurance * 0.35 + consistency * 0.2) / 100;
    const roll = rng.next();
    // Less composed / more aggressive runners tend to go out fast; disciplined runners even or controlled
    const fastOutProb = clamp(0.46 - discipline * 0.32, 0.12, 0.45);
    const evenProb = clamp(0.32 + discipline * 0.18, 0.3, 0.52);
    if (roll < fastOutProb) return 'fast_out';
    if (roll < fastOutProb + evenProb) return 'even_paced';
    return 'controlled_finish';
  }

  public plan(setup: RaceSetupPayload_Men400m): RacePlan_Men400m {
    const rng = new SeededRNG_Men400m(setup.seed);
    const rates = mergeIncidentRates_Men400m(setup.incidentOverrides);

    // 1. Seeded home-straight wind in [-1.5, +3.0] m/s (informational only in 400m)
    const rawWind = rng.range(
      MEN_400M_PHYSICS.windMinMps,
      MEN_400M_PHYSICS.windMaxMps
    );
    const windMps = roundTo(rawWind, 1);
    // Legal-wind limits do not apply to the 400 m
    const windLegal = true;

    const allIncidents: RaceIncidentRecord_Men400m[] = [];
    const attempts: PlannedAttempt_Men400m[] = [];
    const dqMap = new Map<string, { attempt: number; reason: string }>();
    const lateDnsSet = new Set<string>();

    // Lane introductions
    const laneIntros = new Map<string, string>();
    setup.athletes.forEach((a) => {
      laneIntros.set(a.athleteId, this.commentary.generateLaneIntro(a, setup));
    });

    // 2. Evaluate initial DNS & rare call-room late DNS
    const eligibleAthletes: AthleteSetup_Men400m[] = [];
    setup.athletes
      .slice()
      .sort((a, b) => a.lane - b.lane)
      .forEach((ath) => {
        if (ath.status === 'dns') {
          return;
        }
        if (rng.next() < rates.lateDnsRate && eligibleAthletes.length >= 2) {
          lateDnsSet.add(ath.athleteId);
          allIncidents.push({
            type: 'late_dns',
            code: 'LATE_DNS_CALL_ROOM',
            athleteId: ath.athleteId,
            lane: ath.lane,
            attempt: 0,
            atTime: -18.0,
            detail: `${ath.name} withdrew in the call room before the men's 400m walkout.`,
          });
          return;
        }
        eligibleAthletes.push(ath);
      });

    let activeRoster = [...eligibleAthletes];
    if (activeRoster.length === 0) {
      activeRoster = setup.athletes.filter((a) => a.status === 'active');
    }

    // 3. Simulate start attempts (false starts + equipment block slips up to maxRecalls = 3)
    let attemptIdx = 0;
    while (attemptIdx <= rates.maxRecalls) {
      const holdDurationSec = roundTo(
        rng.range(
          MEN_400M_PHYSICS.setHoldMinSec,
          MEN_400M_PHYSICS.setHoldMaxSec
        ),
        2
      );
      const canRecall = attemptIdx < rates.maxRecalls && activeRoster.length > 2;
      const attemptIncidents: RaceIncidentRecord_Men400m[] = [];

      if (
        canRecall &&
        rng.next() < rates.equipmentBlockSlipRate * activeRoster.length
      ) {
        const affected = rng.pick(activeRoster);
        const slipTime = roundTo(rng.range(0.05, 0.25), 3);
        const inc: RaceIncidentRecord_Men400m = {
          type: 'equipment_issue',
          code: 'BLOCK_SLIP_RECALL',
          athleteId: affected.athleteId,
          lane: affected.lane,
          attempt: attemptIdx,
          atTime: slipTime,
          detail: `Starting block pad slipped under ${affected.shortName} in Lane ${affected.lane}; recall gun fired.`,
        };
        attemptIncidents.push(inc);
        allIncidents.push(inc);
        attempts.push({
          attemptIndex: attemptIdx,
          holdDurationSec,
          activeAthleteIds: activeRoster.map((a) => a.athleteId),
          recalled: true,
          recallReason: 'equipment_issue',
          recallAtTimeSec: slipTime,
          offendingAthleteId: affected.athleteId,
          incidents: attemptIncidents,
        });
        attemptIdx++;
        continue;
      }

      let falseStarter: { ath: AthleteSetup_Men400m; atTime: number } | null =
        null;
      if (canRecall) {
        for (const ath of activeRoster) {
          const composureFactor = 1.45 - (ath.ratings.composure / 100) * 0.9;
          const eagernessFactor = 0.8 + (ath.ratings.reaction / 100) * 0.4;
          const pFalse = clamp(
            rates.falseStartBaseRate * composureFactor * eagernessFactor,
            0,
            0.35
          );
          if (rng.next() < pFalse) {
            const atTime = roundTo(rng.range(-0.14, 0.085), 3);
            if (!falseStarter || atTime < falseStarter.atTime) {
              falseStarter = { ath, atTime };
            }
          }
        }
      }

      if (falseStarter) {
        const inc: RaceIncidentRecord_Men400m = {
          type: 'false_start',
          code: 'FALSE_START_UNDER_100MS',
          athleteId: falseStarter.ath.athleteId,
          lane: falseStarter.ath.lane,
          attempt: attemptIdx,
          atTime: falseStarter.atTime,
          detail: `${falseStarter.ath.name} (Lane ${
            falseStarter.ath.lane
          }) reacted at ${falseStarter.atTime.toFixed(
            3
          )}s (< 0.100s) and was charged with a false start.`,
        };
        attemptIncidents.push(inc);
        allIncidents.push(inc);

        if (setup.rules.falseStartDisqualifies) {
          dqMap.set(falseStarter.ath.athleteId, {
            attempt: attemptIdx,
            reason: 'false_start',
          });
          activeRoster = activeRoster.filter(
            (a) => a.athleteId !== falseStarter!.ath.athleteId
          );
        }

        attempts.push({
          attemptIndex: attemptIdx,
          holdDurationSec,
          activeAthleteIds: [
            ...activeRoster.map((a) => a.athleteId),
            ...(setup.rules.falseStartDisqualifies
              ? [falseStarter.ath.athleteId]
              : []),
          ],
          recalled: true,
          recallReason: 'false_start',
          recallAtTimeSec: Math.max(0.25, falseStarter.atTime + 0.35),
          offendingAthleteId: falseStarter.ath.athleteId,
          incidents: attemptIncidents,
        });
        attemptIdx++;
        continue;
      }

      attempts.push({
        attemptIndex: attemptIdx,
        holdDurationSec,
        activeAthleteIds: activeRoster.map((a) => a.athleteId),
        recalled: false,
        incidents: [],
      });
      break;
    }

    const finalAttemptIndex = attempts[attempts.length - 1].attemptIndex;

    // 4. Plan Men's 400m physics, pacing strategy & in-race incidents
    interface RunnerPhysicsSpec {
      ath: AthleteSetup_Men400m;
      pacingStrategy: PacingStrategy_Men400m;
      reactionTime: number;
      peakTargetSpeed: number;
      cruiseSpeed: number;
      accelRate: number;
      finalFadePenalty: number;
      bendPenaltyFactor: number;
      stumbledStart: boolean;
      stumbleLoss: number;
      fallAtDist: number | null;
      injuryAtDist: number | null;
      laneViolationDist: number | null;
      laneViolationInside: boolean;
      laneViolationAdvantage: boolean;
      fatigueCollapseDist: number | null;
      fatigueCollapseDropsOut: boolean;
      breakout: boolean;
      collisionAtDist: number | null;
      notes: string[];
    }

    const specs = new Map<string, RunnerPhysicsSpec>();

    activeRoster.forEach((ath) => {
      const r = ath.ratings;
      const pacingStrategy = this.choosePacingStrategy(ath, rng);
      const formFactor = rng.gaussian(0, 0.008 * (1.25 - r.consistency / 120));
      const breakout = rng.next() < rates.breakoutPerformanceRate;
      const notes: string[] = [];

      // Reaction time: ~0.14 - 0.24 s
      const baseReact = 0.22 - (r.reaction / 100) * 0.078;
      const reactNoise = rng.gaussian(0, 0.011 * (1.2 - r.composure / 140));
      const reactionTime = roundTo(
        clamp(
          baseReact + reactNoise,
          MEN_400M_PHYSICS.reactionMinSec,
          MEN_400M_PHYSICS.reactionMaxSec
        ),
        3
      );

      // Peak speed (~10.6 - 11.2 m/s) during initial 40-75 m drive
      const basePeak =
        MEN_400M_PHYSICS.basePeakMinMps +
        (r.topSpeed / 100) * MEN_400M_PHYSICS.basePeakSpanMps;
      const breakoutBoost = breakout ? rng.range(0.08, 0.16) : 0;
      const peakTargetSpeed = clamp(
        (basePeak + breakoutBoost) * (1 + formFactor * 0.7),
        MEN_400M_PHYSICS.peakSpeedMinMps,
        MEN_400M_PHYSICS.peakSpeedMaxMps
      );

      // Sustainable cruise speed calibrated for elite winning times ~43.60 - 45.50 s, field up to ~47.0 s
      const cruiseFrac =
        MEN_400M_PHYSICS.cruiseFractionBase +
        (r.speedEndurance / 100) * MEN_400M_PHYSICS.cruiseFractionEnduranceSpan;
      const cruiseSpeed = peakTargetSpeed * cruiseFrac * (1 + formFactor);

      // Acceleration over first 40-60 m
      const accelRate =
        MEN_400M_PHYSICS.accelBaseRate +
        (r.acceleration / 100) * MEN_400M_PHYSICS.accelRatingWeight +
        (r.technique / 100) * MEN_400M_PHYSICS.accelTechWeight;

      // Final 100 m lactic fade (greatly increased if fast_out, softened if controlled_finish)
      const baseFade =
        MEN_400M_PHYSICS.finalFadeBase -
        (r.speedEndurance / 100) * MEN_400M_PHYSICS.finalFadeEnduranceReduction;
      const strategyFadeMult =
        pacingStrategy === 'fast_out'
          ? 1.38
          : pacingStrategy === 'even_paced'
          ? 0.96
          : 0.74;
      const finalFadePenalty = clamp(baseFade * strategyFadeMult, 0.06, 0.27);

      // Bend effect on BOTH bends (tighter radius in inner lanes increases curve drag)
      const runR = getLaneRunningRadius(ath.lane);
      const tightnessRatio = Math.max(
        0,
        MEN_400M_PHYSICS.lane8RunningRadiusM / runR - 1
      );
      const techMitigation = 1.25 - (r.technique / 100) * 0.65;
      const bendPenaltyFactor =
        MEN_400M_PHYSICS.bendPenaltyBase +
        tightnessRatio * MEN_400M_PHYSICS.bendTightnessWeight * techMitigation;

      // Stumbled start out of blocks
      const stumbleProb =
        rates.stumbledStartRate * (1.4 - r.technique / 110);
      const stumbledStart = rng.next() < stumbleProb;
      const stumbleLoss = stumbledStart ? rng.range(0.18, 0.34) : 0;

      // Slip or fall on EITHER bend
      const fallProb =
        rates.fallOrTripRate *
        (1.5 - (r.technique + r.composure) / 160) *
        (1 + tightnessRatio * 0.75);
      const willFall = rng.next() < fallProb;
      let fallAtDist: number | null = null;
      if (willFall) {
        const useFinalBend = rng.next() < 0.62;
        const [bMin, bMax] = getSegmentDistanceWindow(
          ath.lane,
          useFinalBend ? 'west_bend' : 'east_bend'
        );
        fallAtDist = roundTo(rng.range(bMin, bMax), 1);
      }

      // Cramp or muscle pull on back straight or final bend (145 - 320 m)
      const injuryProb =
        rates.injuryPullUpRate *
        (1.45 - r.durability / 110) *
        (0.85 + r.topSpeed / 250);
      const willInjure = !willFall && rng.next() < injuryProb;
      const injuryAtDist = willInjure ? roundTo(rng.range(145, 320), 1) : null;

      // Lane violation on either bend (more likely in inner lanes, low technique)
      const innerLaneBias = 1.55 - (ath.lane - 1) * 0.14;
      const laneViolationProb =
        rates.laneViolationRate *
        innerLaneBias *
        (1.45 - r.technique / 105);
      const hasLaneViolation =
        !willFall && !willInjure && rng.next() < laneViolationProb;
      let laneViolationDist: number | null = null;
      if (hasLaneViolation) {
        const useFinalBend = rng.next() < 0.65;
        const [bMin, bMax] = getSegmentDistanceWindow(
          ath.lane,
          useFinalBend ? 'west_bend' : 'east_bend'
        );
        laneViolationDist = roundTo(rng.range(bMin, bMax), 1);
      }
      const laneViolationInside =
        hasLaneViolation && (ath.lane <= 5 || rng.next() < 0.72);
      const laneViolationAdvantage = laneViolationInside;

      // Fatigue collapse in last 100 m (strongly tied to fast_out & lower speedEndurance)
      const paceCollapseMult =
        pacingStrategy === 'fast_out'
          ? 2.1
          : pacingStrategy === 'even_paced'
          ? 0.55
          : 0.2;
      const enduranceVulnerability = clamp(
        1.55 - r.speedEndurance / 95,
        0.35,
        1.45
      );
      const collapseProb =
        rates.fatigueCollapseRate * paceCollapseMult * enduranceVulnerability;
      const willCollapse =
        !willFall && !willInjure && rng.next() < collapseProb;
      const fatigueCollapseDist = willCollapse
        ? roundTo(rng.range(330, 386), 1)
        : null;
      const fatigueCollapseDropsOut =
        willCollapse && rng.next() < 0.35 && (fatigueCollapseDist ?? 400) < 378;

      if (breakout) {
        notes.push('Breakout 400m performance');
        allIncidents.push({
          type: 'great_performance',
          code: 'BREAKOUT_LAP',
          athleteId: ath.athleteId,
          lane: ath.lane,
          attempt: finalAttemptIndex,
          atTime: 33.5,
          detail: `${ath.name} ran a fearless back straight and is surging down the home straight!`,
        });
      }
      if (stumbledStart) {
        notes.push('Stumbled start');
        allIncidents.push({
          type: 'stumbled_start',
          code: 'BLOCK_STUMBLE',
          athleteId: ath.athleteId,
          lane: ath.lane,
          attempt: finalAttemptIndex,
          atTime: roundTo(reactionTime + 0.35, 3),
          detail: `${ath.name} stumbled pushing out of the angled blocks in Lane ${ath.lane}.`,
        });
      }

      specs.set(ath.athleteId, {
        ath,
        pacingStrategy,
        reactionTime,
        peakTargetSpeed,
        cruiseSpeed,
        accelRate,
        finalFadePenalty,
        bendPenaltyFactor,
        stumbledStart,
        stumbleLoss,
        fallAtDist,
        injuryAtDist,
        laneViolationDist,
        laneViolationInside,
        laneViolationAdvantage,
        fatigueCollapseDist,
        fatigueCollapseDropsOut,
        breakout,
        collisionAtDist: null,
        notes,
      });
    });

    // Rare collision brush between adjacent lanes on a bend after stumble or drift
    activeRoster.forEach((ath) => {
      const sp = specs.get(ath.athleteId)!;
      if (
        sp.stumbledStart ||
        (sp.laneViolationDist !== null && !sp.laneViolationInside)
      ) {
        const neighbor = activeRoster.find(
          (other) => Math.abs(other.lane - ath.lane) === 1
        );
        if (neighbor && rng.next() < rates.collisionBrushRate * 6) {
          const nSpec = specs.get(neighbor.athleteId)!;
          const [bMin, bMax] = getSegmentDistanceWindow(ath.lane, 'west_bend');
          const brushDist = roundTo(rng.range(bMin, bMax), 1);
          sp.collisionAtDist = brushDist;
          nSpec.collisionAtDist = brushDist;
          sp.notes.push('Lane brush on bend');
          nSpec.notes.push('Brushed by adjacent runner');
          allIncidents.push({
            type: 'collision',
            code: 'LANE_BRUSH_CONTACT',
            athleteId: ath.athleteId,
            lane: ath.lane,
            attempt: finalAttemptIndex,
            atTime: roundTo(brushDist / 9.2, 2),
            detail: `Shoulder brush on the bend between Lane ${ath.lane} (${ath.shortName}) and Lane ${neighbor.lane} (${neighbor.shortName}).`,
          });
        }
      }
    });

    // 5. Integrate full-lap physics at 30 Hz substeps and record 1/30s frames
    const maxSimSeconds = MEN_400M_PHYSICS.maxSimDurationSec;
    const numFrames = Math.ceil(maxSimSeconds * FIXED_HZ);

    const athleteRuns = new Map<string, PlannedAthleteRun_Men400m>();
    const snap100 = new Map<string, number>();
    const snap200 = new Map<string, number>();
    const snap300 = new Map<string, number>();
    const snapHomeEntry = new Map<string, number>();
    const fadingCandidates = new Map<string, number>();

    setup.athletes.forEach((ath) => {
      const isInitialDns = ath.status === 'dns';
      const isLateDns = lateDnsSet.has(ath.athleteId);
      const dqEntry = dqMap.get(ath.athleteId);

      if (isInitialDns || isLateDns || dqEntry) {
        athleteRuns.set(ath.athleteId, {
          athlete: ath,
          initialDns: isInitialDns,
          lateDns: isLateDns,
          dqOnAttempt: dqEntry?.attempt,
          pacingStrategy: 'even_paced',
          reactionTimeSec: 0,
          topSpeedMps: 0,
          splits: { '100': 0, '200': 0, '300': 0 },
          firstHalfSec: 0,
          secondHalfSec: 0,
          exactFinishTimeSec: null,
          displayFinishTimeSec: null,
          status: dqEntry ? 'DQ' : 'DNS',
          reason: dqEntry
            ? dqEntry.reason
            : isLateDns
            ? 'late_withdrawal'
            : 'dns',
          notes: dqEntry
            ? [
                `Disqualified (Attempt #${dqEntry.attempt + 1}): ${
                  dqEntry.reason
                }`,
              ]
            : [isLateDns ? 'Late call-room withdrawal' : 'Did not start'],
          frames: [],
        });
        return;
      }

      const sp = specs.get(ath.athleteId)!;
      let dist = 0;
      let speed = 0;
      let peakSpeed = 0;
      let fallen = false;
      let injured = false;
      let injuryTimer = 0;
      let fatigueCollapsed = false;
      let fatigueTimer = 0;
      let collisionTriggered = false;
      let laneViolationLogged = false;
      let finishTimeExact: number | null = null;

      const splitCross: Record<'100' | '200' | '300', number> = {
        '100': 0,
        '200': 0,
        '300': 0,
      };
      const frames: AthleteFrameSample_Men400m[] = [];

      for (let f = 0; f <= numFrames; f++) {
        const frameTime = f * FIXED_DT;

        if (Math.abs(frameTime - 11.2) < FIXED_DT * 0.6) {
          snap100.set(ath.athleteId, dist);
        }
        if (Math.abs(frameTime - 21.6) < FIXED_DT * 0.6) {
          snap200.set(ath.athleteId, dist);
        }
        if (Math.abs(frameTime - 32.5) < FIXED_DT * 0.6) {
          snap300.set(ath.athleteId, dist);
        }
        if (Math.abs(frameTime - 34.8) < FIXED_DT * 0.6) {
          snapHomeEntry.set(ath.athleteId, dist);
        }
        if (Math.abs(frameTime - 38.2) < FIXED_DT * 0.6 && dist > 300) {
          fadingCandidates.set(
            ath.athleteId,
            sp.pacingStrategy === 'fast_out' ? 100 - speed * 5 : 50 - speed * 5
          );
        }

        let pose: AthletePoseAction_Men400m = 'sprint';
        if (frameTime < sp.reactionTime) {
          pose = 'set_crouch';
        } else if (fallen) {
          pose = 'fall_slide';
        } else if (injured) {
          pose = speed > 1.2 ? 'pull_up_injured' : 'limp';
        } else if (fatigueCollapsed) {
          if (sp.fatigueCollapseDropsOut && speed < 0.8) {
            pose = 'fall_slide';
          } else if (finishTimeExact !== null && frameTime > finishTimeExact + 0.1) {
            pose = 'collapse_finish';
          } else {
            pose = speed > 3.8 ? 'stumble' : 'tying_up';
          }
        } else if (
          sp.stumbledStart &&
          frameTime >= sp.reactionTime + 0.1 &&
          frameTime <= sp.reactionTime + 0.85
        ) {
          pose = 'stumble';
        } else if (
          dist >= 397.2 &&
          dist <= 401.4 &&
          (finishTimeExact !== null
            ? frameTime < finishTimeExact + 0.2
            : dist <= 400.6)
        ) {
          pose = 'lean_finish';
        } else if (
          finishTimeExact !== null &&
          frameTime > finishTimeExact + 2.0
        ) {
          pose = 'disappointed'; // Winner updated to 'celebrate' after ranking
        } else if (
          dist >= 310 &&
          dist < 397.2 &&
          speed < sp.cruiseSpeed * (sp.pacingStrategy === 'fast_out' ? 0.9 : 0.85)
        ) {
          pose = 'tying_up';
        }

        // Lateral drift during lane violation on a bend
        const driftSign = sp.laneViolationInside ? -1 : 1;
        const lateralOffsetM =
          sp.laneViolationDist !== null
            ? driftSign *
              Math.sin(
                clamp((dist - (sp.laneViolationDist - 14)) / 36, 0, 1) * Math.PI
              ) *
              0.56
            : 0;

        frames.push({
          distanceM: dist,
          speedMps: speed,
          lateralOffsetM,
          pose,
        });

        for (let s = 0; s < SUBSTEPS; s++) {
          const tNow = frameTime + s * SUB_DT;
          if (tNow < sp.reactionTime) {
            speed = 0;
            continue;
          }

          if (!fallen && sp.fallAtDist !== null && dist >= sp.fallAtDist) {
            fallen = true;
            allIncidents.push({
              type: 'fall',
              code: 'BEND_SLIP_FALL',
              athleteId: ath.athleteId,
              lane: ath.lane,
              attempt: finalAttemptIndex,
              atTime: roundTo(tNow, 2),
              detail: `${ath.name} slipped on the bend at ${dist.toFixed(
                1
              )}m and slid out (DNF).`,
            });
          }

          if (
            !injured &&
            !fallen &&
            sp.injuryAtDist !== null &&
            dist >= sp.injuryAtDist
          ) {
            injured = true;
            injuryTimer = 0;
            allIncidents.push({
              type: 'injury',
              code: 'CRAMP_MUSCLE_PULL',
              athleteId: ath.athleteId,
              lane: ath.lane,
              attempt: finalAttemptIndex,
              atTime: roundTo(tNow, 2),
              detail: `${ath.name} suffered a muscle cramp at ${dist.toFixed(
                1
              )}m and pulled up limping (DNF).`,
            });
          }

          if (
            !fatigueCollapsed &&
            !fallen &&
            !injured &&
            sp.fatigueCollapseDist !== null &&
            dist >= sp.fatigueCollapseDist
          ) {
            fatigueCollapsed = true;
            fatigueTimer = 0;
            sp.notes.push(
              sp.fatigueCollapseDropsOut
                ? 'Fatigue collapse before finish (DNF)'
                : 'Heavy lactic collapse in final 100 m'
            );
            allIncidents.push({
              type: 'fatigue_collapse',
              code: sp.fatigueCollapseDropsOut
                ? 'FATIGUE_COLLAPSE_DNF'
                : 'FATIGUE_TYING_UP',
              athleteId: ath.athleteId,
              lane: ath.lane,
              attempt: finalAttemptIndex,
              atTime: roundTo(tNow, 2),
              detail: sp.fatigueCollapseDropsOut
                ? `${ath.name} tied up severely at ${dist.toFixed(
                    1
                  )}m and collapsed before the finish (DNF).`
                : `${ath.name} tied up heavily in the closing metres at ${dist.toFixed(
                    1
                  )}m and stumbled toward the line.`,
            });
          }

          if (
            !laneViolationLogged &&
            sp.laneViolationDist !== null &&
            dist >= sp.laneViolationDist &&
            !fallen &&
            !injured
          ) {
            laneViolationLogged = true;
            sp.notes.push(
              sp.laneViolationAdvantage
                ? 'Lane infringement on bend (DQ)'
                : 'Drifted wide on bend'
            );
            allIncidents.push({
              type: 'lane_violation',
              code: sp.laneViolationAdvantage
                ? 'LANE_LINE_INSIDE_DQ'
                : 'LANE_DRIFT_WARNING',
              athleteId: ath.athleteId,
              lane: ath.lane,
              attempt: finalAttemptIndex,
              atTime: roundTo(tNow, 2),
              detail: sp.laneViolationAdvantage
                ? `${ath.name} stepped inside his inner lane line on the bend near ${dist.toFixed(
                    0
                  )}m (DQ).`
                : `${ath.name} drifted wide on the bend near ${dist.toFixed(
                    0
                  )}m without gaining an advantage.`,
            });
          }

          if (
            !collisionTriggered &&
            sp.collisionAtDist !== null &&
            dist >= sp.collisionAtDist
          ) {
            collisionTriggered = true;
            speed *= 0.88;
          }

          if (fallen) {
            speed = Math.max(0, speed - 7.4 * SUB_DT);
          } else if (injured) {
            injuryTimer += SUB_DT;
            speed = Math.max(0, speed - 3.6 * SUB_DT);
            if (injuryTimer > 2.8) speed = 0;
          } else if (fatigueCollapsed) {
            fatigueTimer += SUB_DT;
            if (sp.fatigueCollapseDropsOut) {
              speed = Math.max(0, speed - 2.9 * SUB_DT);
            } else {
              // Slows sharply to a heavy stumbling walk/jog over the line
              const minCrawl = finishTimeExact !== null ? 0 : 2.9;
              const decel = finishTimeExact !== null ? 3.5 : 2.2;
              speed = Math.max(minCrawl, speed - decel * SUB_DT);
            }
          } else if (finishTimeExact !== null) {
            const after = tNow - finishTimeExact;
            if (after < 0.45) {
              speed = Math.max(0, speed - 1.3 * SUB_DT);
            } else {
              speed = Math.max(0, speed - 3.8 * SUB_DT);
            }
          } else {
            const sinceReact = tNow - sp.reactionTime;
            const onBend = isPointOnBendForLane(ath.lane, dist);

            // Mild informational home-straight wind influence on straightaways
            const windMult = onBend
              ? 1 + windMps * 0.0008
              : 1 + windMps * 0.0022;

            // Compute pacing-adjusted target speed across the 400 m lap
            let targetSpeed: number;
            if (dist < 65) {
              // Drive / acceleration phase toward peak speed (~10.6 - 11.2 m/s)
              const earlyMult =
                sp.pacingStrategy === 'fast_out'
                  ? 1.015
                  : sp.pacingStrategy === 'even_paced'
                  ? 0.995
                  : 0.985;
              targetSpeed = sp.peakTargetSpeed * earlyMult;
            } else if (dist < 200) {
              // Transition from peak into back-straight cruising pace
              const tBack = clamp((dist - 65) / 135, 0, 1);
              const backMult =
                sp.pacingStrategy === 'fast_out'
                  ? 1.01 - tBack * 0.035
                  : sp.pacingStrategy === 'even_paced'
                  ? 0.97 - tBack * 0.01
                  : 0.935 + tBack * 0.005;
              const blendedBase =
                sp.peakTargetSpeed * (1 - tBack * 0.72) +
                sp.cruiseSpeed * (tBack * 0.72);
              targetSpeed = blendedBase * backMult;
            } else if (dist < 300) {
              // Final bend (200-300 m)
              const tWest = clamp((dist - 200) / 100, 0, 1);
              const westMult =
                sp.pacingStrategy === 'fast_out'
                  ? 0.95 - tWest * 0.065
                  : sp.pacingStrategy === 'even_paced'
                  ? 0.96 - tWest * 0.025
                  : 0.945 - tWest * 0.015;
              targetSpeed = sp.cruiseSpeed * westMult;
            } else {
              // Final 100 m (300-400 m) — lactic fade ("tying up" cost)
              const tFinal = clamp((dist - 300) / 100, 0, 1);
              const preFinalMult =
                sp.pacingStrategy === 'fast_out'
                  ? 0.885
                  : sp.pacingStrategy === 'even_paced'
                  ? 0.935
                  : 0.955;
              targetSpeed =
                sp.cruiseSpeed *
                preFinalMult *
                (1 - sp.finalFadePenalty * tFinal);
            }

            targetSpeed *= windMult;

            if (onBend) {
              targetSpeed *= 1 - sp.bendPenaltyFactor;
            }
            if (sp.stumbledStart && sinceReact < 1.1) {
              targetSpeed *= 1 - sp.stumbleLoss * (1 - sinceReact / 1.1);
            }

            const accelGain =
              dist < 65 ? sp.accelRate * 2.1 : sp.accelRate * 2.6;
            const dv = (targetSpeed - speed) * accelGain * SUB_DT;
            speed = Math.max(0, speed + dv);
          }

          if (speed > peakSpeed) peakSpeed = speed;

          const prevDist = dist;
          dist += speed * SUB_DT;

          ([100, 200, 300] as const).forEach((mark) => {
            const key = String(mark) as '100' | '200' | '300';
            if (splitCross[key] === 0 && prevDist < mark && dist >= mark) {
              const frac = (mark - prevDist) / Math.max(1e-6, dist - prevDist);
              splitCross[key] = roundTo(tNow + frac * SUB_DT, 2);
            }
          });

          if (
            finishTimeExact === null &&
            prevDist < MEN_400M_PHYSICS.raceDistanceM &&
            dist >= MEN_400M_PHYSICS.raceDistanceM
          ) {
            const frac =
              (MEN_400M_PHYSICS.raceDistanceM - prevDist) /
              Math.max(1e-6, dist - prevDist);
            finishTimeExact = roundTo(tNow + frac * SUB_DT, 3);
          }
        }
      }

      let status: 'finished' | 'DQ' | 'DNF' = 'finished';
      let reason: string | undefined;
      if (fallen) {
        status = 'DNF';
        reason = 'fall';
      } else if (injured) {
        status = 'DNF';
        reason = 'injury';
      } else if (fatigueCollapsed && sp.fatigueCollapseDropsOut) {
        status = 'DNF';
        reason = 'fatigue_collapse';
      } else if (finishTimeExact === null) {
        status = 'DNF';
        reason = 'did_not_finish';
      } else if (sp.laneViolationDist !== null && sp.laneViolationAdvantage) {
        status = 'DQ';
        reason = 'lane_violation';
      }

      if (
        status === 'finished' &&
        ath.personalBest &&
        finishTimeExact &&
        finishTimeExact < ath.personalBest
      ) {
        sp.notes.push(`New PB (${finishTimeExact.toFixed(2)}s)`);
      }

      const firstHalf = splitCross['200'] > 0 ? splitCross['200'] : 0;
      const secondHalf =
        finishTimeExact !== null && firstHalf > 0
          ? roundTo(finishTimeExact - firstHalf, 2)
          : 0;

      athleteRuns.set(ath.athleteId, {
        athlete: ath,
        initialDns: false,
        lateDns: false,
        pacingStrategy: sp.pacingStrategy,
        reactionTimeSec: sp.reactionTime,
        topSpeedMps: roundTo(peakSpeed, 2),
        splits: splitCross,
        firstHalfSec: firstHalf,
        secondHalfSec: secondHalf,
        exactFinishTimeSec: status === 'finished' ? finishTimeExact : null,
        displayFinishTimeSec:
          status === 'finished' && finishTimeExact !== null
            ? roundTo(finishTimeExact, 2)
            : null,
        status,
        reason,
        notes: sp.notes,
        frames,
      });
    });

    // 6. Rank finishers by exact 0.001 s time
    const allRuns = Array.from(athleteRuns.values());
    const finishers = allRuns
      .filter((r) => r.status === 'finished' && r.exactFinishTimeSec !== null)
      .sort((a, b) => a.exactFinishTimeSec! - b.exactFinishTimeSec!);

    const winnerId = finishers[0]?.athlete.athleteId;
    if (winnerId) {
      const wRun = athleteRuns.get(winnerId)!;
      wRun.frames.forEach((fr, idx) => {
        if (
          wRun.exactFinishTimeSec &&
          idx * FIXED_DT > wRun.exactFinishTimeSec + 1.8 &&
          fr.pose !== 'collapse_finish'
        ) {
          fr.pose = 'celebrate';
        }
      });
    }

    const rankById = new Map<string, number>();
    finishers.forEach((r, idx) => rankById.set(r.athlete.athleteId, idx + 1));

    const results: AthleteRaceResult_Men400m[] = allRuns
      .slice()
      .sort((a, b) => {
        const ra = rankById.get(a.athlete.athleteId);
        const rb = rankById.get(b.athlete.athleteId);
        if (ra !== undefined && rb !== undefined) return ra - rb;
        if (ra !== undefined) return -1;
        if (rb !== undefined) return 1;
        return a.athlete.lane - b.athlete.lane;
      })
      .map((run) => {
        const rank = rankById.get(run.athlete.athleteId) ?? null;
        if (run.status === 'finished') {
          return {
            rank,
            lane: run.athlete.lane,
            athleteId: run.athlete.athleteId,
            name: run.athlete.name,
            shortName: run.athlete.shortName,
            nation: run.athlete.nation,
            nationCode: run.athlete.nationCode,
            bib: run.athlete.bib,
            time: run.displayFinishTimeSec ?? undefined,
            exactTime: run.exactFinishTimeSec ?? undefined,
            reactionTime: run.reactionTimeSec,
            splits: { ...run.splits },
            firstHalf: run.firstHalfSec,
            secondHalf: run.secondHalfSec,
            topSpeedMps: run.topSpeedMps,
            pacingStrategy: run.pacingStrategy,
            status: 'finished',
            notes: [...run.notes],
          };
        }
        return {
          rank: null,
          lane: run.athlete.lane,
          athleteId: run.athlete.athleteId,
          name: run.athlete.name,
          shortName: run.athlete.shortName,
          nation: run.athlete.nation,
          nationCode: run.athlete.nationCode,
          bib: run.athlete.bib,
          reactionTime:
            run.reactionTimeSec > 0 ? run.reactionTimeSec : undefined,
          splits:
            run.splits['100'] > 0 ? { ...run.splits } : undefined,
          firstHalf: run.firstHalfSec > 0 ? run.firstHalfSec : undefined,
          pacingStrategy: run.pacingStrategy,
          status: run.status,
          reason: run.reason,
          notes: [...run.notes],
        };
      });

    const lastFinish =
      finishers.length > 0
        ? finishers[finishers.length - 1].exactFinishTimeSec ?? 46.5
        : 46.5;
    const totalSimDurationSec = Math.min(
      maxSimSeconds,
      Math.max(47.0, lastFinish + 3.6)
    );

    const findLeader = (snap: Map<string, number>) => {
      let bestAth: AthleteSetup_Men400m | undefined;
      let bestDist = -1;
      snap.forEach((d, id) => {
        if (d > bestDist) {
          bestDist = d;
          bestAth = setup.athletes.find((a) => a.athleteId === id);
        }
      });
      return bestAth;
    };

    const fadingRunner = findLeader(fadingCandidates);
    const pacingById = new Map<string, PacingStrategy_Men400m>();
    athleteRuns.forEach((r, id) => pacingById.set(id, r.pacingStrategy));

    const sortedIncidents = allIncidents
      .slice()
      .sort((a, b) => a.attempt - b.attempt || a.atTime - b.atTime);

    const commentaryCtx: CommentaryContext_Men400m = {
      setup,
      windMps,
      incidents: sortedIncidents,
      results,
    };

    const commentaryCues = this.commentary.generateRaceCues(
      commentaryCtx,
      {
        leaderAt100: findLeader(snap100),
        leaderAt200: findLeader(snap200),
        leaderAt300: findLeader(snap300),
        leaderAtHomeEntry: findLeader(snapHomeEntry),
        fadingRunner,
        pacingById,
      },
      rng
    );
    const postRaceSummary =
      this.commentary.generatePostRaceSummary(commentaryCtx);

    const resultsPayload: RaceResultsPayload_Men400m = {
      raceId: setup.raceId,
      seed: setup.seed,
      completedAt: new Date().toISOString(),
      wind: { mps: windMps, legal: windLegal },
      incidents: sortedIncidents,
      results: results.map((r) => ({ ...r })),
    };

    return {
      setup,
      seed: setup.seed,
      windMps,
      windLegal,
      attempts,
      finalAttemptIndex,
      totalSimDurationSec,
      athleteRuns,
      incidents: sortedIncidents,
      results,
      resultsPayload,
      laneIntros,
      commentaryCues,
      postRaceSummary,
    };
  }
}

export function sampleAthleteFrame_Men400m(
  run: PlannedAthleteRun_Men400m,
  raceTimeSec: number
): AthleteFrameSample_Men400m {
  if (run.frames.length === 0) {
    return {
      distanceM: 0,
      speedMps: 0,
      lateralOffsetM: 0,
      pose: 'disappointed',
    };
  }
  if (raceTimeSec <= 0) {
    return run.frames[0];
  }
  const exactIdx = raceTimeSec * FIXED_HZ;
  const i0 = Math.min(run.frames.length - 1, Math.floor(exactIdx));
  const i1 = Math.min(run.frames.length - 1, i0 + 1);
  const alpha = exactIdx - i0;
  const f0 = run.frames[i0];
  const f1 = run.frames[i1];
  return {
    distanceM: f0.distanceM + (f1.distanceM - f0.distanceM) * alpha,
    speedMps: f0.speedMps + (f1.speedMps - f0.speedMps) * alpha,
    lateralOffsetM:
      f0.lateralOffsetM + (f1.lateralOffsetM - f0.lateralOffsetM) * alpha,
    pose: f0.pose,
  };
}
