/**
 * Men's 400 Metres Physics & Calibration Constants (Wavesports AI).
 * Strictly calibrated for elite men's 400m full-lap racing:
 * - Winning times: ~43.60 - 45.50 s
 * - Full field spread: up to ~47.00 s
 * - Reaction times: ~0.14 - 0.24 s
 * - Peak speeds: ~10.6 - 11.2 m/s
 * - No wind limit applies to the 400 m (wind is informational only).
 */

export const MEN_400M_PHYSICS = {
  raceDistanceM: 400.0,
  splitMarksM: [100, 200, 300] as const,

  /** Fixed 30 Hz simulation step and high-resolution physics substeps */
  fixedHz: 30,
  substeps: 10,
  maxSimDurationSec: 58.0,

  /** Men's 400m reaction time bounds (seconds) */
  reactionMinSec: 0.135,
  reactionMaxSec: 0.245,
  falseStartThresholdSec: 0.1,

  /** Men's 400m peak sprint velocity range (m/s) during initial drive/back straight */
  peakSpeedMinMps: 10.62,
  peakSpeedMaxMps: 11.22,
  basePeakMinMps: 10.64,
  basePeakSpanMps: 0.56,

  /** Acceleration over first 40-60 m */
  accelBaseRate: 0.30,
  accelRatingWeight: 0.12,
  accelTechWeight: 0.035,

  /** Sustainable cruise speed fraction (fraction of peak speed before final-100m lactic fade) */
  cruiseFractionBase: 0.798,
  cruiseFractionEnduranceSpan: 0.046,

  /** Final 100 m (300-400 m) lactic fade ("tying up" cost) */
  finalFadeBase: 0.21,
  finalFadeEnduranceReduction: 0.09,
  tyingUpSpeedRatioThreshold: 0.82,

  /** Bend effect applied on BOTH East Bend and West Bend */
  bendPenaltyBase: 0.018,
  bendTightnessWeight: 0.085,
  lane8RunningRadiusM: 45.24,

  /** Informational home-straight wind range (m/s); 400m has no wind limit */
  windMinMps: -1.5,
  windMaxMps: 3.0,

  /** Set command hold window (seconds) */
  setHoldMinSec: 1.5,
  setHoldMaxSec: 2.5,
} as const;
