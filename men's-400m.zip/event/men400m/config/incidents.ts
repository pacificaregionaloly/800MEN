/**
 * Incident probability defaults for Men's 400 Metres (Wavesports AI).
 * Realistic rare defaults; all rates are per-athlete or per-attempt in [0, 1]
 * and overridable (or zeroed for a clean race) via `setup.incidentOverrides`.
 */

export interface IncidentConfigRates_Men400m {
  /** Base probability per athlete of a false start (< 0.100 s or pre-gun movement). */
  falseStartBaseRate: number;
  /** Base probability per athlete of a slow or stumbled push-off from the blocks. */
  stumbledStartRate: number;
  /** Base probability per athlete of a slip or fall on either bend (DNF). */
  fallOrTripRate: number;
  /** Base probability per athlete of a cramp or muscle pull on back straight / final bend (DNF). */
  injuryPullUpRate: number;
  /** Base probability per athlete of stepping on/inside inner lane line or drifting wide on either bend. */
  laneViolationRate: number;
  /** Base probability of heavy fatigue collapse in the final 100 m (amplified by fast-out pacing). */
  fatigueCollapseRate: number;
  /** Probability of an adjacent-lane brush/collision on a bend after a stumble or drift. */
  collisionBrushRate: number;
  /** Very rare call-room withdrawal after setup validation (DNS). */
  lateDnsRate: number;
  /** Very rare starting block slip requiring a recall & restart without penalty. */
  equipmentBlockSlipRate: number;
  /** Chance of a breakout performance / personal best run. */
  breakoutPerformanceRate: number;
  /** Maximum false-start / equipment recalls before forcing a clean start (capped at 3). */
  maxRecalls: number;
}

export const DEFAULT_INCIDENT_RATES_MEN400M: IncidentConfigRates_Men400m = {
  falseStartBaseRate: 0.025,
  stumbledStartRate: 0.024,
  fallOrTripRate: 0.012,
  injuryPullUpRate: 0.013,
  laneViolationRate: 0.015,
  fatigueCollapseRate: 0.038,
  collisionBrushRate: 0.006,
  lateDnsRate: 0.005,
  equipmentBlockSlipRate: 0.006,
  breakoutPerformanceRate: 0.04,
  maxRecalls: 3,
};

export function mergeIncidentRates_Men400m(
  overrides?: Partial<IncidentConfigRates_Men400m> | null
): IncidentConfigRates_Men400m {
  if (!overrides) {
    return { ...DEFAULT_INCIDENT_RATES_MEN400M };
  }
  const merged: IncidentConfigRates_Men400m = {
    ...DEFAULT_INCIDENT_RATES_MEN400M,
  };
  (
    Object.keys(
      DEFAULT_INCIDENT_RATES_MEN400M
    ) as Array<keyof IncidentConfigRates_Men400m>
  ).forEach((key) => {
    const val = overrides[key];
    if (typeof val === 'number' && Number.isFinite(val)) {
      merged[key] =
        key === 'maxRecalls'
          ? Math.max(0, Math.min(3, Math.round(val)))
          : Math.max(0, Math.min(1, val));
    }
  });
  return merged;
}
