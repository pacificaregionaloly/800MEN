# Men's 400 Metres — Wavesports AI Event Module

Self-contained Men's 400 Metres race module inside `event/men400m/` for the **1st Pacifica Regional Olympics 2026** at **Klemonserrat Stadium**, broadcast by **Wavesports Television (WSTV)**.

---

## Opening the Men's 400m Page

- Dev server URL: `/` or `/men400m.html` (e.g. `http://localhost:3000/` or `http://localhost:3000/men400m.html`)
- Dev-only mock mode: `/?mock=1` or `/men400m.html?mock=1` (with optional `&seed=400826`, `&clean=1`, `&mode=admin`, `&race=men-400m-final-1`)
- Production builds output `dist/index.html` and `dist/men400m.html`, both loading **only** Klemonserrat Stadium and the `men400m` module with zero cross-event imports or shared `event/shared/` code.

---

## Stadium Integrity Statement

No stadium file (`src/*`) or stadium 3D object (track, bowl, roof, boards, branding, crowd, officials, orbit camera, HUD, 30 FPS loop) was modified. All Men's 400m additions (full-lap staggered start lines, tangent-aligned lane numbers, angled starting blocks around the East Bend, starter stand, gun flash/smoke, removable 100 m / 200 m / 300 m split cones, wind gauge, wind flags, recall cones, finish laser) live additively inside one `THREE.Group` named `EventLayer_Men400m`.

Stadium public API calls used (`window.WSTV.stadium`):
- `stadium.scene` (additive `EventLayer_Men400m` group attach/detach)
- `stadium.camera` & `stadium.renderer` (broadcast director + live West Board whole-oval `WebGLRenderTarget`)
- `stadium.getTrackPath(lane).pointAt(distanceMeters)` (derives the 0.20 m inside-line full-lap running path & stagger geometry without altering stadium paths)
- `stadium.addUpdateCallback(fn)` (30 Hz fixed-timestep simulation + render interpolation)
- `stadium.boards.get(name)` / `writeMessage(...)` / `setSource(...)`
- `stadium.people.spawnPerson(...)` / `removePerson(...)` / `setPose(...)` / `getAll()`
- `stadium.cameras.goTo(preset)`

### Stadium API Gaps Worked Around in `event/men400m/`
- **0.20 m Running Line & Full-Lap 400.00 m Oval Wrap-Around:** `stadium.getTrackPath(lane)` returns points along the lane center line (`0.61 m` from inside lane line) and starts at `x = -42.195` without automatic wrap-around past one perimeter. `TrackExtension_Men400m.ts` derives an inward `0.41 m` offset to the official `0.20 m` running line (`0.20 m` from the curb for Lane 1) and implements full-oval modular wrap-around (`w = ((ovalOffset + raceDist) % ovalPerimeterM)`) from each lane's East Bend staggered start all the way back across the finish line on the home straight.
- **Custom Sprint, Double-Bend Lean, Tying-Up & Collapse Animations:** `StadiumAPI` only provides idle/jog poses (`idle`, `walk`, `jog`, `sit`, `wave`, `clap`, `cheer`). `AthleteAnimator_Men400m.ts` animates `PersonInstance` limb pivots inside `addUpdateCallback` for call-room walkout, shakeout skips, `on_your_marks`, `set_crouch`, `false_start_twitch`, `sprint` with centripetal inward curve lean on both East & West bends (`bodyPivot.rotation.z = -bendLeanRad`), fatigued `tying_up` form in the final 100 m, `stumble`, `fall_slide`, `pull_up_injured`, `limp`, `lean_finish`, `collapse_finish`, `celebrate`, and `disappointed`.
- **Board `setText` / `addText` / `clearText` & Live Top-Down Whole-Oval Mini-View:** `BoardController_Men400m.ts` wraps `stadium.boards.get(name)` / `writeMessage` / `setSource` and uses a dedicated overhead `PerspectiveCamera` `(0, 148, 0.5)` + `WebGLRenderTarget` on `westBoard` to render the entire 400 m oval simultaneously.

---

## Staggered Start Self-Check

At startup, `EventTrackLayer_Men400m` integrates a 2,400-segment polyline along each lane's derived 0.20 m running line from `d = 0.00 m` (staggered start) to `d = 400.00 m` (home-straight finish line):
- Home straight = `84.39 m`; two bends (`East Bend` + `West Bend`) + `Back Straight` + `Home Straight` = `400.00 m` per athlete in his own lane (no break line).
- Expected stagger between neighbouring lanes: `2 × π × 1.22 ≈ 7.67 m` per lane (`Lane 8` starts `~53.66 m` ahead of `Lane 1` along the East Bend).
- All 8 lanes must measure `400.00 m ± 0.01 m`; otherwise the race is blocked and `SELF_CHECK_FAILED` is reported.

---

## Configuration (`event/men400m/config/index.ts`)

| Setting | Default | Override |
|---|---|---|
| `API_BASE_URL` | `/api/wavesports` | `VITE_WAVESPORTS_API_BASE_URL` or `?apiBase=...` |
| `API_TOKEN` | `""` | `VITE_WAVESPORTS_API_TOKEN` |
| `RACE_ID` | `men-400m-final-1` | `VITE_WAVESPORTS_400M_RACE_ID` or `?race=...` |
| `POLL_INTERVAL_MS` | `2500` | `VITE_WAVESPORTS_POLL_MS` |
| `MOCK_API` | `true` (dev only) | `?mock=1` / `?mock=0` or `MOCK_API` flag (always disabled in production builds) |

---

## Wavesports API & Incidents

See `docs/men400m-api-contract.md` for full HTTP/SSE/WebSocket schemas (`event: "men_400m"`, setup validation, `start`/`abort`/`reset` commands, status updates, and results payload with `100`/`200`/`300` splits, `firstHalf`, `secondHalf`, `pacingStrategy`, and informational wind).

Default rare incident probabilities live in `event/men400m/config/incidents.ts` (`falseStartBaseRate: 0.025`, `stumbledStartRate: 0.028`, `fallOrTripRate: 0.012`, `injuryPullUpRate: 0.014`, `laneViolationRate: 0.016`, `fatigueCollapseRate: 0.038`, `collisionBrushRate: 0.005`, `lateDnsRate: 0.005`, `equipmentBlockSlipRate: 0.006`, `breakoutPerformanceRate: 0.045`, `maxRecalls: 3`) and can be overridden or zeroed via `setup.incidentOverrides`.

---

## Men's 400m Consistency Audit

A full consistency audit is performed across all Men's 400m files (`event/men400m/**`, `men400m.html`, `docs/men400m-api-contract.md`) checking for any leftover female/women or non-400m race references:
- [x] **Event ID & Naming:** All identifiers, titles (`"MEN'S 400 METRES"`), group (`EventLayer_Men400m`), classes (`Men400mRaceController`, `WavesportsAI_Men400m`, etc.), and mock payloads use `"men_400m"` and `Men400m`.
- [x] **Strict Validation Rejection:** `validateSetupPayload_Men400m` accepts only `event === "men_400m"` and rejects `women_400m`, `men_200m`, `women_200m`, `men_100m`, `women_100m`, or any other event.
- [x] **Athletes & Pronouns:** All 8 mock athletes are fictional men spawned with `gender: 'men'`; all commentary, incident messages, and captions use `he`/`him` pronouns and Men's 400m terminology (zero `women`/`female`/`she`/`her` leftovers).
- [x] **400m-Only Physics, Stagger & Splits:** Physics calibrated for Men's 400m (`~43.60–45.50s` winning times, field up to `~47.0s`, `0.14–0.24s` reaction, `10.6–11.2 m/s` peak speed), full-lap `2 × π × 1.22 ≈ 7.67m/lane` (`~53.66m` L8) stagger, and `100`/`200`/`300` splits plus `firstHalf`/`secondHalf` (zero 200m `3.83m`/`115.61m`/`bendTime`/`straightTime` leftovers).
- [x] **Grep Verification Run:** Automated search across `event/men400m`, `men400m.html`, and `docs/men400m-api-contract.md` confirmed zero unintended template leftovers.
