import React, { useEffect, useMemo, useState } from 'react';
import type { StadiumAPI } from '../../src/api/StadiumAPI';
import { MockWavesportsApi_Men400m } from './api/MockWavesportsApi';
import {
  HttpWavesportsApiClient_Men400m,
  RealtimeWavesportsApiClient_Men400m,
  type WavesportsApiClient_Men400m,
} from './api/WavesportsApiClient';
import { getMen400mConfig, STADIUM_INTEGRITY_CALLS_MEN400M } from './config';
import {
  Men400mRaceController,
  type Men400mUIState,
} from './sim/Men400mRaceController';
import { EventPanel_Men400m } from './ui/EventPanel_Men400m';

interface Men400mEventHostProps {
  api: StadiumAPI;
}

export const Men400mEventHost: React.FC<Men400mEventHostProps> = ({ api }) => {
  const config = useMemo(() => getMen400mConfig(), []);
  const [controller, setController] = useState<Men400mRaceController | null>(
    null
  );
  const [uiState, setUiState] = useState<Men400mUIState | null>(null);

  useEffect(() => {
    console.info(
      '[Stadium Integrity] Men400m event initialized additively inside EventLayer_Men400m. No stadium file or object was modified. API calls used:',
      STADIUM_INTEGRITY_CALLS_MEN400M
    );

    let client: WavesportsApiClient_Men400m;
    if (import.meta.env.DEV && config.MOCK_API) {
      client = new MockWavesportsApi_Men400m({
        seedOverride: config.SEED_OVERRIDE,
        cleanRace: config.CLEAN_RACE_OVERRIDE,
      });
    } else if (config.REALTIME_TRANSPORT !== 'none') {
      client = new RealtimeWavesportsApiClient_Men400m(
        config.API_BASE_URL,
        config.API_TOKEN,
        config.REALTIME_TRANSPORT
      );
    } else {
      client = new HttpWavesportsApiClient_Men400m(
        config.API_BASE_URL,
        config.API_TOKEN
      );
    }

    const ctrl = new Men400mRaceController({
      stadium: api,
      apiClient: client,
      raceId: config.RACE_ID,
      pollIntervalMs: config.POLL_INTERVAL_MS,
      onUIUpdate: (next) => setUiState(next),
    });

    setController(ctrl);

    return () => {
      ctrl.dispose();
      setController(null);
    };
  }, [api, config]);

  if (!controller || !uiState) return null;

  return (
    <EventPanel_Men400m
      controller={controller}
      uiState={uiState}
      adminModeFromUrl={config.ADMIN_MODE}
    />
  );
};
