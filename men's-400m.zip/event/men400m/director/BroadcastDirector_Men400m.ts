import * as THREE from 'three';
import type { StadiumAPI } from '../../../src/api/StadiumAPI';
import type { RaceState_Men400m } from '../api/types';
import type { OvalSegmentKind_Men400m } from '../sim/TrackExtension_Men400m';

export type EventCameraId_Men400m =
  | 'auto'
  | 'staggerOverview'
  | 'blocksHeadOn'
  | 'eastBendCam'
  | 'backStraightRail'
  | 'westBendCam'
  | 'topDownBlimp'
  | 'homeStraightHeadOn'
  | 'finishLine'
  | 'photoFinish'
  | 'replayCam';

export interface LeaderCameraTarget_Men400m {
  position: THREE.Vector3;
  heading: number;
  distanceM: number;
  onBend: boolean;
  segment: OvalSegmentKind_Men400m;
}

/**
 * Men's 400m broadcast camera director.
 * Covers the full staggered oval: East Bend blocks/overview -> East Bend tracking ->
 * Back Straight rail -> West Bend (final bend) -> Home Straight head-on -> Finish Line / Photo Finish,
 * plus Top-Down Blimp over the whole 400m oval.
 * Immediately yields to user mouse/wheel/touch so OrbitControls never fights.
 */
export class BroadcastDirector_Men400m {
  private readonly stadium: StadiumAPI;
  private directorEnabled = true;
  private userTookOrbitControl = false;
  private selectedCamera: EventCameraId_Men400m = 'auto';

  private readonly currentPos = new THREE.Vector3();
  private readonly currentTarget = new THREE.Vector3();
  private readonly desiredPos = new THREE.Vector3();
  private readonly desiredTarget = new THREE.Vector3();
  private currentFov = 44;
  private desiredFov = 44;
  private initializedCamera = false;

  private lastStadiumPreset: string;

  private readonly onUserPointer = () => {
    if (!this.userTookOrbitControl) {
      this.userTookOrbitControl = true;
      this.onStateChangeCallback?.();
    }
  };

  private onStateChangeCallback?: () => void;

  constructor(stadium: StadiumAPI, onStateChange?: () => void) {
    this.stadium = stadium;
    this.onStateChangeCallback = onStateChange;
    this.lastStadiumPreset = stadium.state.cameraPreset;

    const dom = stadium.renderer.domElement;
    dom.addEventListener('pointerdown', this.onUserPointer, { passive: true });
    dom.addEventListener('wheel', this.onUserPointer, { passive: true });
    dom.addEventListener('touchstart', this.onUserPointer, { passive: true });
  }

  public isDirectorEnabled(): boolean {
    return this.directorEnabled;
  }

  public hasUserOverride(): boolean {
    return this.userTookOrbitControl;
  }

  public getSelectedCamera(): EventCameraId_Men400m {
    return this.selectedCamera;
  }

  public setDirectorEnabled(enabled: boolean): void {
    this.directorEnabled = enabled;
    if (enabled) {
      this.userTookOrbitControl = false;
      this.initializedCamera = false;
      this.lastStadiumPreset = this.stadium.state.cameraPreset;
    }
    this.onStateChangeCallback?.();
  }

  public selectCamera(camId: EventCameraId_Men400m): void {
    this.selectedCamera = camId;
    this.directorEnabled = true;
    this.userTookOrbitControl = false;
    this.initializedCamera = false;
    if (camId === 'topDownBlimp') {
      this.stadium.cameras.goTo('overhead');
    }
    this.lastStadiumPreset = this.stadium.state.cameraPreset;
    this.onStateChangeCallback?.();
  }

  public resetView(): void {
    this.userTookOrbitControl = false;
    this.initializedCamera = false;
    this.selectedCamera = 'auto';
    this.directorEnabled = true;
    this.stadium.cameras.goTo('homeStraight');
    this.lastStadiumPreset = this.stadium.state.cameraPreset;
    this.onStateChangeCallback?.();
  }

  public update(
    raceState: RaceState_Men400m,
    raceClockSec: number,
    isReplay: boolean,
    leader: LeaderCameraTarget_Men400m | null,
    dt: number
  ): void {
    if (this.stadium.state.cameraPreset !== this.lastStadiumPreset) {
      this.lastStadiumPreset = this.stadium.state.cameraPreset;
      if (!this.userTookOrbitControl) {
        this.userTookOrbitControl = true;
        this.onStateChangeCallback?.();
      }
      return;
    }

    if (!this.directorEnabled || this.userTookOrbitControl) {
      return;
    }

    const activeCam = this.resolveActiveCamera(
      raceState,
      raceClockSec,
      isReplay,
      leader
    );
    const lx = leader ? leader.position.x : 42.2;
    const lz = leader ? leader.position.z : 36.7;

    switch (activeCam) {
      case 'staggerOverview':
        // High East-Bend stands perspective framing all 8 staggered starts from Lane 1 (finish line) to Lane 8
        this.desiredPos.set(88.0, 22.0, 61.0);
        this.desiredTarget.set(63.5, 0.8, 23.0);
        this.desiredFov = 46;
        break;

      case 'blocksHeadOn':
        // Looking down the East Bend tangent into all 8 angled staggered starting blocks
        this.desiredPos.set(80.0, 3.0, -8.0);
        this.desiredTarget.set(66.0, 0.9, 21.0);
        this.desiredFov = 44;
        break;

      case 'eastBendCam': {
        if (leader && leader.segment === 'east_bend') {
          const tx = Math.sin(leader.heading);
          const tz = Math.cos(leader.heading);
          // Outward radial vector (to runner's right)
          const outX = -tz;
          const outZ = tx;
          this.desiredPos.set(
            lx + outX * 12.0 - tx * 3.5,
            4.6,
            lz + outZ * 12.0 - tz * 3.5
          );
          this.desiredTarget.set(lx + tx * 2.5, 1.0, lz + tz * 2.5);
          this.desiredFov = 42;
        } else {
          // Exiting East Bend onto Back Straight
          this.desiredPos.set(62.0, 5.0, -54.0);
          this.desiredTarget.set(34.0, 1.0, -40.5);
          this.desiredFov = 42;
        }
        break;
      }

      case 'backStraightRail': {
        const clampedX = THREE.MathUtils.clamp(lx, -44, 44);
        this.desiredPos.set(clampedX + 2.0, 3.2, -55.0);
        this.desiredTarget.set(clampedX - 4.0, 1.0, -40.8);
        this.desiredFov = 40;
        break;
      }

      case 'westBendCam': {
        if (leader && leader.segment === 'west_bend') {
          const tx = Math.sin(leader.heading);
          const tz = Math.cos(leader.heading);
          const outX = -tz;
          const outZ = tx;
          this.desiredPos.set(
            lx + outX * 12.0 - tx * 3.5,
            4.4,
            lz + outZ * 12.0 - tz * 3.5
          );
          this.desiredTarget.set(lx + tx * 2.5, 1.0, lz + tz * 2.5);
          this.desiredFov = 40;
        } else {
          // Exiting West Bend onto Home Straight
          this.desiredPos.set(-48.0, 4.5, 55.0);
          this.desiredTarget.set(-28.0, 1.0, 41.38);
          this.desiredFov = 40;
        }
        break;
      }

      case 'topDownBlimp':
        this.desiredPos.set(0.0, 146.0, 0.5);
        this.desiredTarget.set(0.0, 0.0, 0.0);
        this.desiredFov = 48;
        break;

      case 'homeStraightHeadOn': {
        const targetX = leader && leader.segment === 'home_straight' ? Math.min(36, lx) : -10;
        this.desiredPos.set(50.5, 2.2, 41.38);
        this.desiredTarget.set(targetX, 1.0, 41.38);
        this.desiredFov = 34;
        break;
      }

      case 'finishLine':
        this.desiredPos.set(47.2, 2.35, 49.6);
        this.desiredTarget.set(42.195, 1.05, 41.38);
        this.desiredFov = 35;
        break;

      case 'photoFinish':
        this.desiredPos.set(42.195, 1.85, 53.2);
        this.desiredTarget.set(42.195, 0.9, 40.5);
        this.desiredFov = 24;
        break;

      case 'replayCam': {
        const clampedX = THREE.MathUtils.clamp(lx, -45, 45);
        this.desiredPos.set(51.5, 1.9, 34.0);
        this.desiredTarget.set(clampedX, 1.0, 41.38);
        this.desiredFov = 36;
        break;
      }
    }

    if (!this.initializedCamera) {
      this.currentPos.copy(this.stadium.camera.position);
      this.currentTarget.copy(this.desiredTarget);
      this.currentFov = this.stadium.camera.fov;
      this.initializedCamera = true;
    }

    const lambda =
      activeCam === 'backStraightRail' ||
      activeCam === 'eastBendCam' ||
      activeCam === 'westBendCam'
        ? 7.2
        : 5.2;
    const alpha = 1 - Math.exp(-lambda * Math.max(0.001, dt));
    this.currentPos.lerp(this.desiredPos, alpha);
    this.currentTarget.lerp(this.desiredTarget, alpha);
    this.currentFov += (this.desiredFov - this.currentFov) * alpha;

    this.stadium.camera.position.copy(this.currentPos);
    if (Math.abs(this.stadium.camera.fov - this.currentFov) > 0.02) {
      this.stadium.camera.fov = this.currentFov;
      this.stadium.camera.updateProjectionMatrix();
    }
    this.stadium.camera.lookAt(this.currentTarget);
  }

  private resolveActiveCamera(
    raceState: RaceState_Men400m,
    raceClockSec: number,
    isReplay: boolean,
    leader: LeaderCameraTarget_Men400m | null
  ): Exclude<EventCameraId_Men400m, 'auto'> {
    if (this.selectedCamera !== 'auto') {
      return this.selectedCamera;
    }
    if (isReplay) {
      if (raceClockSec < 11.5) return 'eastBendCam';
      if (raceClockSec < 21.8) return 'backStraightRail';
      if (raceClockSec < 32.8) return 'westBendCam';
      return raceClockSec > 42.5 ? 'photoFinish' : 'replayCam';
    }
    switch (raceState) {
      case 'WAITING_FOR_API':
      case 'SETUP_RECEIVED':
      case 'VALIDATED':
      case 'ATHLETES_ON_TRACK':
      case 'READY':
      case 'ON_YOUR_MARKS':
      case 'FALSE_START_RECALL':
        return 'staggerOverview';
      case 'SET':
        return 'blocksHeadOn';
      case 'RUNNING': {
        if (raceClockSec < 2.6) return 'blocksHeadOn';
        if (leader) {
          if (leader.segment === 'east_bend') return 'eastBendCam';
          if (leader.segment === 'back_straight') return 'backStraightRail';
          if (leader.segment === 'west_bend') return 'westBendCam';
          if (leader.distanceM < 386) return 'homeStraightHeadOn';
          return 'finishLine';
        }
        if (raceClockSec < 11.5) return 'eastBendCam';
        if (raceClockSec < 21.8) return 'backStraightRail';
        if (raceClockSec < 32.8) return 'westBendCam';
        if (raceClockSec < 42.4) return 'homeStraightHeadOn';
        return 'finishLine';
      }
      case 'FINISHED':
      case 'RESULTS_POSTED':
        return 'finishLine';
      default:
        return 'staggerOverview';
    }
  }

  public dispose(): void {
    const dom = this.stadium.renderer.domElement;
    dom.removeEventListener('pointerdown', this.onUserPointer);
    dom.removeEventListener('wheel', this.onUserPointer);
    dom.removeEventListener('touchstart', this.onUserPointer);
  }
}
