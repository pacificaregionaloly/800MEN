import * as THREE from 'three';
import type { StadiumAPI } from '../../../src/api/StadiumAPI';
import type { BoardMessageTheme, BoardName } from '../../../src/config';
import type { RacePlan_Men400m } from '../ai/WavesportsAI_Men400m';
import type {
  AthleteRaceResult_Men400m,
  RaceIncidentRecord_Men400m,
  RaceSetupPayload_Men400m,
  RaceState_Men400m,
} from '../api/types';
import type { OvalSegmentKind_Men400m } from '../sim/TrackExtension_Men400m';

export interface BoardSnapshot_Men400m {
  raceState: RaceState_Men400m;
  errorMsg: string | null;
  setup: RaceSetupPayload_Men400m | null;
  plan: RacePlan_Men400m | null;
  raceClockSec: number;
  isReplay: boolean;
  replaySpeed: number;
  liveOrder: Array<{
    lane: number;
    shortName: string;
    nationCode: string;
    distanceM: number;
    speedMps: number;
    onBend: boolean;
    segment: OvalSegmentKind_Men400m;
    status: string;
  }>;
  latestHeadline: string;
  latestCaption: string;
  recallIncident: RaceIncidentRecord_Men400m | null;
}

const SEGMENT_TAG: Record<OvalSegmentKind_Men400m, string> = {
  east_bend: 'BEND 1',
  back_straight: 'BACK',
  west_bend: 'BEND 2',
  home_straight: 'HOME',
};

/**
 * Self-contained stadium LED board controller for Men's 400m.
 * Bridges StadiumAPI boards (`boards.get(name)` & `boards.setSource`) to
 * setText / addText / clearText and a live top-down whole-oval mini-view on `westBoard`.
 */
export class BoardController_Men400m {
  private readonly stadium: StadiumAPI;
  private readonly textLogLines: string[] = [];
  private snapshot: BoardSnapshot_Men400m = {
    raceState: 'WAITING_FOR_API',
    errorMsg: null,
    setup: null,
    plan: null,
    raceClockSec: 0,
    isReplay: false,
    replaySpeed: 1,
    liveOrder: [],
    latestHeadline: "MEN'S 400 METRES",
    latestCaption: 'Waiting for Wavesports API…',
    recallIncident: null,
  };

  private pipTarget: THREE.WebGLRenderTarget | null = null;
  private pipCamera: THREE.PerspectiveCamera | null = null;
  private pipEnabled: boolean;
  private readonly isSoftwareGl: boolean;

  constructor(stadium: StadiumAPI) {
    this.stadium = stadium;
    this.isSoftwareGl = stadium.state.performanceMode;
    this.pipEnabled = !this.isSoftwareGl;

    if (!this.isSoftwareGl) {
      this.pipTarget = new THREE.WebGLRenderTarget(512, 256, {
        minFilter: THREE.LinearFilter,
        magFilter: THREE.LinearFilter,
      });
      this.pipTarget.texture.colorSpace = THREE.SRGBColorSpace;
      this.pipCamera = new THREE.PerspectiveCamera(48, 2, 1.0, 360);
      this.pipCamera.position.set(0, 148, 0.5);
      this.pipCamera.lookAt(0, 0, 0);
    }

    this.showWaitingState(null);
  }

  public setText(
    boardName: BoardName | 'all',
    title: string,
    body = '',
    theme: BoardMessageTheme = 'royal'
  ): void {
    const payload = {
      title,
      body,
      theme,
      ticker: '1ST PACIFICA REGIONAL OLYMPICS 2026 · WSTV',
    };
    if (boardName === 'all') {
      (
        ['mainScoreboard', 'eastBoard', 'westBoard', 'ringBoard'] as BoardName[]
      ).forEach((name) => this.stadium.boards.get(name)?.setMessage(payload));
      this.stadium.boards.writeMessage('all', payload);
      return;
    }
    this.stadium.boards.get(boardName)?.setMessage(payload);
    this.stadium.boards.writeMessage(boardName, payload);
  }

  public addText(boardName: BoardName | 'all', line: string): void {
    this.textLogLines.push(line);
    if (this.textLogLines.length > 4) this.textLogLines.shift();
    this.setText(
      boardName,
      "MEN'S 400 METRES · WSTV",
      this.textLogLines.join('\n'),
      'royal'
    );
  }

  public clearText(boardName: BoardName | 'all'): void {
    this.textLogLines.length = 0;
    this.setText(boardName, 'KLEMONSERRAT STADIUM', '', 'royal');
  }

  public setLiveMiniViewEnabled(enabled: boolean): void {
    this.pipEnabled = enabled && !this.isSoftwareGl && this.pipTarget !== null;
    if (!this.pipEnabled && this.snapshot.raceState !== 'WAITING_FOR_API') {
      this.attachEventBoards();
    }
  }

  public isLiveMiniViewEnabled(): boolean {
    return this.pipEnabled;
  }

  public updateSnapshot(next: Partial<BoardSnapshot_Men400m>): void {
    this.snapshot = { ...this.snapshot, ...next };
  }

  public showWaitingState(errorMsg: string | null): void {
    this.snapshot.raceState = 'WAITING_FOR_API';
    this.snapshot.errorMsg = errorMsg;
    this.setText(
      'all',
      "MEN'S 400 METRES – WAITING FOR WAVESPORTS API",
      errorMsg
        ? `API Status: ${errorMsg}`
        : '1st Pacifica Regional Olympics 2026 · Klemonserrat Stadium',
      errorMsg ? 'alert' : 'royal'
    );
  }

  public activateEventBoards(): void {
    this.attachEventBoards();
  }

  private attachEventBoards(): void {
    const drawMain = (
      ctx: CanvasRenderingContext2D,
      w: number,
      h: number,
      elapsed: number
    ) => this.drawMainBoard(ctx, w, h, elapsed);

    const drawEnd = (
      ctx: CanvasRenderingContext2D,
      w: number,
      h: number,
      elapsed: number
    ) => this.drawEndBoard(ctx, w, h, elapsed);

    const drawRing = (
      ctx: CanvasRenderingContext2D,
      w: number,
      h: number,
      elapsed: number
    ) => this.drawRingBoard(ctx, w, h, elapsed);

    this.stadium.boards.setSource('mainScoreboard', 'canvas2d', {
      draw: drawMain,
    });
    this.stadium.boards.setSource('eastBoard', 'canvas2d', { draw: drawEnd });
    if (!this.pipEnabled) {
      this.stadium.boards.setSource('westBoard', 'canvas2d', { draw: drawEnd });
    }
    this.stadium.boards.setSource('ringBoard', 'canvas2d', { draw: drawRing });
  }

  /**
   * Renders a live top-down mini-view of the entire 400m oval onto `westBoard`
   * so viewers can track all 8 staggered lanes simultaneously across the full lap.
   */
  public renderLiveTopDownOval(): void {
    if (
      !this.pipEnabled ||
      !this.pipTarget ||
      !this.pipCamera ||
      this.isSoftwareGl
    ) {
      return;
    }

    const west = this.stadium.boards.get('westBoard');
    if (!west) return;

    if (west.getSource() !== 'renderTarget') {
      this.stadium.boards.setSource('westBoard', 'renderTarget', {
        renderTargetTexture: this.pipTarget.texture,
      });
    }

    // Whole 400m oval framing covering both bends and both straights simultaneously
    this.pipCamera.position.set(0, 148, 0.5);
    this.pipCamera.lookAt(0, 0, 0);

    const prevTarget = this.stadium.renderer.getRenderTarget();
    const prevVis = west.mesh.visible;
    west.mesh.visible = false;
    this.stadium.renderer.setRenderTarget(this.pipTarget);
    this.stadium.renderer.render(this.stadium.scene, this.pipCamera);
    this.stadium.renderer.setRenderTarget(prevTarget);
    west.mesh.visible = prevVis;
  }

  private drawMainBoard(
    ctx: CanvasRenderingContext2D,
    W: number,
    H: number,
    _elapsed: number
  ): void {
    const snap = this.snapshot;
    const isAlert = snap.raceState === 'FALSE_START_RECALL';

    const bg = ctx.createLinearGradient(0, 0, 0, H);
    bg.addColorStop(0, isAlert ? '#2D070F' : '#04122B');
    bg.addColorStop(1, isAlert ? '#4C0519' : '#0A2558');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    ctx.fillStyle = isAlert ? '#DC2626' : '#0033A0';
    ctx.fillRect(0, 0, W, 68);
    ctx.fillStyle = '#F5C542';
    ctx.fillRect(0, 64, W, 4);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 30px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    const titleSuffix = snap.isReplay
      ? `REPLAY ${snap.replaySpeed}x`
      : snap.setup
      ? `${snap.setup.round.toUpperCase()} · HEAT ${snap.setup.heat}`
      : '1ST PACIFICA OLYMPICS';
    ctx.fillText(`WSTV · MEN'S 400M (${titleSuffix})`, 24, 34);

    const windStr = snap.plan
      ? `WIND ${snap.plan.windMps >= 0 ? '+' : ''}${snap.plan.windMps.toFixed(1)} m/s (INFO)`
      : 'WIND --';

    ctx.textAlign = 'right';
    ctx.fillStyle = '#93C5FD';
    ctx.font = 'bold 19px "JetBrains Mono", monospace';
    ctx.fillText(windStr, W - 210, 34);

    ctx.fillStyle = '#F5C542';
    ctx.font = 'bold 36px "JetBrains Mono", monospace';
    ctx.fillText(`${snap.raceClockSec.toFixed(2)}s`, W - 24, 34);

    if (snap.raceState === 'FALSE_START_RECALL' && snap.recallIncident) {
      ctx.fillStyle = '#EF4444';
      ctx.fillRect(W / 2 - 44, 108, 88, 120);
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 4;
      ctx.strokeRect(W / 2 - 44, 108, 88, 120);

      ctx.textAlign = 'center';
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 48px "Barlow Condensed", sans-serif';
      ctx.fillText('FALSE START — RECALL', W / 2, 276);
      ctx.fillStyle = '#FECDD3';
      ctx.font = '600 24px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(snap.recallIncident.detail, W / 2, 330);
    } else if (
      (snap.raceState === 'FINISHED' || snap.raceState === 'RESULTS_POSTED') &&
      snap.plan
    ) {
      this.drawResultsTable(ctx, W, H, snap.plan.results);
    } else if (snap.raceState === 'ON_YOUR_MARKS' || snap.raceState === 'SET') {
      ctx.textAlign = 'center';
      ctx.fillStyle = '#F5C542';
      ctx.font = 'bold 84px "Barlow Condensed", sans-serif';
      ctx.fillText(
        snap.raceState === 'ON_YOUR_MARKS' ? 'ON YOUR MARKS' : 'SET',
        W / 2,
        H * 0.44
      );
      ctx.fillStyle = '#BAE6FD';
      ctx.font = '600 26px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(snap.latestCaption, W / 2, H * 0.62);
    } else if (snap.raceState === 'RUNNING' && snap.liveOrder.length > 0) {
      this.drawLiveLeaderboard(ctx, W, H, snap.liveOrder);
    } else if (snap.setup) {
      this.drawStartList(ctx, W, H, snap.setup);
    }

    ctx.fillStyle = 'rgba(2, 6, 23, 0.85)';
    ctx.fillRect(16, H - 62, W - 32, 48);
    ctx.fillStyle = '#F5C542';
    ctx.fillRect(16, H - 62, 6, 48);
    ctx.textAlign = 'left';
    ctx.fillStyle = '#F5C542';
    ctx.font = 'bold 20px "Barlow Condensed", sans-serif';
    ctx.fillText(snap.latestHeadline.toUpperCase(), 32, H - 46);
    ctx.fillStyle = '#F8FAFC';
    ctx.font = '600 18px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(snap.latestCaption.slice(0, 92), 32, H - 24);
  }

  private drawStartList(
    ctx: CanvasRenderingContext2D,
    W: number,
    _H: number,
    setup: RaceSetupPayload_Men400m
  ): void {
    const sorted = setup.athletes.slice().sort((a, b) => a.lane - b.lane);
    ctx.textAlign = 'left';
    ctx.fillStyle = '#93C5FD';
    ctx.font = 'bold 22px "Barlow Condensed", sans-serif';
    ctx.fillText('OFFICIAL START LIST · FULL-LAP STAGGERED DRAW (400M)', 28, 94);

    sorted.forEach((a, i) => {
      const y = 114 + i * 38;
      ctx.fillStyle =
        i % 2 === 0 ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.025)';
      ctx.fillRect(24, y, W - 48, 34);
      ctx.fillStyle = a.kit.primary;
      ctx.fillRect(24, y, 8, 34);

      ctx.fillStyle = '#F5C542';
      ctx.font = 'bold 20px "JetBrains Mono", monospace';
      ctx.fillText(`L${a.lane}`, 44, y + 18);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 22px "Barlow Condensed", sans-serif';
      ctx.fillText(
        `#${a.bib}  ${a.name.toUpperCase()} (${a.nationCode})`,
        96,
        y + 18
      );

      ctx.textAlign = 'right';
      ctx.fillStyle = a.status === 'dns' ? '#F87171' : '#7DD3FC';
      ctx.font = 'bold 19px "JetBrains Mono", monospace';
      const pbTxt =
        a.status === 'dns'
          ? 'DNS'
          : a.personalBest
          ? `PB ${a.personalBest.toFixed(2)}s`
          : 'ACTIVE';
      ctx.fillText(pbTxt, W - 36, y + 18);
      ctx.textAlign = 'left';
    });
  }

  private drawLiveLeaderboard(
    ctx: CanvasRenderingContext2D,
    W: number,
    _H: number,
    order: BoardSnapshot_Men400m['liveOrder']
  ): void {
    ctx.textAlign = 'left';
    ctx.fillStyle = '#93C5FD';
    ctx.font = 'bold 22px "Barlow Condensed", sans-serif';
    ctx.fillText('LIVE TRACK TELEMETRY · 400M (BY DISTANCE COVERED)', 28, 94);

    order.slice(0, 8).forEach((row, i) => {
      const y = 114 + i * 38;
      ctx.fillStyle =
        i === 0 ? 'rgba(212,175,55,0.22)' : 'rgba(255,255,255,0.05)';
      ctx.fillRect(24, y, W - 48, 34);

      ctx.fillStyle = '#F5C542';
      ctx.font = 'bold 22px "JetBrains Mono", monospace';
      ctx.fillText(`${i + 1}`, 38, y + 18);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 22px "Barlow Condensed", sans-serif';
      ctx.fillText(
        `L${row.lane} · ${row.shortName} (${row.nationCode})`,
        84,
        y + 18
      );

      const barX = W * 0.43;
      const barW = W * 0.28;
      const frac = Math.max(0, Math.min(1, row.distanceM / 400));
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      ctx.fillRect(barX, y + 10, barW, 14);
      ctx.fillStyle = i === 0 ? '#F5C542' : row.onBend ? '#38BDF8' : '#34D399';
      ctx.fillRect(barX, y + 10, barW * frac, 14);

      ctx.textAlign = 'right';
      ctx.fillStyle = '#E2E8F0';
      ctx.font = 'bold 16px "JetBrains Mono", monospace';
      const seg = SEGMENT_TAG[row.segment] ?? 'TRACK';
      ctx.fillText(
        `${seg} · ${Math.min(400, row.distanceM).toFixed(1)}m · ${row.speedMps.toFixed(
          1
        )}m/s`,
        W - 36,
        y + 18
      );
      ctx.textAlign = 'left';
    });
  }

  private drawResultsTable(
    ctx: CanvasRenderingContext2D,
    W: number,
    _H: number,
    results: AthleteRaceResult_Men400m[]
  ): void {
    ctx.textAlign = 'left';
    ctx.fillStyle = '#F5C542';
    ctx.font = 'bold 22px "Barlow Condensed", sans-serif';
    ctx.fillText(
      'OFFICIAL 400M RESULTS · SPLITS (100 / 200 / 300 / HALF)',
      28,
      94
    );

    results.slice(0, 8).forEach((r, i) => {
      const y = 114 + i * 38;
      ctx.fillStyle =
        r.rank === 1
          ? 'rgba(212,175,55,0.24)'
          : i % 2 === 0
          ? 'rgba(255,255,255,0.06)'
          : 'rgba(255,255,255,0.025)';
      ctx.fillRect(24, y, W - 48, 34);

      ctx.fillStyle = r.rank === 1 ? '#F5C542' : '#7DD3FC';
      ctx.font = 'bold 20px "JetBrains Mono", monospace';
      ctx.fillText(r.rank !== null ? `${r.rank}` : r.status, 36, y + 18);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 21px "Barlow Condensed", sans-serif';
      ctx.fillText(
        `L${r.lane} ${r.shortName} (${r.nationCode})`,
        84,
        y + 18
      );

      ctx.textAlign = 'right';
      ctx.fillStyle = r.status === 'finished' ? '#F5C542' : '#FCA5A5';
      ctx.font = 'bold 16px "JetBrains Mono", monospace';
      const timeTxt =
        r.status === 'finished' && r.exactTime !== undefined
          ? `${r.exactTime.toFixed(3)}s · ${r.splits?.['100']?.toFixed(2) ?? '-'} / ${
              r.splits?.['200']?.toFixed(2) ?? '-'
            } / ${r.splits?.['300']?.toFixed(2) ?? '-'} · 2H ${
              r.secondHalf?.toFixed(2) ?? '-'
            }`
          : `${r.status} (${r.reason ?? ''})`;
      ctx.fillText(timeTxt, W - 32, y + 18);
      ctx.textAlign = 'left';
    });
  }

  private drawEndBoard(
    ctx: CanvasRenderingContext2D,
    W: number,
    H: number,
    _elapsed: number
  ): void {
    const snap = this.snapshot;
    ctx.fillStyle = '#04122B';
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#0033A0';
    ctx.fillRect(0, 0, W, 62);
    ctx.fillStyle = '#F5C542';
    ctx.fillRect(0, 58, W, 4);

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 28px "Barlow Condensed", sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText("WSTV · MEN'S 400 METRES", 22, 31);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#F5C542';
    ctx.font = 'bold 34px "JetBrains Mono", monospace';
    ctx.fillText(`${snap.raceClockSec.toFixed(2)}s`, W - 22, 31);

    ctx.textAlign = 'center';
    if (snap.raceState === 'FALSE_START_RECALL') {
      ctx.fillStyle = '#EF4444';
      ctx.fillRect(W / 2 - 42, 110, 84, 110);
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 42px "Barlow Condensed", sans-serif';
      ctx.fillText('FALSE START RECALL', W / 2, 265);
    } else if (
      (snap.raceState === 'FINISHED' || snap.raceState === 'RESULTS_POSTED') &&
      snap.plan
    ) {
      const top3 = snap.plan.results.slice(0, 3);
      ctx.fillStyle = '#F5C542';
      ctx.font = 'bold 34px "Barlow Condensed", sans-serif';
      ctx.fillText('400M PODIUM FINISH', W / 2, 108);
      top3.forEach((r, idx) => {
        ctx.fillStyle = '#FFFFFF';
        ctx.font = 'bold 32px "Barlow Condensed", sans-serif';
        const val =
          r.status === 'finished' && r.time !== undefined
            ? `${r.time.toFixed(2)}s`
            : r.status;
        ctx.fillText(
          `${idx + 1}. ${r.shortName} (${r.nationCode}) — ${val}`,
          W / 2,
          172 + idx * 54
        );
      });
    } else {
      ctx.fillStyle = '#F5C542';
      ctx.font = 'bold 54px "Barlow Condensed", sans-serif';
      ctx.fillText(snap.latestHeadline.toUpperCase(), W / 2, H * 0.44);
      ctx.fillStyle = '#BAE6FD';
      ctx.font = '600 24px "Plus Jakarta Sans", sans-serif';
      ctx.fillText(snap.latestCaption.slice(0, 64), W / 2, H * 0.62);
    }
  }

  private drawRingBoard(
    ctx: CanvasRenderingContext2D,
    W: number,
    H: number,
    elapsed: number
  ): void {
    const snap = this.snapshot;
    ctx.fillStyle =
      snap.raceState === 'FALSE_START_RECALL' ? '#4C0519' : '#031233';
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#F5C542';
    ctx.fillRect(0, 0, W, 6);
    ctx.fillRect(0, H - 6, W, 6);

    const wind = snap.plan
      ? `WIND ${snap.plan.windMps >= 0 ? '+' : ''}${snap.plan.windMps.toFixed(1)} m/s (INFO)`
      : 'WSTV';
    const text = `MEN'S 400 METRES  ·  ${snap.latestHeadline.toUpperCase()}  ·  ${wind}  ·  CLOCK ${snap.raceClockSec.toFixed(
      2
    )}s  ·  `;

    ctx.font = 'bold 48px "Barlow Condensed", sans-serif';
    const tw = Math.max(420, ctx.measureText(text).width);
    const offset = (elapsed * 130) % tw;
    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    for (let x = -offset; x < W; x += tw) {
      ctx.fillText(text, x, H / 2 + 2);
    }
  }

  public resetToDemo(): void {
    this.setLiveMiniViewEnabled(false);
    (
      ['mainScoreboard', 'eastBoard', 'westBoard', 'ringBoard'] as BoardName[]
    ).forEach((b) => this.stadium.boards.setSource(b, 'demo'));
  }

  public dispose(): void {
    this.pipTarget?.dispose();
    this.pipTarget = null;
    this.resetToDemo();
  }
}
