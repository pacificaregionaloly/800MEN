import * as THREE from 'three';
import type { StadiumAPI } from '../../../src/api/StadiumAPI';
import type {
  PersonInstance,
  PersonOptions,
  PersonPoseName,
} from '../../../src/people/PersonFactory';
import type { AthletePoseAction_Men400m } from '../ai/WavesportsAI_Men400m';
import type { AthleteSetup_Men400m } from '../api/types';
import type {
  EventTrackLayer_Men400m,
  OvalSegmentKind_Men400m,
} from '../sim/TrackExtension_Men400m';
import { applyAthletePose_Men400m } from './AthleteAnimator_Men400m';

interface SnapshottedRunner {
  options: PersonOptions;
  pose: PersonPoseName;
  jogDistance: number;
}

export interface EventAthleteEntity_Men400m {
  setup: AthleteSetup_Men400m;
  stadiumPersonId: string;
  person: PersonInstance;
  accentMesh: THREE.Mesh;
  stridePhase: number;
  currentPose: AthletePoseAction_Men400m;
  currentSpeedMps: number;
  currentDistanceM: number;
  onBend: boolean;
  segment: OvalSegmentKind_Men400m;
}

const SKIN_TONES = [
  '#6D442B',
  '#8D5524',
  '#A5694F',
  '#C68642',
  '#E0AC69',
  '#F1C27D',
];

/**
 * Manages Men's 400m male athletes around the full-lap staggered oval.
 * Leaves the stadium untouched on initial WAITING_FOR_API load (no athletes placed).
 * Suspends stadium idle runners only once a validated roster is spawned, and restores them on reset/unmount.
 */
export class AthleteManager_Men400m {
  private readonly stadium: StadiumAPI;
  private readonly trackLayer: EventTrackLayer_Men400m;
  private readonly entities = new Map<string, EventAthleteEntity_Men400m>();
  private snapshottedIdleRunners: SnapshottedRunner[] = [];
  private runnersSuspended = false;

  constructor(stadium: StadiumAPI, trackLayer: EventTrackLayer_Men400m) {
    this.stadium = stadium;
    this.trackLayer = trackLayer;
  }

  private suspendStadiumIdleRunners(): void {
    if (this.runnersSuspended) return;
    const all = this.stadium.people.getAll();
    const toRemove: SnapshottedRunner[] = [];
    const idsToRemove: string[] = [];

    all.forEach((p) => {
      if (p.type === 'runner' && !p.id.startsWith('men400m-')) {
        toRemove.push({
          options: { ...p.options, id: p.id, jogOffsetMeters: p.jogDistance },
          pose: p.pose,
          jogDistance: p.jogDistance,
        });
        idsToRemove.push(p.id);
      }
    });

    idsToRemove.forEach((id) => this.stadium.people.removePerson(id));
    this.snapshottedIdleRunners = toRemove;
    this.runnersSuspended = true;
  }

  private restoreStadiumIdleRunners(): void {
    if (!this.runnersSuspended) return;
    this.snapshottedIdleRunners.forEach((snap) => {
      const id = this.stadium.people.spawnPerson('runner', {
        ...snap.options,
        pose: snap.pose,
        jogOffsetMeters: snap.jogDistance,
      });
      this.stadium.people.setPose(id, snap.pose);
    });
    this.snapshottedIdleRunners = [];
    this.runnersSuspended = false;
  }

  public spawnRoster(
    athletes: AthleteSetup_Men400m[],
    skipIds: Set<string>
  ): void {
    this.clearEventAthletes();
    this.suspendStadiumIdleRunners();

    const sorted = athletes.slice().sort((a, b) => a.lane - b.lane);
    sorted.forEach((ath, idx) => {
      if (ath.status === 'dns' || skipIds.has(ath.athleteId)) {
        return; // DNS athletes remain in the call room
      }

      const lp = this.trackLayer.getLanePath(ath.lane);
      const startPt = lp.pointAtRaceDistance(-0.45);
      const id = `men400m-${ath.athleteId}`;

      const spawnedId = this.stadium.people.spawnPerson('runner', {
        id,
        gender: 'men',
        name: `${ath.shortName} (${ath.nationCode})`,
        number: ath.bib,
        kitPrimary: ath.kit.primary,
        kitSecondary: ath.kit.secondary,
        skinTone: SKIN_TONES[idx % SKIN_TONES.length],
        pose: 'idle',
        position: [startPt.position.x, startPt.position.y, startPt.position.z],
        heading: startPt.heading,
      });

      const person = this.stadium.people
        .getAll()
        .find((p) => p.id === spawnedId);
      if (!person) return;

      const accentGeo = new THREE.BoxGeometry(0.365, 0.06, 0.22);
      const accentMat = new THREE.MeshStandardMaterial({
        color: ath.kit.accent,
        roughness: 0.5,
        metalness: 0.2,
      });
      const accentMesh = new THREE.Mesh(accentGeo, accentMat);
      accentMesh.position.set(0, 0.36, 0);
      person.torso.add(accentMesh);

      this.entities.set(ath.athleteId, {
        setup: ath,
        stadiumPersonId: spawnedId,
        person,
        accentMesh,
        stridePhase: (idx * 1.1) % (Math.PI * 2),
        currentPose: 'stretch_shakeout',
        currentSpeedMps: 0,
        currentDistanceM: -0.45,
        onBend: startPt.onBend,
        segment: startPt.segment,
      });
      applyAthletePose_Men400m(person, 'stretch_shakeout', 0, 0, 0, 0);
    });
  }

  public updateAthleteState(
    athleteId: string,
    distanceM: number,
    lateralOffsetM: number,
    speedMps: number,
    pose: AthletePoseAction_Men400m,
    dt: number,
    elapsedSec: number,
    visible = true
  ): void {
    const ent = this.entities.get(athleteId);
    if (!ent) return;

    ent.person.root.visible = visible;
    if (!visible) return;

    const lp = this.trackLayer.getLanePath(ent.setup.lane);
    const pt = lp.pointAtRaceDistance(distanceM, lateralOffsetM);
    ent.person.root.position.copy(pt.position);
    ent.person.root.rotation.y = pt.heading;

    if (
      pose === 'sprint' ||
      pose === 'tying_up' ||
      pose === 'stumble' ||
      pose === 'lean_finish'
    ) {
      const cadence = 6.2 + speedMps * 1.42;
      ent.stridePhase += cadence * dt;
    } else if (pose === 'pull_up_injured') {
      ent.stridePhase += Math.max(2.0, speedMps * 1.1) * dt;
    }

    ent.currentPose = pose;
    ent.currentSpeedMps = speedMps;
    ent.currentDistanceM = distanceM;
    ent.onBend = pt.onBend;
    ent.segment = pt.segment;

    // Centripetal lean angle into East or West bend: atan(v^2 / (R * g)) * 0.72
    const bendLeanRad =
      pt.onBend && speedMps > 2.0
        ? Math.min(
            0.26,
            Math.atan(
              (speedMps * speedMps) / (Math.max(25, pt.bendRadiusM) * 9.81)
            ) * 0.72
          )
        : 0;

    applyAthletePose_Men400m(
      ent.person,
      pose,
      elapsedSec,
      speedMps,
      ent.stridePhase,
      bendLeanRad
    );
  }

  public getEntity(
    athleteId: string
  ): EventAthleteEntity_Men400m | undefined {
    return this.entities.get(athleteId);
  }

  public getAllEntities(): EventAthleteEntity_Men400m[] {
    return Array.from(this.entities.values());
  }

  public getLeaderSnapshot(): {
    position: THREE.Vector3;
    heading: number;
    distanceM: number;
    onBend: boolean;
    segment: OvalSegmentKind_Men400m;
  } | null {
    let best: EventAthleteEntity_Men400m | null = null;
    this.entities.forEach((ent) => {
      if (!ent.person.root.visible) return;
      if (!best || ent.currentDistanceM > best.currentDistanceM) {
        best = ent;
      }
    });
    if (!best) return null;
    const chosen = best as EventAthleteEntity_Men400m;
    return {
      position: chosen.person.root.position.clone(),
      heading: chosen.person.root.rotation.y,
      distanceM: chosen.currentDistanceM,
      onBend: chosen.onBend,
      segment: chosen.segment,
    };
  }

  public clearEventAthletes(): void {
    this.entities.forEach((ent) => {
      ent.person.torso.remove(ent.accentMesh);
      ent.accentMesh.geometry.dispose();
      (ent.accentMesh.material as THREE.Material).dispose();
      this.stadium.people.removePerson(ent.stadiumPersonId);
    });
    this.entities.clear();
  }

  public cleanupAll(): void {
    this.clearEventAthletes();
    this.restoreStadiumIdleRunners();
  }
}
